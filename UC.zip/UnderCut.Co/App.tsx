import React, {useEffect, useState} from 'react';
import {StatusBar, View, ActivityIndicator, StyleSheet} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {Provider as PaperProvider} from 'react-native-paper';
import {SafeAreaProvider} from 'react-native-safe-area-context';

import {AuthProvider, useAuth} from './src/contexts/AuthContext';
import {ConfigProvider} from './src/contexts/ConfigContext';
import {LanguageProvider} from './src/contexts/LanguageContext';
import {PushNotificationProvider} from './src/contexts/PushNotificationContext';
import {AuthNavigator} from './src/navigation/AuthNavigator';
import {MainNavigator} from './src/navigation/MainNavigator';
import {theme} from './src/theme/theme';
import {initializeFirebase} from './src/services/firebase';
import {initializeI18n} from './src/services/translation';
import {loadConfig} from './src/config/appConfig';
import {setupBackgroundMessageHandler} from './src/services/pushNotifications';
import {initializeProtection} from './src/services/codeProtection';
import {startAIOrchestrator} from './src/workers/aiOrchestratorWorker';

// Setup background message handler (must be called at module level)
setupBackgroundMessageHandler();

// Start AI Orchestrator worker
startAIOrchestrator();

const Stack = createStackNavigator();

const RootNavigator: React.FC = () => {
  const {user, loading: authLoading} = useAuth();

  if (authLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        {user ? (
          <Stack.Screen name="Main" component={MainNavigator} />
        ) : (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Handle deep linking for referrals
export const handleDeepLink = (url: string) => {
  // Parse referral link: https://undercut.co/ref/CODE1234
  const referralMatch = url.match(/\/ref\/([A-Z0-9]+)/i);
  if (referralMatch) {
    const referralCode = referralMatch[1];
    // Navigate to referral onboarding with code
    return {
      screen: 'ReferralOnboarding',
      params: {referralCode},
    };
  }
  return null;
};

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Initialize code protection first
        initializeProtection();
        
        // Load app configuration first
        await loadConfig();
        
        // Initialize translations (must be before other services)
        await initializeI18n();
        
        // Initialize Firebase
        await initializeFirebase();
        
        setIsLoading(false);
      } catch (error) {
        console.error('App initialization error:', error);
        setIsLoading(false);
      }
    };

    initializeApp();
  }, []);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <PaperProvider theme={theme}>
        <ConfigProvider>
          <LanguageProvider>
            <AuthProvider>
              <PushNotificationProvider>
                <StatusBar barStyle="dark-content" backgroundColor={theme.colors.surface} />
                <RootNavigator />
              </PushNotificationProvider>
            </AuthProvider>
          </LanguageProvider>
        </ConfigProvider>
      </PaperProvider>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.colors.background,
  },
});

export default App;

