# Translation Setup Guide

## Overview

UnderCut.Co includes comprehensive global translation support with **34+ languages** and a scalable translation API integration for worldwide adoption.

## Features

- ✅ **34+ Supported Languages** - Major languages worldwide
- ✅ **TAP to Select Language** - Easy language selection interface
- ✅ **Automatic Device Language Detection** - Detects user's device language
- ✅ **Translation API Integration** - Google Translate API support (scalable)
- ✅ **Offline Support** - Local translation files for core languages
- ✅ **Dynamic Translation** - Translate user-generated content via API
- ✅ **Language Persistence** - Saves user's language preference

## Supported Languages

### Popular Languages
- English (en)
- Spanish (es)
- French (fr)
- German (de)
- Italian (it)
- Portuguese (pt)
- Russian (ru)
- Chinese (zh)
- Japanese (ja)
- Korean (ko)

### European Languages
- Polish (pl)
- Dutch (nl)
- Swedish (sv)
- Danish (da)
- Finnish (fi)
- Norwegian (no)
- Czech (cs)
- Hungarian (hu)
- Romanian (ro)
- Greek (el)
- Ukrainian (uk)
- Bulgarian (bg)
- Croatian (hr)
- Slovak (sk)
- Slovenian (sl)

### Asian Languages
- Hindi (hi)
- Thai (th)
- Vietnamese (vi)
- Indonesian (id)
- Malay (ms)

### Middle Eastern & Other
- Arabic (ar)
- Turkish (tr)
- Hebrew (he)

## Setup Instructions

### 1. Install Dependencies

The translation dependencies are already in `package.json`:
- `i18next` - Translation framework
- `react-i18next` - React integration
- `react-native-localize` - Device language detection

```bash
npm install
```

### 2. Translation API Setup (Optional but Recommended)

For dynamic translation of user-generated content and additional languages:

#### Google Translate API

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable "Cloud Translation API"
4. Create credentials (API Key)
5. Add to your `.env` file:

```env
GOOGLE_TRANSLATE_API_KEY=your_api_key_here
```

6. Update `src/config/appConfig.ts`:

```typescript
translationAPIKey: process.env.GOOGLE_TRANSLATE_API_KEY,
useTranslationAPI: true,
translationAPIProvider: 'google',
```

### 3. Language Selection

Users can select their language in two ways:

#### Option 1: From Welcome Screen
- Tap the language button at the top of the welcome screen
- Select from the language list

#### Option 2: From Profile Settings
- Go to Profile → Language
- TAP to select preferred language

### 4. Adding New Languages

#### Method 1: Local Translation Files (Recommended for Core Languages)

1. Create `src/locales/{language_code}.json`
2. Copy structure from `src/locales/en.json`
3. Translate all strings
4. The language will be automatically available

Example: `src/locales/es.json`
```json
{
  "common": {
    "loading": "Cargando...",
    "error": "Error",
    ...
  },
  ...
}
```

#### Method 2: API Translation (For Additional Languages)

The system will automatically translate using the API when:
- Language file doesn't exist locally
- Translation API is configured
- User selects that language

### 5. Using Translations in Code

```typescript
import {useLanguage} from '../contexts/LanguageContext';

const MyComponent = () => {
  const {t} = useLanguage();
  
  return (
    <Text>{t('common.loading')}</Text>
  );
};
```

### 6. Translating User-Generated Content

For dynamic content (quotes, bids, etc.):

```typescript
import {translateText} from '../services/translation';

const translatedText = await translateText(
  userInputText,
  targetLanguage // optional, uses current language if not provided
);
```

## Translation File Structure

All translations follow this structure in `src/locales/en.json`:

```json
{
  "common": { ... },
  "app": { ... },
  "welcome": { ... },
  "auth": { ... },
  "home": { ... },
  "quote": { ... },
  "bid": { ... },
  "transaction": { ... },
  "profile": { ... },
  "terms": { ... },
  "legal": { ... },
  "config": { ... },
  "language": { ... },
  "errors": { ... }
}
```

## Configuration

### App Configuration (`src/config/appConfig.ts`)

```typescript
{
  useTranslationAPI: true,              // Enable API translation
  translationAPIKey: 'your_api_key',    // API key
  translationAPIProvider: 'google',     // 'google' | 'azure' | 'aws' | 'custom'
}
```

## Language Selection Screen

The language selection screen (`src/screens/main/LanguageScreen.tsx`) provides:

- **Current Language Display** - Shows selected language
- **Grouped Languages** - Organized by region (Popular, European, Asian, etc.)
- **TAP to Select** - Large, easy-to-tap language items
- **Visual Feedback** - Checkmark for selected language
- **Loading States** - Shows progress during language change

## Best Practices

1. **Always use translation keys** - Never hardcode text
2. **Keep keys descriptive** - Use namespaces (e.g., `common.loading`)
3. **Test all languages** - Ensure UI works with RTL languages (Arabic, Hebrew)
4. **Cache translations** - API translations are cached automatically
5. **Fallback to English** - If translation fails, English is used

## RTL (Right-to-Left) Support

For RTL languages (Arabic, Hebrew), you may need to:

1. Install `react-native-i18n` or similar for RTL layout
2. Update styles to support RTL
3. Test UI with RTL languages

## Performance Considerations

- **Local files are fast** - Core languages load instantly
- **API translations are cached** - Subsequent loads are fast
- **Batch API calls** - Multiple translations are batched when possible
- **Lazy loading** - Languages load only when selected

## Troubleshooting

### Language not changing
- Check if language file exists in `src/locales/`
- Verify API key is correct (if using API)
- Check console for errors

### Translations not appearing
- Ensure `LanguageProvider` wraps your app
- Verify translation keys match exactly
- Check that `initializeI18n()` is called in `App.tsx`

### API translation not working
- Verify API key is valid
- Check API quota/limits
- Ensure internet connection
- Check API response in console

## Scaling for Worldwide Adoption

The translation system is designed to scale:

1. **Phase 1**: Local translation files (fast, offline)
2. **Phase 2**: API translation for additional languages
3. **Phase 3**: CDN-hosted translation files
4. **Phase 4**: Regional translation servers

## Support

For translation issues or to add new languages, refer to:
- `src/services/translation.ts` - Translation service
- `src/contexts/LanguageContext.tsx` - Language context
- `src/locales/en.json` - Base translation file

---

**Built for global scale with 34+ languages and counting!**

