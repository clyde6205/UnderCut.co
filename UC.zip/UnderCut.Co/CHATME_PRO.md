# ChatMe.Pro Integration

## Overview

ChatMe.Pro is the professional communication platform integrated into UnderCut.Co for buyers and sellers. It is a **subscription-based, closed chat system** designed to protect platform users from casual chat users.

## Key Features

### ✅ Subscription-Based Access
- Users must subscribe to use chat
- Monthly ($9.99/month) or Yearly ($99.99/year) plans
- Subscribers don't need to be buyers or sellers
- Access granted via user profiles → Tap "ChatMe.Pro"

### ✅ Platform Usage Requirement
- **6-month inactivity rule**: If users don't use the platform for its intended purposes (posting quotes, submitting bids, completing transactions) for 6 months, chat access is removed
- Protects buyers and sellers from casual users
- Automatic usage tracking
- Warning system before removal

### ✅ Professional Communication
- Direct messaging between users
- Quote-related chat rooms
- Transaction-related chat rooms
- General chat for platform users
- Real-time messaging
- Message read receipts

### ✅ Optional Feature
- Accessible via user profiles
- Tap "ChatMe.Pro" to access
- No forced usage
- Clear disclaimers about requirements

## Important Disclaimers

### Platform Usage Requirement
> **If within 6 months of not using the Platform for its purposes, Chat usage will be eliminated.**

This policy ensures:
- Protection for buyers and sellers
- Platform purpose integrity
- Prevention of casual users
- Active community engagement

### No Forced Usage
> **We are NOT seeking to force anyone to use our system, but we must protect our buyers and sellers from casual chat users.**

The system:
- Doesn't force anyone to use chat
- Doesn't force anyone to use the platform
- Protects active users from non-active users
- Maintains platform purpose integrity

## How It Works

### For Users

1. **Subscribe to ChatMe.Pro**
   - Go to Profile → Tap "ChatMe.Pro"
   - Choose Monthly or Yearly plan
   - Subscribe and start chatting

2. **Start a Chat**
   - View user profile
   - Tap "ChatMe.Pro" button
   - Or access from Chat list

3. **Maintain Access**
   - Use platform for intended purposes
   - Post quotes, submit bids, complete transactions
   - Activity tracked automatically
   - Warning sent if inactive for 5+ months

### Platform Usage Tracking

Activities that count as platform usage:
- **Posting Quotes** - Buyers posting quotes
- **Submitting Bids** - Sellers submitting bids
- **Completing Transactions** - Finishing purchases

**Inactivity Period**: 6 months without any platform activity
- Warning sent at 5 months
- Chat access removed at 6 months
- Grace period for new users

## Technical Implementation

### Subscription Management
```typescript
// Subscribe to chat
await subscribeToChat(userId, 'monthly' | 'yearly');

// Check subscription status
const hasAccess = await hasActiveChatSubscription(userId);

// Check platform usage eligibility
const isEligible = await checkPlatformUsageEligibility(userId);
```

### Usage Tracking
```typescript
// Track platform usage
await updatePlatformUsage(userId, 'quote' | 'bid' | 'transaction');
```

### Chat Rooms
- Quote-based chat: Links to specific quotes
- Transaction-based chat: Links to transactions
- General chat: Platform-wide communication

## Access Points

1. **Profile Screen**
   - Tap "ChatMe.Pro" in profile menu
   - Access chat list or subscribe

2. **User Profiles**
   - View any user profile
   - Tap "Start Chat" button
   - Creates or opens chat room

3. **Quote/Transaction Details**
   - Chat buttons for related users
   - Direct access to relevant chats

## Benefits

### For Buyers & Sellers
- **Protected Communication** - Only active platform users
- **Professional Environment** - No casual chatter
- **Direct Messaging** - Quick communication
- **Transaction Support** - Chat related to quotes/transactions

### For Platform
- **Maintains Purpose** - Ensures platform-focused usage
- **Quality Control** - Filters out inactive users
- **User Protection** - Protects active users
- **Revenue Stream** - Subscription model

## Configuration

### Subscription Plans
- Monthly: $9.99/month
- Yearly: $99.99/year (Save 17%)

### Usage Requirements
- Inactivity Period: 6 months
- Warning Period: 5 months
- Grace Period: 6 months for new users

### Tracking
- Automatic tracking on:
  - Quote posting
  - Bid submission
  - Transaction completion
- Manual tracking available
- Real-time eligibility checks

## Security & Privacy

- **Subscription Verification** - Verified before chat access
- **Usage Validation** - Regular eligibility checks
- **Message Security** - Encrypted communication
- **User Privacy** - Protected user data
- **Access Control** - Role-based permissions

## Support

For chat-related issues:
- Check subscription status
- Verify platform usage
- Contact support if needed
- Review disclaimers and policies

---

**ChatMe.Pro - Professional Communication for Serious Platform Users**

