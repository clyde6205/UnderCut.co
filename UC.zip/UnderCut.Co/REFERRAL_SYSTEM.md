# QR Sharing & Referral System

## Overview

UnderCut.Co includes a comprehensive QR sharing and referral system designed for easy, fast onboarding and viral growth. Users can refer others through QR codes or referral links.

## Features

### ✅ QR Code Sharing
- **Generate QR Codes** - Each user gets a unique QR code
- **Share QR Image** - Share QR code as image via any platform
- **Scan to Join** - Fast onboarding with QR code scanning
- **Visual QR Display** - Beautiful, branded QR codes

### ✅ Referral Links
- **Unique Referral Links** - Each user gets a unique link
- **Copy to Clipboard** - One-tap copy functionality
- **Share Anywhere** - Share via SMS, email, social media, etc.
- **Deep Linking** - Links automatically open app with referral code

### ✅ Fast Onboarding
- **Quick Signup** - Streamlined signup process for referrals
- **Code Validation** - Real-time referral code validation
- **Automatic Processing** - Referrals processed automatically
- **Instant Rewards** - Track referral status immediately

### ✅ Referral Tracking
- **Statistics Dashboard** - View referral performance
- **Referral History** - See all your referrals
- **Earnings Tracking** - Track referral rewards
- **Status Monitoring** - Pending, completed, rewarded status

## How It Works

### For Referrers

1. **Get Your Referral Code**
   - Go to Profile → Referral Program
   - Your unique code is generated automatically
   - Code format: `USER1234` (8 characters)

2. **Share via QR Code**
   - Tap "Share QR Code"
   - QR code is generated with your referral link
   - Share image via any platform
   - Recipient scans to join instantly

3. **Share via Link**
   - Tap "Share Link" or "Copy Link"
   - Share your referral link: `https://undercut.co/ref/USER1234`
   - Recipient taps link to join

4. **Track Performance**
   - View referral statistics
   - See who joined via your referral
   - Track earnings and rewards

### For New Users

1. **Receive Referral**
   - Scan QR code or tap referral link
   - App opens with referral code pre-filled

2. **Quick Onboarding**
   - Fast signup screen appears
   - Code is validated automatically
   - Fill in basic information
   - Create account instantly

3. **Automatic Processing**
   - Referral is recorded automatically
   - Referrer gets credit
   - Both users benefit

## Technical Implementation

### Referral Code Generation
```typescript
// Format: USERID (4 chars) + Random (4 chars)
// Example: USER1234
const code = generateReferralCode(userId);
```

### Referral Link
```
https://undercut.co/ref/{CODE}
```

### Deep Linking
- Links automatically open app
- Parse referral code from URL
- Pre-fill in signup form
- Validate and process

### QR Code Format
- Contains full referral URL
- Scannable by any QR reader
- Opens app or website
- Auto-redirects to signup

## Integration Points

### Sign Up Flow
- Check for referral code in URL
- Validate code before signup
- Process referral after successful signup
- Credit referrer immediately

### Profile Integration
- Referral section in profile
- Quick access to referral program
- Statistics display
- Share buttons

### Admin Console
- View all referrals
- Referral analytics
- Performance metrics
- Reward management

## Benefits

### For Users
- **Easy Sharing** - QR or link, your choice
- **Fast Onboarding** - Quick signup process
- **Track Performance** - See your referral stats
- **Earn Rewards** - Get rewarded for referrals

### For Platform
- **Viral Growth** - Easy sharing drives growth
- **User Acquisition** - Referrals bring new users
- **Engagement** - Users share to earn rewards
- **Tracking** - Full analytics and insights

## Configuration

### Referral Rewards
- Configure reward amounts
- Set minimum requirements
- Define reward conditions
- Track earnings

### Platform Settings
```typescript
{
  referralRewardAmount: 10,           // Reward per referral
  minReferralTransactions: 1,         // Min transactions for reward
  referralCodeLength: 8,              // Code length
  referralBaseURL: 'https://undercut.co/ref'
}
```

## Scaling Considerations

### Current Phase (0-50k users)
- Direct database queries
- Real-time referral processing
- Firebase storage for QR codes

### Growth Phase (50k-1M users)
- Cached referral data
- CDN for QR code images
- Background processing
- Optimized queries

### Enterprise Phase (1M+ users)
- Dedicated referral service
- Distributed QR generation
- Advanced analytics
- Machine learning optimization

## Security

- **Code Uniqueness** - Guaranteed unique codes
- **Validation** - Real-time code validation
- **Prevent Self-Referral** - Users can't refer themselves
- **Fraud Prevention** - Track and prevent abuse
- **Secure Links** - HTTPS and app deep linking

---

**Built for viral growth and easy worldwide adoption!**

