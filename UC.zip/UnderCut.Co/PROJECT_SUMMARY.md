# UnderCut.Co - Project Summary

## Platform Overview

UnderCut.Co is a **global bartering platform** built with React Native, designed for focused buyers who have already decided exactly what product they want to purchase and are seeking the lowest price through a vetted, timed offering system.

## Key Differentiator

**This is NOT a shopping platform.** It is specifically designed for:
- **Focused buyers** who know exactly what they want (no browsing)
- **Competitive sellers** who compete by offering their lowest prices
- **Timed transactions** with secure E-Escrow
- **Global reach** built to scale to billions of users

## Architecture & Technology Stack

### Frontend
- **React Native 0.72.6** with TypeScript
- **React Navigation** for routing
- **React Native Paper** for UI components
- **React Context API** for state management

### Backend Services
- **Firebase** (Phase 1: 0-50k users)
  - Authentication
  - Firestore Database
  - Storage
- **AWS** (Phase 2: 50k+ users - future migration)

### Payment Processing
- **Stripe** (Primary, fully editable)
- **XRP/Ripple** (Secondary option)
- **Critical:** Company NEVER holds or stores customer money

### Blockchain
- Full blockchain integration for transaction auditing
- Immutable transaction records
- Supports Ethereum, Polygon, Binance networks (configurable)

### AI Integration
- AI agents for organization and automation
- **Non-critical operations only** (no money handling, no critical decisions)

## Core Features Implemented

### ✅ User Management
- Buyer and Seller roles
- Authentication with Firebase
- User profiles with ratings and transaction history

### ✅ Quote System
- Buyers post vetted quotes with specifications
- Category-based (Luxury, Mid-level, Lower-level)
- Time-limited quotes with editable expiration
- Global platform indicators

### ✅ Bidding System
- Sellers submit competitive bids
- Lowest price competition
- Bid details (price, delivery time, warranty)
- Automatic bid sorting

### ✅ Escrow System
- Built-in E-Escrow for secure transactions
- **Editable transaction timing** (configurable timeout)
- Cool-down periods for transaction continuation
- **NO REFUNDS policy** (clearly stated)

### ✅ Payment Integration
- **Stripe** (primary, editable)
- **XRP/Ripple** (secondary, via Ripple's platform)
- Payment processor selection is fully editable
- All money handled by payment processors (never by company)

### ✅ Transaction Management
- Complete transaction lifecycle tracking
- Blockchain transaction recording
- Status management (pending, escrow, completed, etc.)
- Transaction history

### ✅ Legal & Compliance
- Terms of Service
- Financial disclaimers (company never holds money)
- NO REFUNDS policy explanation
- Dispute resolution policy (buyer-seller only)

### ✅ Configuration
- **Editable transaction timeout** (currently 72 hours default)
- **Editable payment processor** (Stripe/XRP)
- Escrow cool-down configuration
- Blockchain network selection

### ✅ Platform Features
- Category filtering
- Global platform messaging
- Real-time quote and bid updates
- Transaction expiration monitoring
- AI organization tasks

## Project Structure

```
UnderCut.Co/
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── QuoteCard.tsx
│   │   └── CategoryFilter.tsx
│   ├── screens/
│   │   ├── auth/           # Authentication screens
│   │   │   ├── WelcomeScreen.tsx
│   │   │   ├── LoginScreen.tsx
│   │   │   └── SignUpScreen.tsx
│   │   └── main/           # Main app screens
│   │       ├── HomeScreen.tsx
│   │       ├── PostQuoteScreen.tsx
│   │       ├── MyQuotesScreen.tsx
│   │       ├── QuoteDetailScreen.tsx
│   │       ├── BidScreen.tsx
│   │       ├── TransactionsScreen.tsx
│   │       ├── TransactionDetailScreen.tsx
│   │       ├── ProfileScreen.tsx
│   │       ├── TermsScreen.tsx
│   │       ├── LegalScreen.tsx
│   │       └── ConfigScreen.tsx
│   ├── navigation/          # Navigation setup
│   │   ├── AuthNavigator.tsx
│   │   └── MainNavigator.tsx
│   ├── services/            # External services
│   │   ├── firebase.ts      # Firebase integration
│   │   ├── stripe.ts        # Stripe payments
│   │   ├── xrp.ts           # XRP/Ripple payments
│   │   ├── blockchain.ts    # Blockchain integration
│   │   ├── escrow.ts        # Escrow system
│   │   └── aiAgent.ts       # AI organization
│   ├── contexts/            # React contexts
│   │   ├── AuthContext.tsx
│   │   └── ConfigContext.tsx
│   ├── types/               # TypeScript types
│   │   └── index.ts
│   ├── config/              # Configuration
│   │   ├── appConfig.ts     # Editable settings
│   │   └── categories.ts    # Product categories
│   ├── utils/               # Utility functions
│   │   └── index.ts
│   └── theme/               # Theme & styling
│       └── theme.ts
├── App.tsx                  # Main app component
├── index.js                 # Entry point
├── package.json
├── tsconfig.json
├── babel.config.js
├── README.md
├── SETUP.md
└── PROJECT_SUMMARY.md

```

## Critical Business Rules

### 1. Money Handling
- **Company NEVER holds or stores customer money**
- All funds processed directly through payment processors
- Money movement handled solely by Stripe/XRP/Ripple platforms

### 2. Transaction Policy
- **NO REFUNDS** due to Escrow cool-down periods
- Cool-down period allows transaction continuation
- All transactions are final once cool-down passes

### 3. Dispute Resolution
- Legal disputes are between buyers and sellers ONLY
- Company provides tools only, does not mediate
- Company is not a party to transactions

### 4. Platform Purpose
- **NOT a shopping platform** - no browsing
- For focused buyers who know exactly what they want
- Sellers compete with lowest prices
- Global platform for worldwide transactions

## Configuration & Customization

### Editable Settings (via ConfigScreen)
1. **Transaction Timeout** - Hours before quote expires (default: 72)
2. **Payment Processor** - Stripe or XRP (fully editable)
3. **Escrow Cool-Down** - Hours for transaction continuation (default: 24)
4. **Blockchain Network** - Ethereum, Polygon, Binance, etc.

### Categories
- **Luxury**: Vehicles, Gold Bullion, Real Estate, Watches, Jewelry
- **Mid-Level**: Electronics, Vehicles, Furniture, Appliances
- **Lower-Level**: Clothing, Books, Home & Garden, Sports

## Scaling Strategy

### Phase 1: Firebase (0-50k users)
- Firebase Authentication
- Firestore Database
- Firebase Storage
- Current implementation

### Phase 2: AWS Migration (50k+ users)
- AWS Cognito (authentication)
- AWS DynamoDB or RDS (database)
- AWS S3 (storage)
- AWS Lambda (backend functions)
- Migration path defined

### Phase 3: Enterprise Scale (Billions of users)
- Microservices architecture
- Global CDN
- Multi-region deployment
- Advanced caching and optimization

## Security & Compliance

- Blockchain transaction auditing
- Secure payment processing (Stripe/XRP)
- Firebase security rules (to be configured)
- User authentication and authorization
- Financial disclaimers and legal compliance
- Terms of Service enforcement

## Next Steps for Production

1. **Firebase Configuration**
   - Set up Firebase project
   - Configure security rules
   - Add google-services.json / GoogleService-Info.plist

2. **Payment Processor Setup**
   - Configure Stripe account
   - Set up XRP/Ripple integration
   - Implement backend payment APIs (for production)

3. **Blockchain Integration**
   - Set up blockchain RPC endpoints
   - Configure transaction recording
   - Test transaction verification

4. **Testing**
   - Unit tests
   - Integration tests
   - End-to-end testing
   - Security testing

5. **Deployment**
   - Android Play Store
   - iOS App Store
   - Backend API deployment
   - Monitoring and analytics

## Important Notes

- All editable settings are stored in app configuration
- Platform messaging emphasizes "focused buyers" and "not a shopping platform"
- Legal disclaimers are prominently displayed
- Financial disclaimers clearly state company never holds money
- NO REFUNDS policy is clearly explained
- Global platform indicators throughout UI

## Support & Documentation

- **README.md** - Main project documentation
- **SETUP.md** - Setup and installation guide
- **PROJECT_SUMMARY.md** - This file

---

**Built with enterprise-grade architecture for global scale.**

