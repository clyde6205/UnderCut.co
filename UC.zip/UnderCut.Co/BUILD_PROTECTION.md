# Build-Time Code Protection

## Production Build Protection

To protect your code from cloning and unauthorized copying, follow these steps for production builds:

## 1. Code Obfuscation

### Install Obfuscation Tools

```bash
# For JavaScript/TypeScript obfuscation
npm install --save-dev javascript-obfuscator
npm install --save-dev react-native-obfuscate
```

### Configure Metro Bundler

Update `metro.config.js`:

```javascript
const {getDefaultConfig} = require('@react-native/metro-config');
const obfuscator = require('react-native-obfuscate');

module.exports = (async () => {
  const config = await getDefaultConfig();
  
  if (process.env.NODE_ENV === 'production') {
    config.transformer = {
      ...config.transformer,
      minifierPath: require.resolve('react-native-obfuscate'),
      minifierConfig: {
        keep_classnames: false,
        keep_fnames: false,
        mangle: true,
        compress: {
          drop_console: true,
          drop_debugger: true,
        },
      },
    };
  }
  
  return config;
})();
```

## 2. Enable Hermes (JavaScript Engine)

### Android (`android/app/build.gradle`)

```gradle
project.ext.react = [
    enableHermes: true,  // Enable Hermes for better performance and obfuscation
]
```

### iOS (`ios/Podfile`)

```ruby
:hermes_enabled => true
```

## 3. Remove Source Maps (Production)

```bash
# Build without source maps
npx react-native run-android --variant=release --no-sourcemap
npx react-native run-ios --configuration Release --no-sourcemap
```

## 4. Enable ProGuard (Android)

Update `android/app/proguard-rules.pro`:

```proguard
# UnderCut.Co Protection
-keep class com.undercutco.** { *; }
-dontwarn com.undercutco.**

# Obfuscation
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose
```

Enable in `android/app/build.gradle`:

```gradle
buildTypes {
    release {
        minifyEnabled true
        shrinkResources true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}
```

## 5. Remove Console Logs

Create `babel-plugin-remove-console.js`:

```javascript
module.exports = function({types: t}) {
  return {
    visitor: {
      CallExpression(path, state) {
        if (process.env.NODE_ENV === 'production') {
          const callee = path.node.callee;
          if (
            t.isMemberExpression(callee) &&
            t.isIdentifier(callee.object, {name: 'console'})
          ) {
            path.remove();
          }
        }
      },
    },
  };
};
```

Update `babel.config.js`:

```javascript
plugins: [
  ...(process.env.NODE_ENV === 'production' 
    ? [require('./babel-plugin-remove-console')]
    : []),
]
```

## 6. Package.json Scripts

Add production build scripts:

```json
{
  "scripts": {
    "build:android:release": "cd android && ./gradlew assembleRelease --no-sourcemap",
    "build:ios:release": "cd ios && xcodebuild -configuration Release --no-sourcemap",
    "obfuscate": "javascript-obfuscator src --output dist --config obfuscator.config.js"
  }
}
```

## 7. Environment Variables

Create `.env.production`:

```env
NODE_ENV=production
ENABLE_OBFUSCATION=true
REMOVE_SOURCE_MAPS=true
ENABLE_CODE_PROTECTION=true
```

## 8. Verification

After building, verify:
- ✅ No readable function names in bundle
- ✅ No console.log statements
- ✅ No source maps generated
- ✅ Code obfuscated and minified
- ✅ Copyright headers preserved

## Additional Protection

### Runtime Protection
- Platform validation on startup
- License checks
- Code integrity verification
- Watermark detection

### Legal Protection
- Copyright registration
- Trademark registration
- Terms of service
- Legal disclaimers

---

**Protecting your code at build-time and runtime.**

