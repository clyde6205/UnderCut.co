# UnderCut.Co - Setup Guide

## Prerequisites

- Node.js (v16 or higher)
- React Native CLI
- Android Studio (for Android development)
- Xcode (for iOS development - macOS only)
- Firebase account
- Stripe account (optional, for payments)
- XRP/Ripple account (optional, for XRP payments)

## Installation

### 1. Install Dependencies

```bash
npm install
```

### 2. iOS Setup (macOS only)

```bash
cd ios
pod install
cd ..
```

### 3. Firebase Setup

1. Create a Firebase project at https://console.firebase.google.com
2. Add Android and iOS apps to your Firebase project
3. Download configuration files:
   - Android: `google-services.json` → Place in `android/app/`
   - iOS: `GoogleService-Info.plist` → Place in `ios/UndercutCo/`

### 4. Environment Configuration

Create a `.env` file in the root directory (use `.env.example` as a template):

```env
# Firebase Configuration
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
FIREBASE_PROJECT_ID=your_project_id
FIREBASE_STORAGE_BUCKET=your_project.appspot.com
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id

# Stripe Configuration (Optional)
STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_publishable_key
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key

# XRP Configuration (Optional)
XRP_API_ENDPOINT=wss://s.altnet.rippletest.net:51233
RIPPLE_NETWORK=testnet

# Blockchain Configuration
BLOCKCHAIN_NETWORK=ethereum
BLOCKCHAIN_RPC_URL=https://mainnet.infura.io/v3/your_infura_key
```

### 5. Update App Configuration

Edit `src/config/appConfig.ts` to include your Firebase configuration:

```typescript
firebaseConfig: {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id",
},
```

## Running the App

### Android

```bash
npm run android
```

### iOS

```bash
npm run ios
```

## Key Features Implemented

### ✅ Core Features
- React Native with TypeScript
- Firebase integration (Auth, Firestore, Storage)
- Stripe payment integration (editable)
- XRP/Ripple payment integration (secondary option)
- Blockchain transaction recording
- Escrow system with editable timing
- Category-based system (Luxury, Mid-level, Lower-level)
- Global platform messaging
- AI agent organization layer

### ✅ User Features
- User authentication (Buyers & Sellers)
- Quote posting by buyers
- Bid submission by sellers
- Transaction management
- Profile management
- Terms of Service & Legal disclaimers

### ✅ Platform Features
- Editable transaction timeout
- Editable payment processor selection
- NO REFUNDS policy implementation
- Financial disclaimers
- Global platform indicators
- Blockchain auditing

## Important Notes

### Payment Processing
- **We NEVER hold customer money** - All payments go directly through Stripe/XRP
- Money movement is handled solely by payment processors

### Transaction Policy
- **NO REFUNDS** - Due to Escrow cool-down periods
- Legal disputes are between buyers and sellers only
- Company provides tools only, does not mediate

### Platform Purpose
- **NOT a shopping platform** - For focused buyers who know what they want
- Buyers post quotes, sellers compete with lowest prices
- Global platform built for billions of users

## Project Structure

```
src/
├── components/        # Reusable UI components
├── screens/          # Screen components
│   ├── auth/        # Authentication screens
│   └── main/        # Main app screens
├── navigation/       # Navigation configuration
├── services/         # External services
│   ├── firebase.ts  # Firebase integration
│   ├── stripe.ts    # Stripe payments
│   ├── xrp.ts       # XRP payments
│   ├── blockchain.ts # Blockchain integration
│   ├── escrow.ts    # Escrow system
│   └── aiAgent.ts   # AI organization
├── contexts/         # React contexts
├── types/           # TypeScript types
├── utils/           # Utility functions
├── config/          # Configuration files
└── theme/           # Theme and styling
```

## Scaling Strategy

1. **Phase 1 (0-50k users)**: Firebase
2. **Phase 2 (50k+ users)**: AWS migration
3. **Phase 3 (Billions)**: Enterprise infrastructure

## Testing

```bash
npm test
```

## Building for Production

### Android
```bash
cd android
./gradlew assembleRelease
```

### iOS
```bash
cd ios
xcodebuild -workspace UndercutCo.xcworkspace -scheme UndercutCo -configuration Release
```

## Support

For issues or questions, please refer to the main README.md file.

