/**
 * Script to add copyright headers to all source files
 * 
 * Run with: node scripts/add-copyright-headers.js
 * 
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

const fs = require('fs');
const path = require('path');

const COPYRIGHT_HEADER = `/**
 * Copyright (c) 2024 UnderCut.Co. All Rights Reserved.
 * 
 * This software is proprietary and confidential. Unauthorized copying,
 * modification, distribution, or use of this software, via any medium,
 * is strictly prohibited and may result in severe civil and criminal penalties.
 * 
 * Protected by copyright law and international treaties.
 */
`;

const EXCLUDED_DIRS = ['node_modules', '.git', 'build', 'dist', 'ios', 'android', '.expo'];
const EXCLUDED_FILES = ['package.json', 'package-lock.json', 'yarn.lock', 'LICENSE', 'README.md'];
const INCLUDE_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx'];

function shouldProcessFile(filePath) {
  const ext = path.extname(filePath);
  if (!INCLUDE_EXTENSIONS.includes(ext)) {
    return false;
  }

  const fileName = path.basename(filePath);
  if (EXCLUDED_FILES.includes(fileName)) {
    return false;
  }

  return true;
}

function shouldProcessDir(dirPath) {
  const dirName = path.basename(dirPath);
  return !EXCLUDED_DIRS.includes(dirName) && !dirName.startsWith('.');
}

function hasCopyrightHeader(content) {
  return content.includes('Copyright (c) 2024 UnderCut.Co') || 
         content.includes('© 2024 UnderCut.Co');
}

function addCopyrightHeader(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');

    // Skip if already has copyright header
    if (hasCopyrightHeader(content)) {
      console.log(`Skipping ${filePath} - already has copyright header`);
      return;
    }

    // Add copyright header at the beginning
    const newContent = COPYRIGHT_HEADER + '\n' + content;
    fs.writeFileSync(filePath, newContent, 'utf8');
    console.log(`Added copyright header to ${filePath}`);
  } catch (error) {
    console.error(`Error processing ${filePath}:`, error.message);
  }
}

function processDirectory(dirPath) {
  const items = fs.readdirSync(dirPath);

  items.forEach(item => {
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      if (shouldProcessDir(fullPath)) {
        processDirectory(fullPath);
      }
    } else if (stat.isFile()) {
      if (shouldProcessFile(fullPath)) {
        addCopyrightHeader(fullPath);
      }
    }
  });
}

// Start processing from src directory
const srcDir = path.join(__dirname, '..', 'src');
if (fs.existsSync(srcDir)) {
  console.log('Adding copyright headers to source files...');
  processDirectory(srcDir);
  console.log('Done!');
} else {
  console.error('src directory not found');
}

