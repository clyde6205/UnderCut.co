import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createStackNavigator} from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {theme} from '../theme/theme';

import HomeScreen from '../screens/main/HomeScreen';
import PostQuoteScreen from '../screens/main/PostQuoteScreen';
import MyQuotesScreen from '../screens/main/MyQuotesScreen';
import TransactionsScreen from '../screens/main/TransactionsScreen';
import ProfileScreen from '../screens/main/ProfileScreen';
import QuoteDetailScreen from '../screens/main/QuoteDetailScreen';
import BidScreen from '../screens/main/BidScreen';
import TransactionDetailScreen from '../screens/main/TransactionDetailScreen';
import TermsScreen from '../screens/main/TermsScreen';
import LegalScreen from '../screens/main/LegalScreen';
import ConfigScreen from '../screens/main/ConfigScreen';
import LanguageScreen from '../screens/main/LanguageScreen';
import ReferralScreen from '../screens/main/ReferralScreen';
import DashboardScreen from '../screens/admin/DashboardScreen';
import ChatListScreen from '../screens/chat/ChatListScreen';
import ChatRoomScreen from '../screens/chat/ChatRoomScreen';
import ChatSubscriptionScreen from '../screens/chat/ChatSubscriptionScreen';
import CopyrightScreen from '../screens/main/CopyrightScreen';
import SupportScreen from '../screens/main/SupportScreen';
import UserProfileScreen from '../screens/main/UserProfileScreen';
import FavoritesScreen from '../screens/main/FavoritesScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const HomeStack = () => (
  <Stack.Navigator>
    <Stack.Screen 
      name="HomeMain" 
      component={HomeScreen}
      options={{title: 'UnderCut.Co', headerShown: false}}
    />
    <Stack.Screen 
      name="QuoteDetail" 
      component={QuoteDetailScreen}
      options={{title: 'Quote Details'}}
    />
    <Stack.Screen 
      name="Bid" 
      component={BidScreen}
      options={{title: 'Place Bid'}}
    />
  </Stack.Navigator>
);

const QuotesStack = () => (
  <Stack.Navigator>
    <Stack.Screen 
      name="MyQuotesMain" 
      component={MyQuotesScreen}
      options={{title: 'My Quotes'}}
    />
    <Stack.Screen 
      name="PostQuote" 
      component={PostQuoteScreen}
      options={{title: 'Post New Quote'}}
    />
    <Stack.Screen 
      name="QuoteDetail" 
      component={QuoteDetailScreen}
      options={{title: 'Quote Details'}}
    />
  </Stack.Navigator>
);

const TransactionsStack = () => (
  <Stack.Navigator>
    <Stack.Screen 
      name="TransactionsMain" 
      component={TransactionsScreen}
      options={{title: 'My Transactions'}}
    />
    <Stack.Screen 
      name="TransactionDetail" 
      component={TransactionDetailScreen}
      options={{title: 'Transaction Details'}}
    />
  </Stack.Navigator>
);

const ProfileStack = () => (
  <Stack.Navigator>
    <Stack.Screen 
      name="ProfileMain" 
      component={ProfileScreen}
      options={{title: 'Profile'}}
    />
    <Stack.Screen 
      name="Terms" 
      component={TermsScreen}
      options={{title: 'Terms of Service'}}
    />
    <Stack.Screen 
      name="Legal" 
      component={LegalScreen}
      options={{title: 'Legal & Disclaimers'}}
    />
    <Stack.Screen 
      name="Config" 
      component={ConfigScreen}
      options={{title: 'Platform Configuration'}}
    />
    <Stack.Screen 
      name="Language" 
      component={LanguageScreen}
      options={{title: 'Select Language'}}
    />
    <Stack.Screen 
      name="Referral" 
      component={ReferralScreen}
      options={{title: 'Referral Program'}}
    />
    <Stack.Screen 
      name="Dashboard" 
      component={DashboardScreen}
      options={{title: 'Founders Console'}}
    />
    <Stack.Screen 
      name="ChatList" 
      component={ChatListScreen}
      options={{title: 'ChatMe.Pro'}}
    />
    <Stack.Screen 
      name="ChatRoom" 
      component={ChatRoomScreen}
      options={{title: 'Chat'}}
    />
    <Stack.Screen 
      name="ChatSubscription" 
      component={ChatSubscriptionScreen}
      options={{title: 'ChatMe.Pro Subscription'}}
    />
    <Stack.Screen 
      name="Copyright" 
      component={CopyrightScreen}
      options={{title: 'Copyright & IP Protection'}}
    />
    <Stack.Screen 
      name="Support" 
      component={SupportScreen}
      options={{title: 'Support'}}
    />
    <Stack.Screen 
      name="UserProfile" 
      component={UserProfileScreen}
      options={{title: 'Profile'}}
    />
    <Stack.Screen 
      name="Favorites" 
      component={FavoritesScreen}
      options={{title: 'Favorites'}}
    />
  </Stack.Navigator>
);

export const MainNavigator: React.FC = () => {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        tabBarIcon: ({focused, color, size}) => {
          let iconName: string;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Quotes') {
            iconName = focused ? 'file-document-edit' : 'file-document-edit-outline';
          } else if (route.name === 'Transactions') {
            iconName = focused ? 'swap-horizontal' : 'swap-horizontal-variant';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'account' : 'account-outline';
          } else {
            iconName = 'help';
          }

          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.textSecondary,
        headerShown: false,
      })}>
      <Tab.Screen name="Home" component={HomeStack} />
      <Tab.Screen name="Quotes" component={QuotesStack} />
      <Tab.Screen name="Transactions" component={TransactionsStack} />
      <Tab.Screen name="Profile" component={ProfileStack} />
    </Tab.Navigator>
  );
};

