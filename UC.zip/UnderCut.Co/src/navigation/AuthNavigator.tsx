import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from '../screens/auth/LoginScreen';
import SignUpScreen from '../screens/auth/SignUpScreen';
import WelcomeScreen from '../screens/auth/WelcomeScreen';
import LanguageScreen from '../screens/main/LanguageScreen';
import ReferralOnboardingScreen from '../screens/auth/ReferralOnboardingScreen';

const Stack = createStackNavigator();

export const AuthNavigator: React.FC = () => {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="SignUp" component={SignUpScreen} />
      <Stack.Screen 
        name="Language" 
        component={LanguageScreen}
        options={{title: 'Select Language'}}
      />
      <Stack.Screen 
        name="ReferralOnboarding" 
        component={ReferralOnboardingScreen}
        options={{title: 'Join via Referral'}}
      />
    </Stack.Navigator>
  );
};

