/**
 * AI Orchestrator Background Worker
 * 
 * Processes AI tasks in background
 * CRITICAL: Only processes non-vital functions
 * 
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {processAITasks} from '../services/aiOrchestrator';

let workerInterval: NodeJS.Timeout | null = null;

/**
 * Start AI orchestrator worker
 */
export const startAIOrchestrator = (): void => {
  if (workerInterval) {
    return; // Already running
  }

  // Process tasks every 30 seconds
  workerInterval = setInterval(async () => {
    try {
      await processAITasks();
    } catch (error) {
      console.error('AI Orchestrator Worker error:', error);
    }
  }, 30000); // 30 seconds

  console.log('AI Orchestrator: Worker started');
};

/**
 * Stop AI orchestrator worker
 */
export const stopAIOrchestrator = (): void => {
  if (workerInterval) {
    clearInterval(workerInterval);
    workerInterval = null;
    console.log('AI Orchestrator: Worker stopped');
  }
};

/**
 * Process tasks immediately (for testing)
 */
export const processTasksNow = async (): Promise<void> => {
  await processAITasks();
};

