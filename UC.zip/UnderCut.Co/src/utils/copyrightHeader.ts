/**
 * Copyright Header Utility
 * 
 * Add this header to all source files for copyright protection.
 * 
 * © 2024 UnderCut.Co. All Rights Reserved.
 * 
 * This software is protected by copyright law. Unauthorized copying,
 * modification, distribution, or use is strictly prohibited.
 */

export const COPYRIGHT_HEADER = `
/**
 * Copyright (c) 2024 UnderCut.Co. All Rights Reserved.
 * 
 * This software is proprietary and confidential. Unauthorized copying,
 * modification, distribution, or use of this software, via any medium,
 * is strictly prohibited and may result in severe civil and criminal penalties.
 * 
 * Protected by copyright law and international treaties.
 */
`;

export const getCopyrightNotice = (): string => {
  return '© 2024 UnderCut.Co. All Rights Reserved.';
};

export const getTrademarkNotice = (): string => {
  return 'UnderCut.Co and ChatMe.Pro are trademarks of UnderCut.Co.';
};

