import {Category, CategoryLevel} from '../types';

export const CATEGORIES: Record<CategoryLevel, Category[]> = {
  luxury: [
    {
      id: 'luxury-vehicles',
      name: 'Luxury Vehicles',
      level: 'luxury',
      icon: 'car-sports',
      description: 'Ferrari, Lamborghini, Rolls-Royce, and other luxury vehicles',
      minPrice: 100000,
      maxPrice: 10000000,
      examples: ['Ferrari', 'Lamborghini', 'Rolls-Royce', 'Bentley', 'Aston Martin'],
    },
    {
      id: 'gold-bullion',
      name: 'Gold Bullion',
      level: 'luxury',
      icon: 'gold',
      description: 'Gold bars, coins, and precious metals',
      minPrice: 50000,
      maxPrice: 5000000,
      examples: ['Gold Bars', 'Gold Coins', 'Platinum', 'Silver Bullion'],
    },
    {
      id: 'real-estate',
      name: 'Real Estate',
      level: 'luxury',
      icon: 'home',
      description: 'Luxury properties, commercial real estate',
      minPrice: 500000,
      maxPrice: 50000000,
      examples: ['Luxury Homes', 'Commercial Properties', 'Estates', 'Penthouses'],
    },
    {
      id: 'luxury-watches',
      name: 'Luxury Watches',
      level: 'luxury',
      icon: 'watch',
      description: 'Rolex, Patek Philippe, and other luxury timepieces',
      minPrice: 10000,
      maxPrice: 1000000,
      examples: ['Rolex', 'Patek Philippe', 'Audemars Piguet', 'Richard Mille'],
    },
    {
      id: 'luxury-jewelry',
      name: 'Luxury Jewelry',
      level: 'luxury',
      icon: 'diamond',
      description: 'High-end jewelry and precious stones',
      minPrice: 10000,
      maxPrice: 5000000,
      examples: ['Diamonds', 'Fine Jewelry', 'Gemstones', 'Designer Pieces'],
    },
  ],
  'mid-level': [
    {
      id: 'electronics',
      name: 'Electronics',
      level: 'mid-level',
      icon: 'laptop',
      description: 'Computers, smartphones, tablets, and tech devices',
      minPrice: 100,
      maxPrice: 50000,
      examples: ['Laptops', 'Smartphones', 'Tablets', 'Gaming Consoles'],
    },
    {
      id: 'vehicles',
      name: 'Vehicles',
      level: 'mid-level',
      icon: 'car',
      description: 'Cars, motorcycles, boats',
      minPrice: 5000,
      maxPrice: 100000,
      examples: ['Cars', 'Motorcycles', 'Boats', 'RVs'],
    },
    {
      id: 'furniture',
      name: 'Furniture',
      level: 'mid-level',
      icon: 'sofa',
      description: 'Home and office furniture',
      minPrice: 100,
      maxPrice: 20000,
      examples: ['Home Furniture', 'Office Furniture', 'Antiques'],
    },
    {
      id: 'appliances',
      name: 'Appliances',
      level: 'mid-level',
      icon: 'washing-machine',
      description: 'Home and kitchen appliances',
      minPrice: 50,
      maxPrice: 10000,
      examples: ['Refrigerators', 'Washers', 'Dryers', 'Dishwashers'],
    },
  ],
  'lower-level': [
    {
      id: 'clothing',
      name: 'Clothing & Apparel',
      level: 'lower-level',
      icon: 'tshirt',
      description: 'Clothing, shoes, accessories',
      minPrice: 10,
      maxPrice: 1000,
      examples: ['Clothing', 'Shoes', 'Accessories', 'Bags'],
    },
    {
      id: 'books',
      name: 'Books & Media',
      level: 'lower-level',
      icon: 'book',
      description: 'Books, movies, music, games',
      minPrice: 10,
      maxPrice: 500,
      examples: ['Books', 'Movies', 'Music', 'Video Games'],
    },
    {
      id: 'home-garden',
      name: 'Home & Garden',
      level: 'lower-level',
      icon: 'flower',
      description: 'Home improvement, gardening supplies',
      minPrice: 10,
      maxPrice: 2000,
      examples: ['Tools', 'Garden Supplies', 'Home Decor'],
    },
    {
      id: 'sports',
      name: 'Sports & Recreation',
      level: 'lower-level',
      icon: 'dumbbell',
      description: 'Sports equipment and recreation items',
      minPrice: 10,
      maxPrice: 5000,
      examples: ['Fitness Equipment', 'Sports Gear', 'Outdoor Equipment'],
    },
  ],
};

export const getCategoryById = (id: string): Category | undefined => {
  for (const level of Object.values(CATEGORIES)) {
    const category = level.find(cat => cat.id === id);
    if (category) return category;
  }
  return undefined;
};

export const getCategoriesByLevel = (level: CategoryLevel): Category[] => {
  return CATEGORIES[level] || [];
};

export const getAllCategories = (): Category[] => {
  return Object.values(CATEGORIES).flat();
};

