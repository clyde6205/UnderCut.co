import AsyncStorage from '@react-native-async-storage/async-storage';

export interface AppConfig {
  // Payment Processor Configuration (Editable)
  paymentProcessor: 'stripe' | 'xrp' | 'custom';
  stripePublishableKey?: string;
  stripeSecretKey?: string;
  xrpApiEndpoint?: string;
  rippleNetwork?: 'mainnet' | 'testnet';
  
  // Transaction Timing (Editable)
  transactionTimeoutHours: number;
  escrowCoolDownHours: number;
  dealClosureGracePeriodHours: number;
  
  // Blockchain Configuration
  blockchainNetwork: 'ethereum' | 'polygon' | 'binance' | 'custom';
  blockchainRpcUrl?: string;
  
  // Platform Configuration
  maxQuoteAmount: number;
  minQuoteAmount: number;
  
  // Firebase Configuration
  useFirebase: boolean;
  firebaseConfig?: {
    apiKey: string;
    authDomain: string;
    projectId: string;
    storageBucket: string;
    messagingSenderId: string;
    appId: string;
  };
  
  // AWS Configuration (for future scaling)
  useAws: boolean;
  awsRegion?: string;
  awsApiEndpoint?: string;
  
  // Translation Configuration
  useTranslationAPI: boolean;
  translationAPIKey?: string;
  translationAPIProvider?: 'google' | 'azure' | 'aws' | 'custom';
  
  // Support Configuration (Editable)
  supportEmail: string;
  supportPhone?: string;
  supportHours?: string;
}

const DEFAULT_CONFIG: AppConfig = {
  paymentProcessor: 'stripe',
  transactionTimeoutHours: 72, // Editable - 3 days default
  escrowCoolDownHours: 24,
  dealClosureGracePeriodHours: 12,
  blockchainNetwork: 'ethereum',
  maxQuoteAmount: 10000000, // $10M max
  minQuoteAmount: 10, // $10 min
  useFirebase: true,
  useAws: false,
  useTranslationAPI: true,
  translationAPIProvider: 'google',
  // Support Configuration
  supportEmail: 'clydeusa@zohomail.com',
};

const CONFIG_STORAGE_KEY = '@UndercutCo:AppConfig';

let cachedConfig: AppConfig | null = null;

export const loadConfig = async (): Promise<AppConfig> => {
  if (cachedConfig) {
    return cachedConfig;
  }

  try {
    const storedConfig = await AsyncStorage.getItem(CONFIG_STORAGE_KEY);
    if (storedConfig) {
      cachedConfig = {...DEFAULT_CONFIG, ...JSON.parse(storedConfig)};
      return cachedConfig;
    }
  } catch (error) {
    console.error('Error loading config:', error);
  }

  cachedConfig = DEFAULT_CONFIG;
  return cachedConfig;
};

export const saveConfig = async (config: Partial<AppConfig>): Promise<void> => {
  try {
    const currentConfig = await loadConfig();
    const updatedConfig = {...currentConfig, ...config};
    await AsyncStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(updatedConfig));
    cachedConfig = updatedConfig;
  } catch (error) {
    console.error('Error saving config:', error);
    throw error;
  }
};

export const getConfig = (): AppConfig => {
  if (!cachedConfig) {
    return DEFAULT_CONFIG;
  }
  return cachedConfig;
};

export const updateTransactionTimeout = async (hours: number): Promise<void> => {
  await saveConfig({transactionTimeoutHours: hours});
};

export const updatePaymentProcessor = async (processor: 'stripe' | 'xrp' | 'custom'): Promise<void> => {
  await saveConfig({paymentProcessor: processor});
};

export const updateEscrowCoolDown = async (hours: number): Promise<void> => {
  await saveConfig({escrowCoolDownHours: hours});
};

export const updateSupportEmail = async (email: string): Promise<void> => {
  await saveConfig({supportEmail: email});
};

export const updateSupportPhone = async (phone: string): Promise<void> => {
  await saveConfig({supportPhone: phone});
};

export const updateSupportHours = async (hours: string): Promise<void> => {
  await saveConfig({supportHours: hours});
};

