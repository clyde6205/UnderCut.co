export type UserRole = 'buyer' | 'seller' | 'admin' | 'founder';
export type CategoryLevel = 'luxury' | 'mid-level' | 'lower-level';
export type TransactionStatus = 
  | 'pending' 
  | 'quote_posted' 
  | 'bids_received' 
  | 'accepted' 
  | 'escrow_initiated' 
  | 'payment_processing' 
  | 'completed' 
  | 'cancelled' 
  | 'disputed';

export type PaymentMethod = 'stripe' | 'xrp';

export interface User {
  id: string;
  email: string;
  displayName: string;
  role: UserRole;
  verified: boolean;
  createdAt: Date;
  profileImage?: string;
  location?: {
    country: string;
    city?: string;
  };
  rating?: number;
  totalTransactions?: number;
  referralCode?: string;
  referredBy?: string;
  referralCount?: number;
  totalReferralEarnings?: number;
  chatSubscription?: {
    subscribed: boolean;
    subscribedAt?: Date;
    expiresAt?: Date;
    lastPlatformUsage?: Date;
    usageWarningSent?: boolean;
  };
  // New fields for seller trust metrics
  sellerMetrics?: {
    averageResponseTime?: number; // minutes
    totalBids?: number;
    acceptedBids?: number;
    completionRate?: number;
    verifiedSeller?: boolean;
    responseTimeMinutes?: number;
  };
  buyerMetrics?: {
    totalQuotes?: number;
    completedPurchases?: number;
    averageCommitmentDeposit?: number;
    seriousBuyer?: boolean;
  };
  // Favorites system
  favorites?: string[]; // Array of user IDs
}

export interface Quote {
  id: string;
  buyerId: string;
  buyerName: string;
  title: string;
  description: string;
  category: string;
  categoryLevel: CategoryLevel;
  maxPrice: number;
  currency: string;
  images?: string[];
  specifications?: Record<string, any>;
  location?: {
    country: string;
    city?: string;
  };
  expiresAt: Date;
  createdAt: Date;
  status: TransactionStatus;
  minimumBids?: number;
  // New fields for commitment and action
  buyerCommitmentDeposit?: number;
  buyerCommitted: boolean;
  urgencyLevel?: 'normal' | 'urgent' | 'asap';
  preferredDeliveryDate?: Date;
  quantity?: number;
}

export interface Bid {
  id: string;
  quoteId: string;
  sellerId: string;
  sellerName: string;
  price: number;
  currency: string;
  message?: string;
  deliveryTime?: string;
  warranty?: string;
  conditions?: string[];
  createdAt: Date;
  isSelected: boolean;
  // New fields for seller trust
  sellerRating?: number;
  sellerVerified?: boolean;
  sellerResponseTime?: number; // in minutes
  estimatedDeliveryDate?: Date;
  stockAvailable?: boolean;
  sellerLocation?: string;
}

export interface Transaction {
  id: string;
  quoteId: string;
  bidId: string;
  buyerId: string;
  sellerId: string;
  amount: number;
  currency: string;
  paymentMethod: PaymentMethod;
  status: TransactionStatus;
  escrowAddress?: string;
  blockchainTxHash?: string;
  createdAt: Date;
  expiresAt: Date;
  completedAt?: Date;
  coolDownEndsAt?: Date;
  categoryLevel: CategoryLevel;
  termsAccepted: boolean;
  // New fields for delivery tracking
  deliveryTracking?: {
    carrier?: string;
    trackingNumber?: string;
    estimatedDelivery?: Date;
    shippedAt?: Date;
    deliveredAt?: Date;
    status: 'pending' | 'preparing' | 'shipped' | 'in_transit' | 'delivered';
  };
  review?: {
    buyerReview?: Review;
    sellerReview?: Review;
  };
}

export interface Review {
  id: string;
  transactionId: string;
  reviewerId: string;
  revieweeId: string;
  rating: number; // 1-5
  comment?: string;
  createdAt: Date;
  helpful?: number;
}

export interface PriceAlert {
  id: string;
  userId: string;
  quoteId: string;
  alertType: 'new_bid' | 'price_drop' | 'expiring_soon' | 'best_price';
  thresholdPrice?: number;
  isActive: boolean;
  createdAt: Date;
}

export interface MarketInsight {
  category: string;
  averagePrice: number;
  lowestPrice: number;
  highestPrice: number;
  totalQuotes: number;
  totalBids: number;
  priceTrend: 'up' | 'down' | 'stable';
  lastUpdated: Date;
}

export interface EscrowDetails {
  transactionId: string;
  escrowAddress: string;
  amount: number;
  currency: string;
  blockchainTxHash: string;
  initiatedAt: Date;
  expiresAt: Date;
  status: 'pending' | 'held' | 'released' | 'refunded';
}

export interface Category {
  id: string;
  name: string;
  level: CategoryLevel;
  icon?: string;
  description?: string;
  minPrice?: number;
  maxPrice?: number;
  examples?: string[];
}

export interface BlockchainTransaction {
  txHash: string;
  blockNumber: number;
  from: string;
  to: string;
  amount: string;
  timestamp: Date;
  status: 'pending' | 'confirmed' | 'failed';
  network: string;
}

export interface AITask {
  id: string;
  type: 'routing' | 'organization' | 'notification' | 'matching' | 'blockchain_prep' | 'analytics' | 'optimization';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  data: Record<string, any>;
  createdAt: Date;
  completedAt?: Date;
  error?: string;
}

