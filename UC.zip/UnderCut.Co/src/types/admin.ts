import {User, Transaction, Quote, Bid} from './index';

export interface PlatformAnalytics {
  totalUsers: number;
  activeUsers: number;
  totalBuyers: number;
  totalSellers: number;
  totalQuotes: number;
  totalBids: number;
  totalTransactions: number;
  completedTransactions: number;
  totalTransactionVolume: number;
  averageTransactionValue: number;
  platformRevenue: number;
  activeReferrals: number;
  newUsersToday: number;
  newUsersThisWeek: number;
  newUsersThisMonth: number;
  transactionsToday: number;
  transactionsThisWeek: number;
  transactionsThisMonth: number;
  topCategories: Array<{category: string; count: number; volume: number}>;
  topCountries: Array<{country: string; users: number; transactions: number}>;
  userGrowth: Array<{date: string; count: number}>;
  transactionGrowth: Array<{date: string; count: number; volume: number}>;
}

export interface AdminUser extends User {
  permissions: string[];
  lastLoginAt?: Date;
  loginCount: number;
}

export interface ReferralData {
  id: string;
  referrerId: string;
  referrerName: string;
  referredUserId: string;
  referredUserName: string;
  referralCode: string;
  status: 'pending' | 'completed' | 'rewarded';
  createdAt: Date;
  completedAt?: Date;
  rewardAmount?: number;
  transactionId?: string;
}

export interface PlatformSettings {
  maintenanceMode: boolean;
  registrationEnabled: boolean;
  transactionTimeoutHours: number;
  escrowCoolDownHours: number;
  platformFeePercentage: number;
  referralRewardAmount: number;
  minReferralTransactions: number;
  maxQuotesPerUser: number;
  maxBidsPerQuote: number;
}

export interface AdminAction {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  targetType: 'user' | 'transaction' | 'quote' | 'bid' | 'platform';
  targetId: string;
  details: Record<string, any>;
  timestamp: Date;
  ipAddress?: string;
}

