export interface ChatMessage {
  id: string;
  chatRoomId: string;
  senderId: string;
  senderName: string;
  text: string;
  createdAt: Date;
  read: boolean;
  readAt?: Date;
}

export interface ChatRoom {
  id: string;
  participantIds: string[];
  participantNames: Record<string, string>;
  lastMessage?: ChatMessage;
  lastMessageAt?: Date;
  createdAt: Date;
  relatedQuoteId?: string;
  relatedTransactionId?: string;
  type: 'quote' | 'transaction' | 'general';
  unreadCount?: Record<string, number>;
}

export interface ChatSubscription {
  userId: string;
  subscribed: boolean;
  subscribedAt: Date;
  expiresAt?: Date;
  subscriptionType: 'monthly' | 'yearly' | 'lifetime';
  lastPaymentDate?: Date;
  nextPaymentDate?: Date;
  autoRenew: boolean;
}

export interface PlatformUsage {
  userId: string;
  lastQuotePost?: Date;
  lastBidSubmission?: Date;
  lastTransactionCompletion?: Date;
  lastPlatformActivity?: Date;
  totalQuotesPosted: number;
  totalBidsSubmitted: number;
  totalTransactionsCompleted: number;
  chatUsageEligible: boolean;
  warningSentAt?: Date;
}

