import React, {useState, useEffect} from 'react';
import {TouchableOpacity, Text, StyleSheet, ActivityIndicator, Alert} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useNavigation} from '@react-navigation/native';
import {useAuth} from '../contexts/AuthContext';
import {hasActiveChatSubscription, getOrCreateChatRoom} from '../services/chatMePro';
import {theme} from '../theme/theme';

interface StartChatButtonProps {
  recipientId: string;
  recipientName: string;
  type?: 'quote' | 'transaction' | 'general';
  relatedQuoteId?: string;
  relatedTransactionId?: string;
}

export const StartChatButton: React.FC<StartChatButtonProps> = ({
  recipientId,
  recipientName,
  type = 'general',
  relatedQuoteId,
  relatedTransactionId,
}) => {
  const navigation = useNavigation();
  const {user} = useAuth();
  const [loading, setLoading] = useState(false);
  const [canChat, setCanChat] = useState(false);

  useEffect(() => {
    checkChatAccess();
  }, [user]);

  const checkChatAccess = async () => {
    if (!user) return;

    try {
      const hasAccess = await hasActiveChatSubscription(user.id);
      setCanChat(hasAccess);
    } catch (error) {
      console.error('Error checking chat access:', error);
    }
  };

  const handleStartChat = async () => {
    if (!user) {
      Alert.alert('Error', 'You must be logged in to start a chat');
      return;
    }

    if (!canChat) {
      Alert.alert(
        'Chat Subscription Required',
        'You need to subscribe to ChatMe.Pro to start chatting. Would you like to subscribe?',
        [
          {text: 'Cancel', style: 'cancel'},
          {
            text: 'Subscribe',
            onPress: () => navigation.navigate('ChatSubscription' as never),
          },
        ]
      );
      return;
    }

    setLoading(true);
    try {
      const chatRoomId = await getOrCreateChatRoom(
        user.id,
        recipientId,
        user.displayName,
        recipientName,
        type,
        relatedQuoteId,
        relatedTransactionId
      );

      navigation.navigate('ChatRoom' as never, {
        chatRoomId,
        recipientName,
      } as never);
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to start chat');
    } finally {
      setLoading(false);
    }
  };

  return (
    <TouchableOpacity
      style={[styles.button, !canChat && styles.buttonDisabled]}
      onPress={handleStartChat}
      disabled={loading}>
      {loading ? (
        <ActivityIndicator size="small" color={theme.colors.background} />
      ) : (
        <>
          <Icon name="chat-processing" size={16} color={theme.colors.background} />
          <Text style={styles.buttonText}>ChatMe.Pro</Text>
        </>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.info,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: theme.colors.background,
    fontSize: 14,
    fontWeight: '600',
    marginLeft: theme.spacing.xs,
  },
});

