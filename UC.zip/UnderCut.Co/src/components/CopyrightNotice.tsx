import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useNavigation} from '@react-navigation/native';
import {theme} from '../theme/theme';

interface CopyrightNoticeProps {
  variant?: 'full' | 'compact' | 'minimal';
  showOnScroll?: boolean;
}

export const CopyrightNotice: React.FC<CopyrightNoticeProps> = ({
  variant = 'compact',
  showOnScroll = false,
}) => {
  const navigation = useNavigation();

  if (variant === 'minimal') {
    return (
      <Text style={styles.minimalText}>
        © 2024 UnderCut.Co. All Rights Reserved.
      </Text>
    );
  }

  if (variant === 'compact') {
    return (
      <View style={styles.compactContainer}>
        <Icon name="copyright" size={12} color={theme.colors.textSecondary} />
        <Text style={styles.compactText}>
          © 2024 UnderCut.Co. All Rights Reserved.{' '}
          <Text style={styles.linkText} onPress={() => navigation.navigate('Copyright' as never)}>
            Legal
          </Text>
        </Text>
      </View>
    );
  }

  // Full variant
  return (
    <View style={styles.fullContainer}>
      <View style={styles.header}>
        <Icon name="shield-check" size={24} color={theme.colors.primary} />
        <Text style={styles.title}>Copyright & Intellectual Property</Text>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.paragraph}>
          <Text style={styles.bold}>© 2024 UnderCut.Co. All Rights Reserved.</Text>
        </Text>
        
        <Text style={styles.paragraph}>
          This platform, including all software, designs, logos, and content, is protected by 
          copyright, trademark, and other intellectual property laws. Unauthorized copying, 
          modification, distribution, or cloning of this platform is strictly prohibited.
        </Text>
        
        <View style={styles.warningBox}>
          <Icon name="alert-circle" size={20} color={theme.colors.warning} />
          <Text style={styles.warningText}>
            <Text style={styles.bold}>Notice:</Text> This platform includes code protection, 
            watermarking, and monitoring systems. Unauthorized use may result in legal action.
          </Text>
        </View>
        
        <Text style={styles.paragraph}>
          <Text style={styles.bold}>UnderCut.Co</Text> and <Text style={styles.bold}>ChatMe.Pro</Text> are 
          trademarks of UnderCut.Co. Unauthorized use of these trademarks is prohibited.
        </Text>
        
        <TouchableOpacity
          style={styles.legalButton}
          onPress={() => navigation.navigate('Copyright' as never)}>
          <Text style={styles.legalButtonText}>View Full Legal Information</Text>
          <Icon name="arrow-right" size={16} color={theme.colors.primary} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  minimalText: {
    fontSize: 10,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  compactContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: theme.spacing.sm,
    paddingHorizontal: theme.spacing.md,
  },
  compactText: {
    fontSize: 11,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
  },
  linkText: {
    color: theme.colors.primary,
    textDecorationLine: 'underline',
  },
  fullContainer: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    margin: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
  },
  content: {
    marginTop: theme.spacing.sm,
  },
  paragraph: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 20,
    marginBottom: theme.spacing.md,
  },
  bold: {
    fontWeight: '700',
  },
  warningBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.warning + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.warning + '40',
  },
  warningText: {
    flex: 1,
    fontSize: 13,
    color: theme.colors.text,
    lineHeight: 18,
    marginLeft: theme.spacing.sm,
  },
  legalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: theme.spacing.sm,
    paddingVertical: theme.spacing.sm,
  },
  legalButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.primary,
    marginRight: theme.spacing.xs,
  },
});

