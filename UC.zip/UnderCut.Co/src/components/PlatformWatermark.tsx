import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {WATERMARK, validatePlatform} from '../services/codeProtection';
import {theme} from '../theme/theme';

/**
 * Platform Watermark Component
 * 
 * This component displays the platform watermark and copyright notice.
 * DO NOT REMOVE - Part of intellectual property protection.
 * 
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

interface PlatformWatermarkProps {
  visible?: boolean;
  position?: 'top' | 'bottom' | 'corner';
}

export const PlatformWatermark: React.FC<PlatformWatermarkProps> = ({
  visible = true,
  position = 'bottom',
}) => {
  if (!visible) return null;

  // Validate platform on render
  const isValid = validatePlatform();

  if (position === 'corner') {
    return (
      <View style={styles.cornerWatermark} pointerEvents="none">
        <Text style={styles.cornerText}>
          {WATERMARK.copyright} {WATERMARK.platform}
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.watermark, position === 'top' ? styles.top : styles.bottom]}>
      <Text style={styles.watermarkText}>
        © {WATERMARK.copyright} {WATERMARK.platform}. All Rights Reserved.
      </Text>
      {!isValid && (
        <Text style={styles.warningText}>Unauthorized Platform Detected</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  watermark: {
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.sm,
    backgroundColor: theme.colors.surface,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  top: {
    borderTopWidth: 0,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  bottom: {
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  watermarkText: {
    fontSize: 10,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  warningText: {
    fontSize: 9,
    color: theme.colors.error,
    textAlign: 'center',
    marginTop: theme.spacing.xs,
    fontWeight: '700',
  },
  cornerWatermark: {
    position: 'absolute',
    bottom: theme.spacing.sm,
    right: theme.spacing.sm,
    backgroundColor: theme.colors.background + 'CC',
    paddingHorizontal: theme.spacing.xs,
    paddingVertical: 2,
    borderRadius: theme.borderRadius.sm,
    opacity: 0.6,
  },
  cornerText: {
    fontSize: 8,
    color: theme.colors.textSecondary,
  },
});

