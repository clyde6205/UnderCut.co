import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Quote, CategoryLevel} from '../types';
import {theme} from '../theme/theme';
import {format} from 'date-fns';

interface QuoteCardProps {
  quote: Quote;
  onPress: () => void;
  showBidButton?: boolean;
  onBid?: () => void;
}

export const QuoteCard: React.FC<QuoteCardProps> = ({
  quote,
  onPress,
  showBidButton = false,
  onBid,
}) => {
  const getCategoryColor = (level: CategoryLevel) => {
    switch (level) {
      case 'luxury':
        return theme.colors.categoryLuxury;
      case 'mid-level':
        return theme.colors.categoryMidLevel;
      case 'lower-level':
        return theme.colors.categoryLowerLevel;
      default:
        return theme.colors.textSecondary;
    }
  };

  const getCategoryLabel = (level: CategoryLevel) => {
    switch (level) {
      case 'luxury':
        return 'Luxury';
      case 'mid-level':
        return 'Mid-Level';
      case 'lower-level':
        return 'Lower-Level';
      default:
        return '';
    }
  };

  const timeRemaining = Math.max(0, quote.expiresAt.getTime() - Date.now());
  const hoursRemaining = Math.floor(timeRemaining / (1000 * 60 * 60));
  const isExpiringSoon = hoursRemaining < 24;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <View style={styles.categoryBadge}>
          <View
            style={[
              styles.categoryDot,
              {backgroundColor: getCategoryColor(quote.categoryLevel)},
            ]}
          />
          <Text style={styles.categoryText}>
            {getCategoryLabel(quote.categoryLevel)}
          </Text>
        </View>
        <View
          style={[
            styles.timeBadge,
            isExpiringSoon && styles.timeBadgeWarning,
          ]}>
          <Icon
            name="clock-outline"
            size={14}
            color={isExpiringSoon ? theme.colors.error : theme.colors.textSecondary}
          />
          <Text
            style={[
              styles.timeText,
              isExpiringSoon && styles.timeTextWarning,
            ]}>
            {hoursRemaining}h left
          </Text>
        </View>
      </View>

      <Text style={styles.title}>{quote.title}</Text>
      <Text style={styles.description} numberOfLines={2}>
        {quote.description}
      </Text>

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Icon name="tag" size={16} color={theme.colors.textSecondary} />
          <Text style={styles.detailText}>{quote.category}</Text>
        </View>
        {quote.location && (
          <View style={styles.detailRow}>
            <Icon name="map-marker" size={16} color={theme.colors.textSecondary} />
            <Text style={styles.detailText}>
              {quote.location.city || quote.location.country}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.footer}>
        <View>
          <Text style={styles.priceLabel}>Max Price</Text>
          <Text style={styles.price}>
            {quote.currency} {quote.maxPrice.toLocaleString()}
          </Text>
        </View>
        {showBidButton && (
          <TouchableOpacity
            style={styles.bidButton}
            onPress={(e) => {
              e.stopPropagation();
              onBid?.();
            }}>
            <Text style={styles.bidButtonText}>Place Bid</Text>
            <Icon name="arrow-right" size={16} color={theme.colors.background} />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.buyerInfo}>
        <Icon name="account-circle" size={16} color={theme.colors.textSecondary} />
        <Text style={styles.buyerText}>Posted by {quote.buyerName}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: theme.spacing.xs,
  },
  categoryText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    textTransform: 'uppercase',
  },
  timeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
    backgroundColor: theme.colors.surface,
  },
  timeBadgeWarning: {
    backgroundColor: theme.colors.error + '20',
  },
  timeText: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
    fontWeight: '600',
  },
  timeTextWarning: {
    color: theme.colors.error,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  description: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    lineHeight: 20,
    marginBottom: theme.spacing.sm,
  },
  details: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: theme.spacing.sm,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: theme.spacing.md,
    marginBottom: theme.spacing.xs,
  },
  detailText: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: theme.spacing.sm,
    paddingTop: theme.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  priceLabel: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  price: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.primary,
  },
  bidButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
  },
  bidButtonText: {
    color: theme.colors.background,
    fontSize: 14,
    fontWeight: '600',
    marginRight: theme.spacing.xs,
  },
  buyerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.sm,
    paddingTop: theme.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  buyerText: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
  },
});

