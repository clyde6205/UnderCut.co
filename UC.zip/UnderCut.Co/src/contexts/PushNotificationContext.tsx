import React, {createContext, useContext, useEffect, ReactNode} from 'react';
import {Alert} from 'react-native';
import {
  initializePushNotifications,
  setupForegroundMessageHandler,
  setupNotificationOpenedHandler,
  saveFCMToken,
} from '../services/pushNotifications';
import {useAuth} from './AuthContext';

interface PushNotificationContextType {
  // Context for push notifications
}

const PushNotificationContext = createContext<PushNotificationContextType | undefined>(undefined);

export const PushNotificationProvider: React.FC<{children: ReactNode}> = ({children}) => {
  const {user} = useAuth();

  useEffect(() => {
    // Initialize push notifications when user is logged in
    if (user) {
      initializePushNotifications(user.id);
      saveFCMToken(user.id);
    }
  }, [user]);

  useEffect(() => {
    // Setup foreground message handler
    const unsubscribeForeground = setupForegroundMessageHandler((message) => {
      // Handle foreground notifications
      if (message.notification) {
        Alert.alert(
          message.notification.title || 'New Message',
          message.notification.body || '',
          [{text: 'OK'}]
        );
      }
    });

    // Setup notification opened handler
    const unsubscribeOpened = setupNotificationOpenedHandler((message) => {
      // Handle notification opened
      console.log('Notification opened:', message);
      // Navigate to chat room if chat message
      if (message.data?.chatRoomId) {
        // Navigation handled by app state
      }
    });

    return () => {
      unsubscribeForeground();
      unsubscribeOpened();
    };
  }, []);

  return (
    <PushNotificationContext.Provider value={{}}>
      {children}
    </PushNotificationContext.Provider>
  );
};

export const usePushNotifications = (): PushNotificationContextType => {
  const context = useContext(PushNotificationContext);
  if (!context) {
    return {}; // Return empty object if not in provider
  }
  return context;
};

