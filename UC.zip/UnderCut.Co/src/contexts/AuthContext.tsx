import React, {createContext, useContext, useState, useEffect, ReactNode} from 'react';
import {FirebaseAuthTypes} from '@react-native-firebase/auth';
import {auth, firestore} from '../services/firebase';
import {User} from '../types';
import {
  loadUserDataOptimized,
  fastSignOut,
  cacheUserData,
  getCachedUserData,
} from '../services/authOptimized';

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseAuthTypes.User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, displayName: string, role: 'buyer' | 'seller', referralCode?: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{children: ReactNode}> = ({children}) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseAuthTypes.User | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load cached user immediately for instant UI
    getCachedUserData().then(cachedUser => {
      if (cachedUser) {
        setUser(cachedUser);
      }
      setLoading(false);
    });

    // Listen for auth changes
    const unsubscribe = auth().onAuthStateChanged(async (firebaseUser) => {
      setFirebaseUser(firebaseUser);
      if (firebaseUser) {
        // Load from cache first, then refresh
        const cached = await getCachedUserData();
        if (cached && cached.id === firebaseUser.uid) {
          setUser(cached);
          setLoading(false);
          // Refresh in background
          loadUserDataOptimized(firebaseUser.uid, false).then(freshUser => {
            if (freshUser) {
              setUser(freshUser);
            }
          });
        } else {
          // No cache, load fresh
          const userData = await loadUserDataOptimized(firebaseUser.uid, false);
          setUser(userData);
          setLoading(false);
        }
      } else {
        setUser(null);
        setLoading(false);
      }
    });

    return unsubscribe;
  }, []);

  const loadUserData = async (uid: string) => {
    const userData = await loadUserDataOptimized(uid);
    if (userData) {
      setUser(userData);
    }
  };

  const signIn = async (email: string, password: string) => {
    // Sign in - auth state listener will handle user loading
    const userCredential = await auth().signInWithEmailAndPassword(email, password);
    // Pre-load user data for instant access
    const userData = await loadUserDataOptimized(userCredential.user.uid);
    if (userData) {
      setUser(userData);
    }
  };

  const signUp = async (email: string, password: string, displayName: string, role: 'buyer' | 'seller', referralCode?: string) => {
    const userCredential = await auth().createUserWithEmailAndPassword(email, password);
    await userCredential.user.updateProfile({displayName});
    
    await firestore().collection('users').doc(userCredential.user.uid).set({
      email,
      displayName,
      role,
      verified: false,
      createdAt: firestore.FieldValue.serverTimestamp(),
      totalTransactions: 0,
      referralCount: 0,
      totalReferralEarnings: 0,
    });

    // Process referral if code provided
    if (referralCode) {
      try {
        const {processReferral} = await import('../services/referral');
        await processReferral(userCredential.user.uid, referralCode);
      } catch (error) {
        console.error('Error processing referral:', error);
        // Don't fail signup if referral processing fails
      }
    }

    await loadUserData(userCredential.user.uid);
  };

  const signOut = async () => {
    // Fast sign out - clear cache immediately
    await fastSignOut();
    setUser(null);
    setFirebaseUser(null);
  };

  const updateProfile = async (updates: Partial<User>) => {
    if (!firebaseUser) return;

    try {
      await firestore().collection('users').doc(firebaseUser.uid).update(updates);
      const updatedUser = await loadUserDataOptimized(firebaseUser.uid, false);
      if (updatedUser) {
        setUser(updatedUser);
        await cacheUserData(updatedUser);
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{user, firebaseUser, loading, signIn, signUp, signOut, updateProfile}}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

