import React, {createContext, useContext, useState, useEffect, ReactNode} from 'react';
import {AppConfig, loadConfig, saveConfig, updateTransactionTimeout, updatePaymentProcessor} from '../config/appConfig';

interface ConfigContextType {
  config: AppConfig | null;
  loading: boolean;
  updateConfig: (updates: Partial<AppConfig>) => Promise<void>;
  updateTimeout: (hours: number) => Promise<void>;
  updatePayment: (processor: 'stripe' | 'xrp' | 'custom') => Promise<void>;
  refreshConfig: () => Promise<void>;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

export const ConfigProvider: React.FC<{children: ReactNode}> = ({children}) => {
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshConfig = async () => {
    try {
      const loadedConfig = await loadConfig();
      setConfig(loadedConfig);
    } catch (error) {
      console.error('Error refreshing config:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshConfig();
  }, []);

  const updateConfig = async (updates: Partial<AppConfig>) => {
    try {
      await saveConfig(updates);
      await refreshConfig();
    } catch (error) {
      console.error('Error updating config:', error);
      throw error;
    }
  };

  const updateTimeout = async (hours: number) => {
    await updateTransactionTimeout(hours);
    await refreshConfig();
  };

  const updatePayment = async (processor: 'stripe' | 'xrp' | 'custom') => {
    await updatePaymentProcessor(processor);
    await refreshConfig();
  };

  return (
    <ConfigContext.Provider value={{config, loading, updateConfig, updateTimeout, updatePayment, refreshConfig}}>
      {children}
    </ConfigContext.Provider>
  );
};

export const useConfig = (): ConfigContextType => {
  const context = useContext(ConfigContext);
  if (!context) {
    throw new Error('useConfig must be used within a ConfigProvider');
  }
  return context;
};

