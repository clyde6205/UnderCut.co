import React, {createContext, useContext, useState, useEffect, ReactNode} from 'react';
import {changeLanguage, getCurrentLanguage, SUPPORTED_LANGUAGES, translateText} from '../services/translation';
import {useTranslation} from 'react-i18next';

interface LanguageContextType {
  currentLanguage: string;
  supportedLanguages: typeof SUPPORTED_LANGUAGES;
  changeLanguage: (languageCode: string) => Promise<void>;
  translateText: (text: string, targetLanguage?: string) => Promise<string>;
  t: (key: string, options?: any) => string;
  isLoading: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{children: ReactNode}> = ({children}) => {
  const {t, i18n} = useTranslation();
  const [currentLanguage, setCurrentLanguage] = useState<string>(getCurrentLanguage());
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setCurrentLanguage(i18n.language);
  }, [i18n.language]);

  const handleChangeLanguage = async (languageCode: string) => {
    setIsLoading(true);
    try {
      await changeLanguage(languageCode);
      setCurrentLanguage(languageCode);
    } catch (error) {
      console.error('Error changing language:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        supportedLanguages: SUPPORTED_LANGUAGES,
        changeLanguage: handleChangeLanguage,
        translateText,
        t,
        isLoading,
      }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

