import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAuth} from '../../contexts/AuthContext';
import {useLanguage} from '../../contexts/LanguageContext';
import {
  subscribeToUserChatRooms,
  hasActiveChatSubscription,
  unsubscribeFromUserChatRooms,
} from '../../services/chatMePro';
import {ChatRoom} from '../../types/chat';
import {theme} from '../../theme/theme';
import {format} from 'date-fns';

const ChatListScreen: React.FC = () => {
  const navigation = useNavigation();
  const {user} = useAuth();
  const {t} = useLanguage();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasSubscription, setHasSubscription] = useState(false);

  useEffect(() => {
    checkSubscriptionAndLoadRooms();
    
    // Cleanup subscription on unmount
    return () => {
      if (unsubscribeRef) {
        unsubscribeRef();
      }
    };
  }, [user]);

  const checkSubscriptionAndLoadRooms = async () => {
    if (!user) return;

    try {
      const subscribed = await hasActiveChatSubscription(user.id);
      setHasSubscription(subscribed);

      if (subscribed) {
        // Subscribe to real-time chat rooms (no cold start)
        const unsubscribe = subscribeToChatRooms();
        setUnsubscribeRef(() => unsubscribe);
      }
    } catch (error) {
      console.error('Error checking subscription:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToChatRooms = () => {
    if (!user) return;

    // Real-time subscription - loads from cache instantly, then syncs
    const unsubscribe = subscribeToUserChatRooms(user.id, (rooms) => {
      setChatRooms(rooms);
    });

    // Store unsubscribe function for cleanup
    return unsubscribe;
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  if (!hasSubscription) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Icon name="arrow-left" size={24} color={theme.colors.text} />
          </TouchableOpacity>
          <Text style={styles.title}>ChatMe.Pro</Text>
        </View>

        <View style={styles.subscriptionRequired}>
          <Icon name="chat-processing" size={64} color={theme.colors.primary} />
          <Text style={styles.subscriptionTitle}>Subscription Required</Text>
          <Text style={styles.subscriptionText}>
            ChatMe.Pro is a subscription-based communication platform for buyers and sellers.
          </Text>
          <Text style={styles.subscriptionText}>
            Subscribe to start chatting with other platform users.
          </Text>

          <TouchableOpacity
            style={styles.subscribeButton}
            onPress={() => navigation.navigate('ChatSubscription' as never)}>
            <Text style={styles.subscribeButtonText}>Subscribe to ChatMe.Pro</Text>
            <Icon name="arrow-right" size={20} color={theme.colors.background} />
          </TouchableOpacity>

          <View style={styles.disclaimerBox}>
            <Icon name="alert-circle" size={20} color={theme.colors.warning} />
            <Text style={styles.disclaimerText}>
              <Text style={styles.bold}>Important:</Text> Chat access requires active platform usage.
              If you do not use the platform for its intended purposes (posting quotes, submitting
              bids, completing transactions) for 6 months, chat access will be removed to protect
              our buyers and sellers from casual users.
            </Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>ChatMe.Pro</Text>
        <TouchableOpacity
          style={styles.settingsButton}
          onPress={() => navigation.navigate('ChatSubscription' as never)}>
          <Icon name="cog" size={24} color={theme.colors.text} />
        </TouchableOpacity>
      </View>

      {chatRooms.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Icon name="chat-outline" size={64} color={theme.colors.textSecondary} />
          <Text style={styles.emptyText}>No chats yet</Text>
          <Text style={styles.emptySubtext}>
            Start a conversation by tapping on a user's profile
          </Text>
        </View>
      ) : (
        <FlatList
          data={chatRooms}
          keyExtractor={item => item.id}
          renderItem={({item}) => {
            const otherParticipantId = item.participantIds.find(id => id !== user?.id);
            const otherParticipantName = otherParticipantId
              ? item.participantNames[otherParticipantId]
              : 'Unknown';

            return (
              <TouchableOpacity
                style={styles.chatRoomItem}
                onPress={() =>
                  navigation.navigate('ChatRoom' as never, {chatRoomId: item.id} as never)
                }>
                <View style={styles.avatar}>
                  <Icon name="account-circle" size={48} color={theme.colors.primary} />
                </View>
                <View style={styles.chatRoomContent}>
                  <View style={styles.chatRoomHeader}>
                    <Text style={styles.chatRoomName}>{otherParticipantName}</Text>
                    {item.lastMessageAt && (
                      <Text style={styles.chatRoomTime}>
                        {format(item.lastMessageAt, 'MMM dd')}
                      </Text>
                    )}
                  </View>
                  {item.lastMessage && (
                    <Text style={styles.lastMessage} numberOfLines={1}>
                      {item.lastMessage.text}
                    </Text>
                  )}
                  {item.type !== 'general' && (
                    <View style={styles.typeBadge}>
                      <Icon
                        name={item.type === 'quote' ? 'file-document' : 'swap-horizontal'}
                        size={12}
                        color={theme.colors.textSecondary}
                      />
                      <Text style={styles.typeText}>
                        {item.type === 'quote' ? 'Quote' : 'Transaction'}
                      </Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  title: {
    flex: 1,
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.text,
  },
  settingsButton: {
    marginLeft: theme.spacing.md,
  },
  subscriptionRequired: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.xl,
  },
  subscriptionTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.lg,
    marginBottom: theme.spacing.md,
  },
  subscriptionText: {
    fontSize: 16,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: theme.spacing.sm,
  },
  subscribeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.xl,
    paddingVertical: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    marginTop: theme.spacing.xl,
  },
  subscribeButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
    marginRight: theme.spacing.sm,
  },
  disclaimerBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.warning + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginTop: theme.spacing.xl,
    borderWidth: 1,
    borderColor: theme.colors.warning + '40',
  },
  disclaimerText: {
    flex: 1,
    fontSize: 12,
    color: theme.colors.text,
    lineHeight: 18,
    marginLeft: theme.spacing.sm,
  },
  bold: {
    fontWeight: '700',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.xl,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
  },
  emptySubtext: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    textAlign: 'center',
  },
  chatRoomItem: {
    flexDirection: 'row',
    padding: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
    backgroundColor: theme.colors.surface,
  },
  avatar: {
    marginRight: theme.spacing.md,
  },
  chatRoomContent: {
    flex: 1,
  },
  chatRoomHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.xs,
  },
  chatRoomName: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
  },
  chatRoomTime: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  lastMessage: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  typeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: theme.colors.surface,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
  },
  typeText: {
    fontSize: 10,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
    fontWeight: '600',
  },
});

export default ChatListScreen;

