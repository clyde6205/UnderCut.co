import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import {GiftedChat, IMessage, InputToolbar, Send} from 'react-native-gifted-chat';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAuth} from '../../contexts/AuthContext';
import {
  sendMessage,
  subscribeToChatRoomMessages,
  markMessagesAsRead,
  unsubscribeFromChatRoomMessages,
} from '../../services/chatMePro';
import {ChatMessage} from '../../types/chat';
import {theme} from '../../theme/theme';

type ChatRoomRouteParams = {
  ChatRoom: {
    chatRoomId: string;
    recipientName?: string;
  };
};

const ChatRoomScreen: React.FC = () => {
  const route = useRoute<RouteProp<ChatRoomRouteParams, 'ChatRoom'>>();
  const navigation = useNavigation();
  const {user} = useAuth();
  const {chatRoomId, recipientName} = route.params;
  const [messages, setMessages] = useState<IMessage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Subscribe to real-time messages (no cold start - loads from cache instantly)
    const unsubscribe = subscribeToChatRoomMessages(chatRoomId, (newMessages) => {
      const formattedMessages: IMessage[] = newMessages.map(msg => ({
        _id: msg.id,
        text: msg.text,
        createdAt: msg.createdAt,
        user: {
          _id: msg.senderId,
          name: msg.senderName,
        },
      }));
      setMessages(formattedMessages);
      setLoading(false);
    });

    // Mark as read when viewing
    if (user) {
      markMessagesAsRead(chatRoomId, user.id);
    }

    return () => {
      unsubscribe();
    };
  }, [chatRoomId, user]);


  const onSend = useCallback(async (newMessages: IMessage[] = []) => {
    if (!user || newMessages.length === 0) return;

    try {
      const message = newMessages[0];
      await sendMessage(chatRoomId, user.id, user.displayName, message.text);
      
      setMessages(previousMessages => GiftedChat.append(previousMessages, newMessages));
    } catch (error: any) {
      console.error('Error sending message:', error);
      // Show error to user
    }
  }, [chatRoomId, user]);

  const renderInputToolbar = (props: any) => {
    return (
      <InputToolbar
        {...props}
        containerStyle={styles.inputToolbar}
        textInputStyle={styles.textInput}
      />
    );
  };

  const renderSend = (props: any) => {
    return (
      <Send {...props} containerStyle={styles.sendContainer}>
        <Icon name="send" size={24} color={theme.colors.primary} />
      </Send>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Icon name="arrow-left" size={24} color={theme.colors.text} />
          </TouchableOpacity>
          <View style={styles.headerInfo}>
            <Text style={styles.headerTitle}>{recipientName || 'Chat'}</Text>
            <Text style={styles.headerSubtitle}>ChatMe.Pro</Text>
          </View>
        </View>
      </View>

      <GiftedChat
        messages={messages}
        onSend={onSend}
        user={{
          _id: user?.id || '',
          name: user?.displayName || '',
        }}
        renderInputToolbar={renderInputToolbar}
        renderSend={renderSend}
        placeholder="Type a message..."
        alwaysShowSend
        scrollToBottom
        scrollToBottomComponent={() => (
          <Icon name="chevron-down" size={24} color={theme.colors.primary} />
        )}
      />
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
    paddingTop: Platform.OS === 'ios' ? 50 : 10,
    paddingBottom: 10,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.md,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  headerInfo: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
  },
  headerSubtitle: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  inputToolbar: {
    backgroundColor: theme.colors.surface,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
    paddingVertical: theme.spacing.xs,
  },
  textInput: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.md,
    paddingHorizontal: theme.spacing.md,
    marginHorizontal: theme.spacing.sm,
    fontSize: 16,
    color: theme.colors.text,
  },
  sendContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.sm,
  },
});

export default ChatRoomScreen;

