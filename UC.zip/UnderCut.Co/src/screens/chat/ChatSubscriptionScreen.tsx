import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAuth} from '../../contexts/AuthContext';
import {useLanguage} from '../../contexts/LanguageContext';
import {
  hasActiveChatSubscription,
  subscribeToChat,
  cancelChatSubscription,
  checkPlatformUsageEligibility,
} from '../../services/chatMePro';
import {theme} from '../../theme/theme';

const ChatSubscriptionScreen: React.FC = () => {
  const navigation = useNavigation();
  const {user} = useAuth();
  const {t} = useLanguage();
  const [hasSubscription, setHasSubscription] = useState(false);
  const [isEligible, setIsEligible] = useState(true);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');

  useEffect(() => {
    checkSubscriptionStatus();
  }, [user]);

  const checkSubscriptionStatus = async () => {
    if (!user) return;

    try {
      const subscribed = await hasActiveChatSubscription(user.id);
      const eligible = await checkPlatformUsageEligibility(user.id);
      setHasSubscription(subscribed);
      setIsEligible(eligible);
    } catch (error) {
      console.error('Error checking subscription:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async () => {
    if (!user) return;

    if (!isEligible) {
      Alert.alert(
        'Platform Usage Required',
        'You must actively use the platform (post quotes, submit bids, or complete transactions) to maintain chat access. Your last activity was more than 6 months ago.'
      );
      return;
    }

    setProcessing(true);
    try {
      await subscribeToChat(user.id, selectedPlan);
      Alert.alert('Success', 'Successfully subscribed to ChatMe.Pro!', [
        {text: 'OK', onPress: () => navigation.goBack()},
      ]);
      await checkSubscriptionStatus();
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to subscribe');
    } finally {
      setProcessing(false);
    }
  };

  const handleCancel = async () => {
    if (!user) return;

    Alert.alert(
      'Cancel Subscription',
      'Are you sure you want to cancel your ChatMe.Pro subscription?',
      [
        {text: 'No', style: 'cancel'},
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: async () => {
            setProcessing(true);
            try {
              await cancelChatSubscription(user.id);
              Alert.alert('Cancelled', 'Your subscription has been cancelled.');
              await checkSubscriptionStatus();
            } catch (error: any) {
              Alert.alert('Error', error.message || 'Failed to cancel subscription');
            } finally {
              setProcessing(false);
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>ChatMe.Pro Subscription</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.brandSection}>
          <Icon name="chat-processing" size={64} color={theme.colors.primary} />
          <Text style={styles.brandName}>ChatMe.Pro</Text>
          <Text style={styles.brandTagline}>
            Professional communication for buyers and sellers
          </Text>
        </View>

        {!isEligible && (
          <View style={styles.warningBox}>
            <Icon name="alert-circle" size={24} color={theme.colors.error} />
            <Text style={styles.warningText}>
              <Text style={styles.bold}>Platform Usage Required:</Text> You must actively use
              UnderCut.Co for its intended purposes (posting quotes, submitting bids, or completing
              transactions) to maintain chat access. Your last platform activity was more than 6
              months ago.
            </Text>
          </View>
        )}

        {hasSubscription ? (
          <View style={styles.subscribedSection}>
            <View style={styles.successBadge}>
              <Icon name="check-circle" size={32} color={theme.colors.success} />
              <Text style={styles.subscribedText}>You're Subscribed!</Text>
            </View>

            <TouchableOpacity
              style={styles.cancelButton}
              onPress={handleCancel}
              disabled={processing}>
              {processing ? (
                <ActivityIndicator color={theme.colors.error} />
              ) : (
                <>
                  <Icon name="cancel" size={20} color={theme.colors.error} />
                  <Text style={styles.cancelButtonText}>Cancel Subscription</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.subscriptionPlans}>
            <Text style={styles.sectionTitle}>Choose Your Plan</Text>

            <TouchableOpacity
              style={[
                styles.planCard,
                selectedPlan === 'monthly' && styles.planCardSelected,
              ]}
              onPress={() => setSelectedPlan('monthly')}>
              <View style={styles.planHeader}>
                <Text style={styles.planName}>Monthly</Text>
                <Text style={styles.planPrice}>$9.99/month</Text>
              </View>
              <Text style={styles.planDescription}>
                Perfect for active buyers and sellers
              </Text>
              {selectedPlan === 'monthly' && (
                <Icon name="check-circle" size={24} color={theme.colors.primary} style={styles.checkIcon} />
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.planCard,
                selectedPlan === 'yearly' && styles.planCardSelected,
              ]}
              onPress={() => setSelectedPlan('yearly')}>
              <View style={styles.planHeader}>
                <Text style={styles.planName}>Yearly</Text>
                <Text style={styles.planPrice}>$99.99/year</Text>
                <View style={styles.savingsBadge}>
                  <Text style={styles.savingsText}>Save 17%</Text>
                </View>
              </View>
              <Text style={styles.planDescription}>
                Best value for frequent users
              </Text>
              {selectedPlan === 'yearly' && (
                <Icon name="check-circle" size={24} color={theme.colors.primary} style={styles.checkIcon} />
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.subscribeButton, processing && styles.subscribeButtonDisabled]}
              onPress={handleSubscribe}
              disabled={processing || !isEligible}>
              {processing ? (
                <ActivityIndicator color={theme.colors.background} />
              ) : (
                <>
                  <Text style={styles.subscribeButtonText}>Subscribe Now</Text>
                  <Icon name="arrow-right" size={20} color={theme.colors.background} />
                </>
              )}
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.disclaimerSection}>
          <Text style={styles.disclaimerTitle}>Important Information</Text>
          <View style={styles.disclaimerBox}>
            <Icon name="information" size={20} color={theme.colors.info} />
            <Text style={styles.disclaimerText}>
              <Text style={styles.bold}>Platform Usage Requirement:</Text> ChatMe.Pro is not an
              open chat platform. To protect our buyers and sellers from casual users, chat access
              requires active platform usage. If you do not use UnderCut.Co for its intended
              purposes (posting quotes, submitting bids, or completing transactions) for 6 months,
              your chat access will be removed.
            </Text>
          </View>
          <View style={styles.disclaimerBox}>
            <Icon name="shield-check" size={20} color={theme.colors.success} />
            <Text style={styles.disclaimerText}>
              <Text style={styles.bold}>No Forced Usage:</Text> We are not seeking to force anyone
              to use our system. However, we must protect our buyers and sellers from users who do
              not actively participate in the platform's core purpose.
            </Text>
          </View>
          <View style={styles.disclaimerBox}>
            <Icon name="chat" size={20} color={theme.colors.primary} />
            <Text style={styles.disclaimerText}>
              <Text style={styles.bold}>Subscriber Benefits:</Text> Subscribers can chat with other
              platform users. You do not need to be a buyer or seller to subscribe, but you must
              maintain active platform usage.
            </Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.text,
  },
  content: {
    padding: theme.spacing.lg,
  },
  brandSection: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  brandName: {
    fontSize: 32,
    fontWeight: '700',
    color: theme.colors.primary,
    marginTop: theme.spacing.md,
  },
  brandTagline: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginTop: theme.spacing.xs,
  },
  warningBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.error + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.lg,
    borderWidth: 1,
    borderColor: theme.colors.error + '40',
  },
  warningText: {
    flex: 1,
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 20,
    marginLeft: theme.spacing.sm,
  },
  subscribedSection: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  successBadge: {
    alignItems: 'center',
    marginBottom: theme.spacing.lg,
  },
  subscribedText: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.success,
    marginTop: theme.spacing.sm,
  },
  cancelButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.error + '20',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.error,
  },
  cancelButtonText: {
    color: theme.colors.error,
    fontSize: 16,
    fontWeight: '600',
    marginLeft: theme.spacing.sm,
  },
  subscriptionPlans: {
    marginBottom: theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  planCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    borderWidth: 2,
    borderColor: theme.colors.border,
    position: 'relative',
  },
  planCardSelected: {
    borderColor: theme.colors.primary,
    backgroundColor: theme.colors.primary + '10',
  },
  planHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  planName: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.text,
    flex: 1,
  },
  planPrice: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.primary,
  },
  savingsBadge: {
    backgroundColor: theme.colors.success,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
    marginLeft: theme.spacing.sm,
  },
  savingsText: {
    color: theme.colors.background,
    fontSize: 12,
    fontWeight: '700',
  },
  planDescription: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  checkIcon: {
    position: 'absolute',
    top: theme.spacing.md,
    right: theme.spacing.md,
  },
  subscribeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.primary,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    marginTop: theme.spacing.md,
  },
  subscribeButtonDisabled: {
    opacity: 0.6,
  },
  subscribeButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
    marginRight: theme.spacing.sm,
  },
  disclaimerSection: {
    marginTop: theme.spacing.xl,
  },
  disclaimerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  disclaimerBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.info + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.info + '40',
  },
  disclaimerText: {
    flex: 1,
    fontSize: 13,
    color: theme.colors.text,
    lineHeight: 20,
    marginLeft: theme.spacing.sm,
  },
  bold: {
    fontWeight: '700',
  },
});

export default ChatSubscriptionScreen;

