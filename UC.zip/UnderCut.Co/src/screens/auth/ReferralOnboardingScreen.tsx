import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAuth} from '../../contexts/AuthContext';
import {useLanguage} from '../../contexts/LanguageContext';
import {validateReferralCode} from '../../services/referral';
import {theme} from '../../theme/theme';

type ReferralOnboardingRouteParams = {
  ReferralOnboarding: {
    referralCode?: string;
  };
};

const ReferralOnboardingScreen: React.FC = () => {
  const route = useRoute<RouteProp<ReferralOnboardingRouteParams, 'ReferralOnboarding'>>();
  const navigation = useNavigation();
  const {signUp} = useAuth();
  const {t} = useLanguage();
  const {referralCode: initialCode} = route.params || {};

  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [referralCode, setReferralCode] = useState(initialCode || '');
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  const [loading, setLoading] = useState(false);
  const [validatingCode, setValidatingCode] = useState(false);
  const [codeValid, setCodeValid] = useState<boolean | null>(null);

  useEffect(() => {
    if (initialCode) {
      validateCode(initialCode);
    }
  }, [initialCode]);

  const validateCode = async (code: string) => {
    if (!code) {
      setCodeValid(null);
      return;
    }

    setValidatingCode(true);
    try {
      const isValid = await validateReferralCode(code.toUpperCase());
      setCodeValid(isValid);
      if (!isValid) {
        Alert.alert('Invalid Code', 'This referral code is not valid. You can still sign up without it.');
      }
    } catch (error) {
      setCodeValid(false);
    } finally {
      setValidatingCode(false);
    }
  };

  const handleSignUp = async () => {
    if (!displayName || !email || !password) {
      Alert.alert(t('errors.fillAllFields'));
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert(t('errors.passwordsDontMatch'));
      return;
    }

    if (password.length < 6) {
      Alert.alert(t('errors.passwordTooShort'));
      return;
    }

    setLoading(true);
    try {
      // Sign up with referral code if provided and valid
      await signUp(email, password, displayName, role, referralCode.toUpperCase() || undefined);
    } catch (error: any) {
      Alert.alert(t('errors.signUpFailed'), error.message || t('errors.failedToCreateAccount'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.referralBadge}>
          <Icon name="account-plus" size={24} color={theme.colors.primary} />
          <Text style={styles.referralBadgeText}>Quick Onboarding</Text>
        </View>
        <Text style={styles.title}>Join UnderCut.Co</Text>
        <Text style={styles.subtitle}>You've been invited! Create your account now</Text>
      </View>

      <View style={styles.form}>
        <View style={styles.referralSection}>
          <Text style={styles.label}>Referral Code (Optional)</Text>
          <View style={styles.referralInputContainer}>
            <TextInput
              style={[
                styles.referralInput,
                codeValid === true && styles.referralInputValid,
                codeValid === false && styles.referralInputInvalid,
              ]}
              placeholder="Enter referral code"
              value={referralCode}
              onChangeText={(text) => {
                setReferralCode(text.toUpperCase());
                if (text.length >= 4) {
                  validateCode(text.toUpperCase());
                } else {
                  setCodeValid(null);
                }
              }}
              autoCapitalize="characters"
              editable={!initialCode}
            />
            {validatingCode && (
              <ActivityIndicator size="small" color={theme.colors.primary} style={styles.validatingIcon} />
            )}
            {codeValid === true && (
              <Icon name="check-circle" size={20} color={theme.colors.success} style={styles.validatingIcon} />
            )}
            {codeValid === false && (
              <Icon name="alert-circle" size={20} color={theme.colors.error} style={styles.validatingIcon} />
            )}
          </View>
          {codeValid === true && (
            <Text style={styles.validCodeText}>✓ Valid referral code</Text>
          )}
        </View>

        <View style={styles.roleSelector}>
          <TouchableOpacity
            style={[styles.roleButton, role === 'buyer' && styles.roleButtonActive]}
            onPress={() => setRole('buyer')}>
            <Icon
              name="cart"
              size={24}
              color={role === 'buyer' ? theme.colors.background : theme.colors.textSecondary}
            />
            <Text
              style={[
                styles.roleButtonText,
                role === 'buyer' && styles.roleButtonTextActive,
              ]}>
              {t('auth.imBuyer')}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.roleButton, role === 'seller' && styles.roleButtonActive]}
            onPress={() => setRole('seller')}>
            <Icon
              name="store"
              size={24}
              color={role === 'seller' ? theme.colors.background : theme.colors.textSecondary}
            />
            <Text
              style={[
                styles.roleButtonText,
                role === 'seller' && styles.roleButtonTextActive,
              ]}>
              {t('auth.imSeller')}
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.label}>Full Name *</Text>
        <TextInput
          style={styles.input}
          placeholder="Your full name"
          value={displayName}
          onChangeText={setDisplayName}
          autoCapitalize="words"
        />

        <Text style={styles.label}>Email *</Text>
        <TextInput
          style={styles.input}
          placeholder="your.email@example.com"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />

        <Text style={styles.label}>Password *</Text>
        <TextInput
          style={styles.input}
          placeholder="Minimum 6 characters"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          autoCapitalize="none"
        />

        <Text style={styles.label}>Confirm Password *</Text>
        <TextInput
          style={styles.input}
          placeholder="Confirm your password"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry
          autoCapitalize="none"
        />

        <TouchableOpacity
          style={[styles.submitButton, loading && styles.submitButtonDisabled]}
          onPress={handleSignUp}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator color={theme.colors.background} />
          ) : (
            <Text style={styles.submitButtonText}>Create Account & Join</Text>
          )}
        </TouchableOpacity>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            By creating an account, you agree to our Terms of Service
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.primary + '10',
  },
  referralBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.full,
    marginBottom: theme.spacing.md,
  },
  referralBadgeText: {
    color: theme.colors.background,
    fontSize: 12,
    fontWeight: '600',
    marginLeft: theme.spacing.xs,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  form: {
    padding: theme.spacing.lg,
  },
  referralSection: {
    marginBottom: theme.spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
    marginTop: theme.spacing.md,
  },
  referralInputContainer: {
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
  },
  referralInput: {
    flex: 1,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    borderWidth: 2,
    borderColor: theme.colors.border,
    letterSpacing: 2,
    textAlign: 'center',
  },
  referralInputValid: {
    borderColor: theme.colors.success,
    backgroundColor: theme.colors.success + '10',
  },
  referralInputInvalid: {
    borderColor: theme.colors.error,
    backgroundColor: theme.colors.error + '10',
  },
  validatingIcon: {
    position: 'absolute',
    right: theme.spacing.md,
  },
  validCodeText: {
    fontSize: 12,
    color: theme.colors.success,
    marginTop: theme.spacing.xs,
    fontWeight: '600',
  },
  roleSelector: {
    flexDirection: 'row',
    marginBottom: theme.spacing.lg,
    gap: theme.spacing.md,
  },
  roleButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    backgroundColor: theme.colors.surface,
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  roleButtonActive: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  roleButtonText: {
    marginLeft: theme.spacing.sm,
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.textSecondary,
  },
  roleButtonTextActive: {
    color: theme.colors.background,
  },
  input: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    fontSize: 16,
    color: theme.colors.text,
    borderWidth: 1,
    borderColor: theme.colors.border,
    marginBottom: theme.spacing.sm,
  },
  submitButton: {
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
    marginTop: theme.spacing.lg,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  footer: {
    marginTop: theme.spacing.lg,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
});

export default ReferralOnboardingScreen;

