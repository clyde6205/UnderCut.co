import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useLanguage} from '../../contexts/LanguageContext';
import {theme} from '../../theme/theme';

type AuthStackParamList = {
  Welcome: undefined;
  Login: undefined;
  SignUp: undefined;
};

type WelcomeScreenNavigationProp = StackNavigationProp<AuthStackParamList, 'Welcome'>;

const WelcomeScreen: React.FC = () => {
  const navigation = useNavigation<WelcomeScreenNavigationProp>();
  const {t, currentLanguage, supportedLanguages, changeLanguage} = useLanguage();

  return (
    <LinearGradient
      colors={[theme.colors.primary, theme.colors.secondary]}
      style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.languageButton}
            onPress={() => navigation.navigate('Language' as never)}>
            <Icon name="translate" size={20} color={theme.colors.background} />
            <Text style={styles.languageButtonText}>
              {supportedLanguages.find(l => l.code === currentLanguage)?.nativeName || 'English'}
            </Text>
            <Icon name="chevron-down" size={16} color={theme.colors.background} />
          </TouchableOpacity>
          <Icon name="handshake" size={80} color={theme.colors.background} />
          <Text style={styles.title}>{t('app.name')}</Text>
          <Text style={styles.subtitle}>{t('app.tagline')}</Text>
        </View>

        <View style={styles.content}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{t('welcome.whatWeAre')}</Text>
            <Text style={styles.cardText}>
              <Text style={styles.bold}>{t('welcome.notShoppingPlatform')}</Text>
            </Text>
            <Text style={styles.cardDescription}>
              {t('welcome.description1')} {t('welcome.description2')}
            </Text>
            <Text style={styles.cardDescription}>
              {t('welcome.description3')} {t('welcome.description4')}
            </Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>{t('welcome.howItWorks')}</Text>
            <View style={styles.featureRow}>
              <Icon name="file-document-check" size={24} color={theme.colors.primary} />
              <Text style={styles.featureText}>{t('welcome.feature1')}</Text>
            </View>
            <View style={styles.featureRow}>
              <Icon name="tag-multiple" size={24} color={theme.colors.primary} />
              <Text style={styles.featureText}>{t('welcome.feature2')}</Text>
            </View>
            <View style={styles.featureRow}>
              <Icon name="lock" size={24} color={theme.colors.primary} />
              <Text style={styles.featureText}>{t('welcome.feature3')}</Text>
            </View>
            <View style={styles.featureRow}>
              <Icon name="earth" size={24} color={theme.colors.global} />
              <Text style={styles.featureText}>{t('welcome.feature4')}</Text>
            </View>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>{t('welcome.importantInfo')}</Text>
            <View style={styles.infoRow}>
              <Icon name="information" size={20} color={theme.colors.warning} />
              <Text style={styles.infoText}>
                {t('welcome.noMoneyHeld')}
              </Text>
            </View>
            <View style={styles.infoRow}>
              <Icon name="alert-circle" size={20} color={theme.colors.error} />
              <Text style={styles.infoText}>
                {t('welcome.noRefunds')}
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('SignUp')}>
            <Text style={styles.buttonText}>{t('welcome.getStarted')}</Text>
            <Icon name="arrow-right" size={20} color={theme.colors.background} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.linkButton}
            onPress={() => navigation.navigate('Login')}>
            <Text style={styles.linkText}>{t('welcome.alreadyHaveAccount')}</Text>
          </TouchableOpacity>

          <View style={styles.copyrightContainer}>
            <Text style={styles.copyrightText}>
              © 2024 UnderCut.Co. All Rights Reserved.{' '}
              <Text style={styles.copyrightLink}>Protected by copyright law.</Text>
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: theme.spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginTop: theme.spacing.xxl,
    marginBottom: theme.spacing.xl,
  },
  languageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.background + '40',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.full,
    marginBottom: theme.spacing.lg,
    borderWidth: 1,
    borderColor: theme.colors.background + '60',
  },
  languageButtonText: {
    color: theme.colors.background,
    fontSize: 14,
    fontWeight: '600',
    marginHorizontal: theme.spacing.xs,
  },
  title: {
    fontSize: 42,
    fontWeight: '700',
    color: theme.colors.background,
    marginTop: theme.spacing.md,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: theme.colors.background,
    opacity: 0.9,
    marginTop: theme.spacing.sm,
    textAlign: 'center',
  },
  content: {
    flex: 1,
  },
  card: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: theme.colors.primary,
    marginBottom: theme.spacing.md,
  },
  cardText: {
    fontSize: 16,
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  cardDescription: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    lineHeight: 22,
    marginBottom: theme.spacing.sm,
  },
  bold: {
    fontWeight: '700',
    color: theme.colors.text,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  featureText: {
    fontSize: 14,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    flex: 1,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: theme.spacing.sm,
  },
  infoText: {
    fontSize: 13,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.sm,
    flex: 1,
    lineHeight: 20,
  },
  button: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.full,
    padding: theme.spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: theme.spacing.lg,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  buttonText: {
    color: theme.colors.primary,
    fontSize: 18,
    fontWeight: '600',
    marginRight: theme.spacing.sm,
  },
  linkButton: {
    marginTop: theme.spacing.md,
    padding: theme.spacing.sm,
  },
  linkText: {
    color: theme.colors.background,
    fontSize: 14,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
  copyrightContainer: {
    marginTop: theme.spacing.xl,
    paddingHorizontal: theme.spacing.lg,
  },
  copyrightText: {
    color: theme.colors.background,
    fontSize: 11,
    textAlign: 'center',
    opacity: 0.8,
    lineHeight: 16,
  },
  copyrightLink: {
    fontWeight: '600',
  },
});

export default WelcomeScreen;

