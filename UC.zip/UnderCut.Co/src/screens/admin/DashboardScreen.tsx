import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useNavigation} from '@react-navigation/native';
import {useAuth} from '../../contexts/AuthContext';
import {useLanguage} from '../../contexts/LanguageContext';
import {getPlatformAnalytics} from '../../services/admin';
import {PlatformAnalytics} from '../../types/admin';
import {theme} from '../../theme/theme';
import {formatCurrency} from '../../utils';

const DashboardScreen: React.FC = () => {
  const navigation = useNavigation();
  const {user} = useAuth();
  const {t} = useLanguage();
  const [analytics, setAnalytics] = useState<PlatformAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const data = await getPlatformAnalytics();
      setAnalytics(data);
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadAnalytics();
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  if (!analytics) {
    return (
      <View style={styles.container}>
        <Text>Error loading analytics</Text>
      </View>
    );
  }

  const StatCard = ({
    title,
    value,
    icon,
    color,
    onPress,
  }: {
    title: string;
    value: string | number;
    icon: string;
    color: string;
    onPress?: () => void;
  }) => (
    <TouchableOpacity
      style={[styles.statCard, {borderLeftColor: color}]}
      onPress={onPress}
      disabled={!onPress}>
      <View style={styles.statCardHeader}>
        <Icon name={icon} size={24} color={color} />
        <Text style={styles.statCardTitle}>{title}</Text>
      </View>
      <Text style={[styles.statCardValue, {color}]}>{value}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Founders Console</Text>
          <Text style={styles.headerSubtitle}>Global Platform Control</Text>
        </View>
        <Icon name="shield-crown" size={32} color={theme.colors.primary} />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Platform Overview</Text>
        <View style={styles.statsGrid}>
          <StatCard
            title="Total Users"
            value={analytics.totalUsers.toLocaleString()}
            icon="account-group"
            color={theme.colors.primary}
            onPress={() => navigation.navigate('Users' as never)}
          />
          <StatCard
            title="Active Users"
            value={analytics.activeUsers.toLocaleString()}
            icon="account-check"
            color={theme.colors.success}
          />
          <StatCard
            title="Buyers"
            value={analytics.totalBuyers.toLocaleString()}
            icon="cart"
            color={theme.colors.info}
          />
          <StatCard
            title="Sellers"
            value={analytics.totalSellers.toLocaleString()}
            icon="store"
            color={theme.colors.warning}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Transactions</Text>
        <View style={styles.statsGrid}>
          <StatCard
            title="Total Transactions"
            value={analytics.totalTransactions.toLocaleString()}
            icon="swap-horizontal"
            color={theme.colors.primary}
            onPress={() => navigation.navigate('AllTransactions' as never)}
          />
          <StatCard
            title="Completed"
            value={analytics.completedTransactions.toLocaleString()}
            icon="check-circle"
            color={theme.colors.success}
          />
          <StatCard
            title="Total Volume"
            value={formatCurrency(analytics.totalTransactionVolume, 'USD')}
            icon="cash"
            color={theme.colors.success}
          />
          <StatCard
            title="Avg. Value"
            value={formatCurrency(analytics.averageTransactionValue, 'USD')}
            icon="chart-line"
            color={theme.colors.info}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Growth Metrics</Text>
        <View style={styles.statsGrid}>
          <StatCard
            title="New Users Today"
            value={analytics.newUsersToday}
            icon="account-plus"
            color={theme.colors.success}
          />
          <StatCard
            title="This Week"
            value={analytics.newUsersThisWeek}
            icon="calendar-week"
            color={theme.colors.info}
          />
          <StatCard
            title="This Month"
            value={analytics.newUsersThisMonth}
            icon="calendar-month"
            color={theme.colors.primary}
          />
          <StatCard
            title="Active Referrals"
            value={analytics.activeReferrals}
            icon="account-group"
            color={theme.colors.warning}
            onPress={() => navigation.navigate('Referrals' as never)}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Platform Activity</Text>
        <View style={styles.statsGrid}>
          <StatCard
            title="Quotes"
            value={analytics.totalQuotes.toLocaleString()}
            icon="file-document"
            color={theme.colors.info}
            onPress={() => navigation.navigate('AllQuotes' as never)}
          />
          <StatCard
            title="Bids"
            value={analytics.totalBids.toLocaleString()}
            icon="tag"
            color={theme.colors.warning}
          />
          <StatCard
            title="Platform Revenue"
            value={formatCurrency(analytics.platformRevenue, 'USD')}
            icon="bank"
            color={theme.colors.success}
          />
          <StatCard
            title="Transactions Today"
            value={analytics.transactionsToday}
            icon="calendar-today"
            color={theme.colors.primary}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => navigation.navigate('Users' as never)}>
            <Icon name="account-group" size={24} color={theme.colors.primary} />
            <Text style={styles.actionButtonText}>Manage Users</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => navigation.navigate('Settings' as never)}>
            <Icon name="cog" size={24} color={theme.colors.primary} />
            <Text style={styles.actionButtonText}>Platform Settings</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => navigation.navigate('Referrals' as never)}>
            <Icon name="account-group" size={24} color={theme.colors.primary} />
            <Text style={styles.actionButtonText}>Referral System</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => navigation.navigate('Analytics' as never)}>
            <Icon name="chart-box" size={24} color={theme.colors.primary} />
            <Text style={styles.actionButtonText}>Detailed Analytics</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
  },
  headerSubtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  section: {
    padding: theme.spacing.lg,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing.md,
  },
  statCard: {
    width: '48%',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderLeftWidth: 4,
    marginBottom: theme.spacing.sm,
  },
  statCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  statCardTitle: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.sm,
    flex: 1,
  },
  statCardValue: {
    fontSize: 20,
    fontWeight: '700',
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing.md,
  },
  actionButton: {
    width: '48%',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    marginTop: theme.spacing.xs,
  },
});

export default DashboardScreen;

