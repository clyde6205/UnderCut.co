import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import firestore from '@react-native-firebase/firestore';
import {useAuth} from '../../contexts/AuthContext';
import {Quote, Bid} from '../../types';
import {theme} from '../../theme/theme';
import {format} from 'date-fns';
import {acceptBidInstantly, canInstantPurchase, getBestBid} from '../../services/instantPurchase';
import {getPriceComparison, calculateSavings} from '../../services/marketInsights';
import {createPriceAlert} from '../../services/priceAlerts';
import {isBuyerCommitted} from '../../services/buyerCommitment';

type QuoteDetailRouteParams = {
  QuoteDetail: {
    quoteId: string;
  };
};

const QuoteDetailScreen: React.FC = () => {
  const route = useRoute<RouteProp<QuoteDetailRouteParams, 'QuoteDetail'>>();
  const navigation = useNavigation();
  const {user} = useAuth();
  const {quoteId} = route.params;
  const [quote, setQuote] = useState<Quote | null>(null);
  const [bids, setBids] = useState<Bid[]>([]);
  const [loading, setLoading] = useState(true);
  const [bestBid, setBestBid] = useState<Bid | null>(null);
  const [priceComparison, setPriceComparison] = useState<any>(null);
  const [isCommitted, setIsCommitted] = useState(false);
  const [processingPurchase, setProcessingPurchase] = useState(false);

  useEffect(() => {
    loadQuote();
    loadBids();
    loadPriceComparison();
    checkCommitment();
  }, [quoteId, user]);

  useEffect(() => {
    if (bids.length > 0) {
      setBestBid(bids[0]); // First bid is lowest price (sorted)
    }
  }, [bids]);

  const loadQuote = async () => {
    try {
      const doc = await firestore().collection('quotes').doc(quoteId).get();
      if (doc.exists) {
        const data = doc.data();
        setQuote({
          id: doc.id,
          ...data,
          createdAt: data?.createdAt?.toDate() || new Date(),
          expiresAt: data?.expiresAt?.toDate() || new Date(),
        } as Quote);
      }
    } catch (error) {
      console.error('Error loading quote:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadBids = async () => {
    try {
      const snapshot = await firestore()
        .collection('bids')
        .where('quoteId', '==', quoteId)
        .orderBy('price', 'asc')
        .get();

      const bidsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
      })) as Bid[];

      setBids(bidsData);
      
      // Load seller info for each bid
      for (const bid of bidsData) {
        const sellerDoc = await firestore().collection('users').doc(bid.sellerId).get();
        if (sellerDoc.exists) {
          const sellerData = sellerDoc.data();
          bid.sellerRating = sellerData?.rating;
          bid.sellerVerified = sellerData?.verified || sellerData?.sellerMetrics?.verifiedSeller;
        }
      }
    } catch (error) {
      console.error('Error loading bids:', error);
    }
  };

  const loadPriceComparison = async () => {
    try {
      const comparison = await getPriceComparison(quoteId);
      setPriceComparison(comparison);
    } catch (error) {
      console.error('Error loading price comparison:', error);
    }
  };

  const checkCommitment = async () => {
    if (quote && user) {
      const committed = await isBuyerCommitted(quote.id, user.id);
      setIsCommitted(committed);
    }
  };

  const handleInstantPurchase = async () => {
    if (!quote || !bestBid || !user) {
      Alert.alert('Error', 'Unable to process purchase');
      return;
    }

    Alert.alert(
      'Confirm Instant Purchase',
      `Purchase from ${bestBid.sellerName} for ${quote.currency} ${bestBid.price.toLocaleString()}?`,
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Purchase Now',
          onPress: async () => {
            setProcessingPurchase(true);
            try {
              const result = await acceptBidInstantly(quote, bestBid, user, 'stripe');
              if (result.success && result.transactionId) {
                Alert.alert('Success', 'Purchase completed! Redirecting to transaction...', [
                  {
                    text: 'OK',
                    onPress: () => navigation.navigate('Transactions' as never),
                  },
                ]);
              } else {
                Alert.alert('Error', result.error || 'Purchase failed');
              }
            } catch (error: any) {
              Alert.alert('Error', error.message || 'Purchase failed');
            } finally {
              setProcessingPurchase(false);
            }
          },
        },
      ]
    );
  };

  const handleCreatePriceAlert = async () => {
    if (!quote || !user) return;

    try {
      await createPriceAlert(user.id, quote.id, 'new_bid');
      Alert.alert('Success', 'Price alerts enabled for this quote');
    } catch (error) {
      Alert.alert('Error', 'Failed to create price alert');
    }
  };

  if (loading || !quote) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  const isOwner = user?.id === quote.buyerId;
  const canBid = user?.role === 'seller' && !isOwner;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.title}>{quote.title}</Text>
          <Text style={styles.description}>{quote.description}</Text>

          <View style={styles.details}>
            <View style={styles.detailItem}>
              <Icon name="tag" size={20} color={theme.colors.textSecondary} />
              <Text style={styles.detailText}>{quote.category}</Text>
            </View>
            {quote.location && (
              <View style={styles.detailItem}>
                <Icon name="map-marker" size={20} color={theme.colors.textSecondary} />
                <Text style={styles.detailText}>
                  {quote.location.city || quote.location.country}
                </Text>
              </View>
            )}
            <TouchableOpacity
              style={styles.detailItem}
              onPress={() => navigation.navigate('UserProfile' as never, {userId: quote.buyerId} as never)}>
              <Icon name="account-circle" size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.detailText, styles.linkText]}>Posted by {quote.buyerName}</Text>
            </TouchableOpacity>
            <View style={styles.detailItem}>
              <Icon name="clock-outline" size={20} color={theme.colors.textSecondary} />
              <Text style={styles.detailText}>
                Expires: {format(quote.expiresAt, 'MMM dd, yyyy HH:mm')}
              </Text>
            </View>
          </View>

          <View style={styles.priceContainer}>
            <Text style={styles.priceLabel}>Maximum Price</Text>
            <Text style={styles.price}>
              {quote.currency} {quote.maxPrice.toLocaleString()}
            </Text>
            {bestBid && priceComparison?.savings && (
              <View style={styles.savingsContainer}>
                <Icon name="trending-down" size={20} color={theme.colors.success} />
                <Text style={styles.savingsText}>
                  Save {quote.currency} {priceComparison.savings.amount.toLocaleString()} (
                  {priceComparison.savings.percentage}%)
                </Text>
              </View>
            )}
            {quote.buyerCommitted && (
              <View style={styles.commitmentBadge}>
                <Icon name="check-circle" size={16} color={theme.colors.success} />
                <Text style={styles.commitmentText}>Committed Buyer</Text>
              </View>
            )}
          </View>
        </View>

        {/* Instant Purchase Section */}
        {isOwner && bestBid && canInstantPurchase(quote, bids) && (
          <TouchableOpacity
            style={styles.instantPurchaseButton}
            onPress={handleInstantPurchase}
            disabled={processingPurchase}>
            {processingPurchase ? (
              <ActivityIndicator color={theme.colors.background} />
            ) : (
              <>
                <View style={styles.instantPurchaseContent}>
                  <Icon name="flash" size={24} color={theme.colors.background} />
                  <View style={styles.instantPurchaseText}>
                    <Text style={styles.instantPurchaseTitle}>Instant Purchase</Text>
                    <Text style={styles.instantPurchaseSubtitle}>
                      Best Price: {quote.currency} {bestBid.price.toLocaleString()}
                    </Text>
                  </View>
                </View>
                <Icon name="chevron-right" size={24} color={theme.colors.background} />
              </>
            )}
          </TouchableOpacity>
        )}

        {/* Price Comparison */}
        {priceComparison && priceComparison.bids.length > 0 && (
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Price Comparison</Text>
            <View style={styles.comparisonRow}>
              <View style={styles.comparisonItem}>
                <Text style={styles.comparisonLabel}>Lowest</Text>
                <Text style={styles.comparisonValue}>
                  {quote.currency} {priceComparison.lowestPrice.toLocaleString()}
                </Text>
              </View>
              <View style={styles.comparisonItem}>
                <Text style={styles.comparisonLabel}>Average</Text>
                <Text style={styles.comparisonValue}>
                  {quote.currency} {priceComparison.averagePrice.toLocaleString()}
                </Text>
              </View>
              <View style={styles.comparisonItem}>
                <Text style={styles.comparisonLabel}>Your Max</Text>
                <Text style={styles.comparisonValue}>
                  {quote.currency} {quote.maxPrice.toLocaleString()}
                </Text>
              </View>
            </View>
            {!isOwner && (
              <TouchableOpacity
                style={styles.alertButton}
                onPress={handleCreatePriceAlert}>
                <Icon name="bell-outline" size={20} color={theme.colors.primary} />
                <Text style={styles.alertButtonText}>Get Price Alerts</Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        <View style={styles.card}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Bids ({bids.length})</Text>
            {canBid && (
              <TouchableOpacity
                style={styles.bidButton}
                onPress={() => navigation.navigate('Bid' as never, {quoteId} as never)}>
                <Text style={styles.bidButtonText}>Place Bid</Text>
                <Icon name="plus" size={16} color={theme.colors.background} />
              </TouchableOpacity>
            )}
          </View>

          {bids.length === 0 ? (
            <View style={styles.emptyBids}>
              <Icon name="tag-outline" size={48} color={theme.colors.textSecondary} />
              <Text style={styles.emptyBidsText}>No bids yet</Text>
            </View>
          ) : (
            <FlatList
              data={bids}
              keyExtractor={item => item.id}
              renderItem={({item}) => (
                <View style={styles.bidCard}>
                  <View style={styles.bidHeader}>
                    <View>
                      <Text style={styles.bidPrice}>
                        {quote.currency} {item.price.toLocaleString()}
                      </Text>
                      {item === bestBid && (
                        <Text style={styles.bestPriceBadge}>BEST PRICE</Text>
                      )}
                    </View>
                    <View style={styles.bidBadges}>
                      {item.isSelected && (
                        <View style={styles.selectedBadge}>
                          <Icon name="check-circle" size={16} color={theme.colors.success} />
                          <Text style={styles.selectedText}>Selected</Text>
                        </View>
                      )}
                      {item.sellerVerified && (
                        <View style={styles.verifiedBadge}>
                          <Icon name="shield-check" size={14} color={theme.colors.primary} />
                          <Text style={styles.verifiedText}>Verified</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <TouchableOpacity
                    style={styles.bidSellerRow}
                    onPress={() => navigation.navigate('UserProfile' as never, {userId: item.sellerId} as never)}>
                    <Text style={styles.bidSeller}>by {item.sellerName}</Text>
                    {item.sellerRating && (
                      <View style={styles.ratingBadge}>
                        <Icon name="star" size={14} color={theme.colors.warning} />
                        <Text style={styles.ratingText}>{item.sellerRating.toFixed(1)}</Text>
                      </View>
                    )}
                    {item.sellerResponseTime && (
                      <Text style={styles.responseTime}>
                        Responds in {Math.round(item.sellerResponseTime / 60)}h
                      </Text>
                    )}
                  </View>
                  {item.message && (
                    <Text style={styles.bidMessage}>{item.message}</Text>
                  )}
                  {item.deliveryTime && (
                    <Text style={styles.bidDetail}>
                      Delivery: {item.deliveryTime}
                    </Text>
                  )}
                  <Text style={styles.bidDate}>
                    {format(item.createdAt, 'MMM dd, yyyy HH:mm')}
                  </Text>
                </View>
              )}
              scrollEnabled={false}
            />
          )}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    padding: theme.spacing.lg,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  content: {
    padding: theme.spacing.lg,
  },
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  description: {
    fontSize: 16,
    color: theme.colors.textSecondary,
    lineHeight: 24,
    marginBottom: theme.spacing.md,
  },
  details: {
    marginBottom: theme.spacing.md,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  detailText: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.sm,
  },
  priceContainer: {
    paddingTop: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  priceLabel: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  price: {
    fontSize: 32,
    fontWeight: '700',
    color: theme.colors.primary,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
  },
  bidButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
  },
  bidButtonText: {
    color: theme.colors.background,
    fontSize: 14,
    fontWeight: '600',
    marginRight: theme.spacing.xs,
  },
  emptyBids: {
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  emptyBidsText: {
    fontSize: 16,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.sm,
  },
  bidCard: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.sm,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  bidHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.xs,
  },
  bidPrice: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.success,
  },
  selectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectedText: {
    fontSize: 12,
    color: theme.colors.success,
    fontWeight: '600',
    marginLeft: theme.spacing.xs,
  },
  bidMessage: {
    fontSize: 14,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  bidDetail: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  bidDate: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  instantPurchaseButton: {
    backgroundColor: theme.colors.success,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  instantPurchaseContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  instantPurchaseText: {
    marginLeft: theme.spacing.md,
  },
  instantPurchaseTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.background,
  },
  instantPurchaseSubtitle: {
    fontSize: 14,
    color: theme.colors.background,
    opacity: 0.9,
    marginTop: theme.spacing.xs,
  },
  savingsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.sm,
    backgroundColor: theme.colors.success + '20',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.md,
    alignSelf: 'flex-start',
  },
  savingsText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.success,
    marginLeft: theme.spacing.xs,
  },
  commitmentBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.sm,
    backgroundColor: theme.colors.info + '20',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.md,
    alignSelf: 'flex-start',
  },
  commitmentText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.info,
    marginLeft: theme.spacing.xs,
  },
  comparisonRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: theme.spacing.md,
    paddingVertical: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
  comparisonItem: {
    alignItems: 'center',
  },
  comparisonLabel: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  comparisonValue: {
    fontSize: 16,
    fontWeight: '700',
    color: theme.colors.text,
  },
  alertButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderWidth: 1,
    borderColor: theme.colors.primary,
    borderRadius: theme.borderRadius.md,
  },
  alertButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.primary,
    marginLeft: theme.spacing.xs,
  },
  bestPriceBadge: {
    fontSize: 10,
    fontWeight: '700',
    color: theme.colors.success,
    marginTop: theme.spacing.xs,
    textTransform: 'uppercase',
  },
  bidBadges: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.xs,
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary + '20',
    paddingHorizontal: theme.spacing.xs,
    paddingVertical: 2,
    borderRadius: theme.borderRadius.sm,
  },
  verifiedText: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.primary,
    marginLeft: 2,
  },
  bidSellerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.xs,
    flexWrap: 'wrap',
  },
  bidSeller: {
    fontSize: 14,
    color: theme.colors.primary,
    fontWeight: '600',
    marginBottom: theme.spacing.xs,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: theme.spacing.sm,
    backgroundColor: theme.colors.warning + '20',
    paddingHorizontal: theme.spacing.xs,
    paddingVertical: 2,
    borderRadius: theme.borderRadius.sm,
  },
  ratingText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.warning,
    marginLeft: 2,
  },
  responseTime: {
    fontSize: 11,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.sm,
  },
  linkText: {
    color: theme.colors.primary,
    textDecorationLine: 'underline',
  },
});

export default QuoteDetailScreen;

