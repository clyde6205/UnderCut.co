import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useLanguage} from '../../contexts/LanguageContext';
import {theme} from '../../theme/theme';

const LanguageScreen: React.FC = () => {
  const navigation = useNavigation();
  const {currentLanguage, supportedLanguages, changeLanguage, isLoading, t} = useLanguage();
  const [changing, setChanging] = useState(false);

  const handleLanguageSelect = async (languageCode: string) => {
    if (languageCode === currentLanguage) {
      return; // Already selected
    }

    setChanging(true);
    try {
      await changeLanguage(languageCode);
      Alert.alert(
        t('common.success'),
        t('language.languageChanged'),
        [{text: t('common.ok'), onPress: () => navigation.goBack()}]
      );
    } catch (error) {
      Alert.alert(t('common.error'), t('language.errorChangingLanguage'));
    } finally {
      setChanging(false);
    }
  };

  // Group languages by region for better organization
  const groupedLanguages = {
    popular: supportedLanguages.slice(0, 10),
    european: supportedLanguages.filter(lang => 
      ['de', 'fr', 'it', 'es', 'pt', 'ru', 'pl', 'nl', 'sv', 'da', 'fi', 'no', 'cs', 'hu', 'ro', 'el', 'uk', 'bg', 'hr', 'sk', 'sl'].includes(lang.code)
    ),
    asian: supportedLanguages.filter(lang =>
      ['zh', 'ja', 'ko', 'hi', 'th', 'vi', 'id', 'ms'].includes(lang.code)
    ),
    middleEastern: supportedLanguages.filter(lang =>
      ['ar', 'he', 'tr'].includes(lang.code)
    ),
  };

  const renderLanguageItem = (language: typeof supportedLanguages[0]) => {
    const isSelected = language.code === currentLanguage;
    
    return (
      <TouchableOpacity
        key={language.code}
        style={[
          styles.languageItem,
          isSelected && styles.languageItemSelected,
        ]}
        onPress={() => handleLanguageSelect(language.code)}
        disabled={changing || isLoading}>
        <View style={styles.languageContent}>
          <View style={styles.languageInfo}>
            <Text
              style={[
                styles.languageName,
                isSelected && styles.languageNameSelected,
              ]}>
              {language.nativeName}
            </Text>
            <Text
              style={[
                styles.languageEnglish,
                isSelected && styles.languageEnglishSelected,
              ]}>
              {language.name}
            </Text>
          </View>
          {isSelected && (
            <Icon name="check-circle" size={24} color={theme.colors.primary} />
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.title}>{t('language.title')}</Text>
          <Text style={styles.subtitle}>{t('language.subtitle')}</Text>
        </View>
      </View>

      {changing || isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
          <Text style={styles.loadingText}>{t('language.changingLanguage')}</Text>
        </View>
      ) : (
        <ScrollView style={styles.content}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>{t('language.currentLanguage')}</Text>
            <View style={styles.currentLanguageCard}>
              <Icon name="earth" size={32} color={theme.colors.primary} />
              <View style={styles.currentLanguageInfo}>
                <Text style={styles.currentLanguageName}>
                  {supportedLanguages.find(l => l.code === currentLanguage)?.nativeName}
                </Text>
                <Text style={styles.currentLanguageCode}>
                  {currentLanguage.toUpperCase()}
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Popular Languages</Text>
            {groupedLanguages.popular.map(renderLanguageItem)}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>European Languages</Text>
            {groupedLanguages.european.map(renderLanguageItem)}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Asian Languages</Text>
            {groupedLanguages.asian.map(renderLanguageItem)}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Middle Eastern & Other</Text>
            {groupedLanguages.middleEastern.map(renderLanguageItem)}
          </View>

          <View style={styles.footer}>
            <Icon name="information" size={20} color={theme.colors.textSecondary} />
            <Text style={styles.footerText}>
              {t('app.globalPlatform')} - Available in {supportedLanguages.length} languages
            </Text>
          </View>
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  headerContent: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: theme.spacing.md,
    fontSize: 16,
    color: theme.colors.textSecondary,
  },
  content: {
    flex: 1,
  },
  section: {
    padding: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  currentLanguageCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary + '20',
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    borderWidth: 2,
    borderColor: theme.colors.primary,
  },
  currentLanguageInfo: {
    marginLeft: theme.spacing.md,
    flex: 1,
  },
  currentLanguageName: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.primary,
    marginBottom: theme.spacing.xs,
  },
  currentLanguageCode: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    fontWeight: '600',
  },
  languageItem: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.sm,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  languageItemSelected: {
    backgroundColor: theme.colors.primary + '20',
    borderColor: theme.colors.primary,
    borderWidth: 2,
  },
  languageContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  languageInfo: {
    flex: 1,
  },
  languageName: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  languageNameSelected: {
    color: theme.colors.primary,
  },
  languageEnglish: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  languageEnglishSelected: {
    color: theme.colors.primary,
    opacity: 0.8,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
  },
  footerText: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.sm,
    textAlign: 'center',
  },
});

export default LanguageScreen;

