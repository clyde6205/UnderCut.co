import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Clipboard from '@react-native-clipboard/clipboard';
import {getConfig, updateSupportEmail, updateSupportPhone, updateSupportHours} from '../../config/appConfig';
import {useLanguage} from '../../contexts/LanguageContext';
import {theme} from '../../theme/theme';

const SupportScreen: React.FC = () => {
  const {t} = useLanguage();
  const {user} = useAuth();
  const [config, setConfig] = useState(getConfig());
  const [isEditing, setIsEditing] = useState(false);
  const [supportEmail, setSupportEmail] = useState(config.supportEmail || 'clydeusa@zohomail.com');
  const [supportPhone, setSupportPhone] = useState(config.supportPhone || '');
  const [supportHours, setSupportHours] = useState(config.supportHours || '');

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = () => {
    const currentConfig = getConfig();
    setConfig(currentConfig);
    setSupportEmail(currentConfig.supportEmail || 'clydeusa@zohomail.com');
    setSupportPhone(currentConfig.supportPhone || '');
    setSupportHours(currentConfig.supportHours || '');
  };

  const handleSave = async () => {
    try {
      await updateSupportEmail(supportEmail);
      if (supportPhone) {
        await updateSupportPhone(supportPhone);
      }
      if (supportHours) {
        await updateSupportHours(supportHours);
      }
      setIsEditing(false);
      loadConfig();
      Alert.alert('Success', 'Support information updated successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to update support information');
      console.error(error);
    }
  };

  const handleEmailPress = () => {
    const email = config.supportEmail || 'clydeusa@zohomail.com';
    const mailtoUrl = `mailto:${email}?subject=UnderCut.Co Support Request`;
    Linking.openURL(mailtoUrl).catch(() => {
      Clipboard.setString(email);
      Alert.alert('Email Copied', `Email address copied to clipboard: ${email}`);
    });
  };

  const handlePhonePress = () => {
    if (config.supportPhone) {
      const phoneUrl = `tel:${config.supportPhone}`;
      Linking.openURL(phoneUrl).catch(() => {
        Clipboard.setString(config.supportPhone!);
        Alert.alert('Phone Copied', `Phone number copied to clipboard: ${config.supportPhone}`);
      });
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    Clipboard.setString(text);
    Alert.alert('Copied', `${label} copied to clipboard`);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="help-circle" size={48} color={theme.colors.primary} />
        <Text style={styles.title}>Support</Text>
        <Text style={styles.subtitle}>Get help and contact us</Text>
      </View>

      <View style={styles.content}>
        {/* Support Email Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Contact Email</Text>
            {(user?.role === 'admin' || user?.role === 'founder') && (
              <TouchableOpacity
                style={styles.editButton}
                onPress={() => setIsEditing(!isEditing)}>
                <Icon
                  name={isEditing ? 'close' : 'pencil'}
                  size={20}
                  color={theme.colors.primary}
                />
                <Text style={styles.editButtonText}>
                  {isEditing ? 'Cancel' : 'Edit'}
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {isEditing && (user?.role === 'admin' || user?.role === 'founder') ? (
            <View style={styles.editContainer}>
              <Text style={styles.label}>Support Email</Text>
              <View style={styles.inputContainer}>
                <Icon name="email" size={20} color={theme.colors.textSecondary} />
                <TextInput
                  style={styles.input}
                  value={supportEmail}
                  onChangeText={setSupportEmail}
                  placeholder="support@undercut.co"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
              <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                <Icon name="check" size={20} color={theme.colors.background} />
                <Text style={styles.saveButtonText}>Save Changes</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity
              style={styles.contactCard}
              onPress={handleEmailPress}
              activeOpacity={0.7}>
              <View style={styles.contactIcon}>
                <Icon name="email" size={32} color={theme.colors.primary} />
              </View>
              <View style={styles.contactInfo}>
                <Text style={styles.contactLabel}>Email Support</Text>
                <Text style={styles.contactValue}>
                  {config.supportEmail || 'clydeusa@zohomail.com'}
                </Text>
              </View>
              <TouchableOpacity
                style={styles.copyButton}
                onPress={() =>
                  copyToClipboard(
                    config.supportEmail || 'clydeusa@zohomail.com',
                    'Email address',
                  )
                }>
                <Icon name="content-copy" size={20} color={theme.colors.textSecondary} />
              </TouchableOpacity>
              <Icon name="chevron-right" size={24} color={theme.colors.textSecondary} />
            </TouchableOpacity>
          )}
        </View>

        {/* Support Phone Section (Optional) */}
        {(config.supportPhone || isEditing) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Phone Support</Text>
            {isEditing && (user?.role === 'admin' || user?.role === 'founder') ? (
              <View style={styles.editContainer}>
                <Text style={styles.label}>Support Phone</Text>
                <View style={styles.inputContainer}>
                  <Icon name="phone" size={20} color={theme.colors.textSecondary} />
                  <TextInput
                    style={styles.input}
                    value={supportPhone}
                    onChangeText={setSupportPhone}
                    placeholder="+1 (555) 123-4567"
                    keyboardType="phone-pad"
                  />
                </View>
                <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                  <Icon name="check" size={20} color={theme.colors.background} />
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </TouchableOpacity>
              </View>
            ) : config.supportPhone ? (
              <TouchableOpacity
                style={styles.contactCard}
                onPress={handlePhonePress}
                activeOpacity={0.7}>
                <View style={styles.contactIcon}>
                  <Icon name="phone" size={32} color={theme.colors.primary} />
                </View>
                <View style={styles.contactInfo}>
                  <Text style={styles.contactLabel}>Phone Support</Text>
                  <Text style={styles.contactValue}>{config.supportPhone}</Text>
                </View>
                <TouchableOpacity
                  style={styles.copyButton}
                  onPress={() => copyToClipboard(config.supportPhone!, 'Phone number')}>
                  <Icon name="content-copy" size={20} color={theme.colors.textSecondary} />
                </TouchableOpacity>
                <Icon name="chevron-right" size={24} color={theme.colors.textSecondary} />
              </TouchableOpacity>
            ) : null}
          </View>
        )}

        {/* Support Hours Section (Optional) */}
        {(config.supportHours || isEditing) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Support Hours</Text>
            {isEditing && (user?.role === 'admin' || user?.role === 'founder') ? (
              <View style={styles.editContainer}>
                <Text style={styles.label}>Support Hours</Text>
                <View style={styles.inputContainer}>
                  <Icon name="clock" size={20} color={theme.colors.textSecondary} />
                  <TextInput
                    style={styles.input}
                    value={supportHours}
                    onChangeText={setSupportHours}
                    placeholder="Mon-Fri 9AM-5PM EST"
                  />
                </View>
                <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                  <Icon name="check" size={20} color={theme.colors.background} />
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </TouchableOpacity>
              </View>
            ) : config.supportHours ? (
              <View style={styles.hoursCard}>
                <Icon name="clock-outline" size={24} color={theme.colors.primary} />
                <Text style={styles.hoursText}>{config.supportHours}</Text>
              </View>
            ) : null}
          </View>
        )}

        {/* Help Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How Can We Help?</Text>
          <View style={styles.helpCard}>
            <Icon name="information" size={24} color={theme.colors.info} />
            <View style={styles.helpContent}>
              <Text style={styles.helpText}>
                Need assistance? Contact our support team via email. We're here to help with:
              </Text>
              <View style={styles.helpList}>
                <Text style={styles.helpItem}>• Account issues and questions</Text>
                <Text style={styles.helpItem}>• Transaction support</Text>
                <Text style={styles.helpItem}>• Platform features and usage</Text>
                <Text style={styles.helpItem}>• Technical problems</Text>
                <Text style={styles.helpItem}>• General inquiries</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={handleEmailPress}>
            <Icon name="email-outline" size={24} color={theme.colors.primary} />
            <Text style={styles.actionButtonText}>Send Email</Text>
            <Icon name="chevron-right" size={24} color={theme.colors.textSecondary} />
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  content: {
    padding: theme.spacing.lg,
  },
  section: {
    marginBottom: theme.spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
  },
  editButtonText: {
    fontSize: 14,
    color: theme.colors.primary,
    marginLeft: theme.spacing.xs,
    fontWeight: '600',
  },
  contactCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  contactIcon: {
    width: 56,
    height: 56,
    borderRadius: theme.borderRadius.full,
    backgroundColor: theme.colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: theme.spacing.md,
  },
  contactInfo: {
    flex: 1,
  },
  contactLabel: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  contactValue: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
  },
  copyButton: {
    padding: theme.spacing.sm,
    marginRight: theme.spacing.sm,
  },
  hoursCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  hoursText: {
    fontSize: 16,
    color: theme.colors.text,
    marginLeft: theme.spacing.md,
    fontWeight: '600',
  },
  editContainer: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    paddingHorizontal: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: theme.colors.text,
    paddingVertical: theme.spacing.sm,
    marginLeft: theme.spacing.sm,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.background,
    marginLeft: theme.spacing.sm,
  },
  helpCard: {
    flexDirection: 'row',
    backgroundColor: theme.colors.info + '20',
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.info + '40',
  },
  helpContent: {
    flex: 1,
    marginLeft: theme.spacing.md,
  },
  helpText: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 20,
    marginBottom: theme.spacing.sm,
  },
  helpList: {
    marginLeft: theme.spacing.sm,
  },
  helpItem: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 24,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  actionButtonText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    marginLeft: theme.spacing.md,
  },
});

export default SupportScreen;

