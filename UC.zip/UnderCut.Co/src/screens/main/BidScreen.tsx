import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import firestore from '@react-native-firebase/firestore';
import {useAuth} from '../../contexts/AuthContext';
import {useAutoTrackUsage} from '../../hooks/usePlatformUsage';
import {Quote, Bid} from '../../types';
import {theme} from '../../theme/theme';

type BidRouteParams = {
  Bid: {
    quoteId: string;
  };
};

const BidScreen: React.FC = () => {
  const route = useRoute<RouteProp<BidRouteParams, 'Bid'>>();
  const navigation = useNavigation();
  const {user} = useAuth();
  const {onBidSubmitted} = useAutoTrackUsage();
  const {quoteId} = route.params;
  const [quote, setQuote] = useState<Quote | null>(null);
  const [price, setPrice] = useState('');
  const [message, setMessage] = useState('');
  const [deliveryTime, setDeliveryTime] = useState('');
  const [warranty, setWarranty] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadQuote();
  }, [quoteId]);

  const loadQuote = async () => {
    try {
      const doc = await firestore().collection('quotes').doc(quoteId).get();
      if (doc.exists) {
        const data = doc.data();
        setQuote({
          id: doc.id,
          ...data,
          createdAt: data?.createdAt?.toDate() || new Date(),
          expiresAt: data?.expiresAt?.toDate() || new Date(),
        } as Quote);
      }
    } catch (error) {
      console.error('Error loading quote:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitBid = async () => {
    if (!price || !user || !quote) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const bidPrice = parseFloat(price);
    if (isNaN(bidPrice) || bidPrice <= 0) {
      Alert.alert('Error', 'Please enter a valid price');
      return;
    }

    if (bidPrice > quote.maxPrice) {
      Alert.alert('Error', 'Your bid cannot exceed the maximum price');
      return;
    }

    setSubmitting(true);
    try {
      const bidData: Omit<Bid, 'id'> = {
        quoteId,
        sellerId: user.id,
        sellerName: user.displayName,
        price: bidPrice,
        currency: quote.currency,
        message: message || undefined,
        deliveryTime: deliveryTime || undefined,
        warranty: warranty || undefined,
        createdAt: new Date(),
        isSelected: false,
      };

      await firestore().collection('bids').add({
        ...bidData,
        createdAt: firestore.FieldValue.serverTimestamp(),
      });

      // Track platform usage for chat eligibility
      await onBidSubmitted();
      
      Alert.alert('Success', 'Your bid has been submitted!', [
        {text: 'OK', onPress: () => navigation.goBack()},
      ]);
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to submit bid');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !quote) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Place Your Bid</Text>
      </View>

      <View style={styles.quoteCard}>
        <Text style={styles.quoteTitle}>{quote.title}</Text>
        <Text style={styles.maxPrice}>
          Max Price: {quote.currency} {quote.maxPrice.toLocaleString()}
        </Text>
      </View>

      <View style={styles.form}>
        <Text style={styles.label}>Your Price *</Text>
        <TextInput
          style={styles.input}
          placeholder={`Enter price in ${quote.currency}`}
          value={price}
          onChangeText={setPrice}
          keyboardType="numeric"
        />
        <Text style={styles.hint}>
          Enter your lowest price. Lower is better for winning the bid.
        </Text>

        <Text style={styles.label}>Message (Optional)</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Add a message to your bid..."
          value={message}
          onChangeText={setMessage}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />

        <Text style={styles.label}>Delivery Time (Optional)</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g., 5-7 business days"
          value={deliveryTime}
          onChangeText={setDeliveryTime}
        />

        <Text style={styles.label}>Warranty (Optional)</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g., 1 year manufacturer warranty"
          value={warranty}
          onChangeText={setWarranty}
        />

        <TouchableOpacity
          style={[styles.submitButton, submitting && styles.submitButtonDisabled]}
          onPress={handleSubmitBid}
          disabled={submitting}>
          {submitting ? (
            <ActivityIndicator color={theme.colors.background} />
          ) : (
            <Text style={styles.submitButtonText}>Submit Bid</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.text,
  },
  quoteCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    margin: theme.spacing.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  quoteTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  maxPrice: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  form: {
    padding: theme.spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
    marginTop: theme.spacing.md,
  },
  input: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    fontSize: 16,
    color: theme.colors.text,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  textArea: {
    height: 100,
    paddingTop: theme.spacing.md,
  },
  hint: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  submitButton: {
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
    marginTop: theme.spacing.xl,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
});

export default BidScreen;

