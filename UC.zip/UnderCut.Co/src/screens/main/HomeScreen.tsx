import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  RefreshControl,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import firestore from '@react-native-firebase/firestore';
import {useAuth} from '../../contexts/AuthContext';
import {Quote, CategoryLevel} from '../../types';
import {theme} from '../../theme/theme';
import {QuoteCard} from '../../components/QuoteCard';
import {CategoryFilter} from '../../components/CategoryFilter';
import {CopyrightNotice} from '../../components/CopyrightNotice';

type HomeStackParamList = {
  HomeMain: undefined;
  QuoteDetail: {quoteId: string};
  Bid: {quoteId: string};
};

type HomeScreenNavigationProp = StackNavigationProp<HomeStackParamList, 'HomeMain'>;

const HomeScreen: React.FC = () => {
  const navigation = useNavigation<HomeScreenNavigationProp>();
  const {user} = useAuth();
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<CategoryLevel | 'all'>('all');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadQuotes();
  }, [selectedCategory]);

  const loadQuotes = async () => {
    try {
      let query = firestore()
        .collection('quotes')
        .where('status', '==', 'quote_posted')
        .orderBy('createdAt', 'desc')
        .limit(50);

      if (selectedCategory !== 'all') {
        query = query.where('categoryLevel', '==', selectedCategory) as any;
      }

      const snapshot = await query.get();
      const quotesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        expiresAt: doc.data().expiresAt?.toDate() || new Date(),
      })) as Quote[];

      setQuotes(quotesData);
    } catch (error) {
      console.error('Error loading quotes:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadQuotes();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>UnderCut.Co</Text>
          <View style={styles.globalBadge}>
            <Icon name="earth" size={16} color={theme.colors.global} />
            <Text style={styles.globalText}>Global Platform</Text>
          </View>
        </View>
        {user && (
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{user.displayName}</Text>
            <Text style={styles.userRole}>{user.role === 'buyer' ? 'Buyer' : 'Seller'}</Text>
          </View>
        )}
      </View>

      <View style={styles.banner}>
        <Icon name="information" size={20} color={theme.colors.warning} />
        <Text style={styles.bannerText}>
          <Text style={styles.bold}>Focused buyers only.</Text> You know what you want.
          Find the <Text style={styles.bold}>lowest price</Text> here.
        </Text>
      </View>

      <CategoryFilter
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      <FlatList
        data={quotes}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <QuoteCard
            quote={item}
            onPress={() => navigation.navigate('QuoteDetail', {quoteId: item.id})}
            showBidButton={user?.role === 'seller'}
            onBid={() => navigation.navigate('Bid', {quoteId: item.id})}
          />
        )}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="file-question" size={64} color={theme.colors.textSecondary} />
            <Text style={styles.emptyText}>No quotes available</Text>
            <Text style={styles.emptySubtext}>
              Check back later or post your own quote
            </Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.primary,
  },
  globalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.xs,
  },
  globalText: {
    fontSize: 12,
    color: theme.colors.global,
    marginLeft: theme.spacing.xs,
    fontWeight: '600',
  },
  userInfo: {
    alignItems: 'flex-end',
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
  },
  userRole: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    textTransform: 'capitalize',
  },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.warning + '20',
    padding: theme.spacing.md,
    marginHorizontal: theme.spacing.lg,
    marginTop: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
  },
  bannerText: {
    flex: 1,
    fontSize: 13,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    lineHeight: 18,
  },
  bold: {
    fontWeight: '700',
  },
  listContent: {
    padding: theme.spacing.lg,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.xxl,
    marginTop: theme.spacing.xxl,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
  },
  emptySubtext: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    textAlign: 'center',
  },
});

export default HomeScreen;

