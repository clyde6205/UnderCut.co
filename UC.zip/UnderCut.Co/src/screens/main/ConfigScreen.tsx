import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  Switch,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useConfig} from '../../contexts/ConfigContext';
import {theme} from '../../theme/theme';

const ConfigScreen: React.FC = () => {
  const {config, updateConfig, updateTimeout, updatePayment} = useConfig();
  const [transactionTimeout, setTransactionTimeout] = useState(
    config?.transactionTimeoutHours?.toString() || '72'
  );

  const handleUpdateTimeout = async () => {
    const hours = parseInt(transactionTimeout, 10);
    if (isNaN(hours) || hours < 1) {
      Alert.alert('Error', 'Please enter a valid number of hours (minimum 1)');
      return;
    }

    try {
      await updateTimeout(hours);
      Alert.alert('Success', `Transaction timeout updated to ${hours} hours`);
    } catch (error) {
      Alert.alert('Error', 'Failed to update transaction timeout');
    }
  };

  const handleUpdatePaymentProcessor = async (processor: 'stripe' | 'xrp' | 'custom') => {
    try {
      await updatePayment(processor);
      Alert.alert('Success', `Payment processor updated to ${processor.toUpperCase()}`);
    } catch (error) {
      Alert.alert('Error', 'Failed to update payment processor');
    }
  };

  if (!config) {
    return (
      <View style={styles.container}>
        <Text>Loading configuration...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="cog" size={48} color={theme.colors.primary} />
        <Text style={styles.title}>Platform Configuration</Text>
        <Text style={styles.subtitle}>
          Editable settings for transaction timing and payment processing
        </Text>
      </View>

      <View style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Transaction Timing (Editable)</Text>
          <Text style={styles.description}>
            Configure how long transactions remain open before the deal closure window expires.
          </Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Transaction Timeout (Hours)</Text>
            <TextInput
              style={styles.input}
              value={transactionTimeout}
              onChangeText={setTransactionTimeout}
              keyboardType="numeric"
              placeholder="72"
            />
            <Text style={styles.hint}>
              Current: {config.transactionTimeoutHours} hours
            </Text>
            <TouchableOpacity
              style={styles.updateButton}
              onPress={handleUpdateTimeout}>
              <Text style={styles.updateButtonText}>Update Timeout</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.infoCard}>
            <Icon name="information" size={20} color={theme.colors.info} />
            <Text style={styles.infoText}>
              This setting controls how long buyers have to select a bid and initiate escrow.
              After this time, quotes expire.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Processor (Editable)</Text>
          <Text style={styles.description}>
            Select the primary payment processor. This setting is fully editable.
          </Text>

          <View style={styles.paymentOptions}>
            <TouchableOpacity
              style={[
                styles.paymentOption,
                config.paymentProcessor === 'stripe' && styles.paymentOptionActive,
              ]}
              onPress={() => handleUpdatePaymentProcessor('stripe')}>
              <Icon
                name="credit-card"
                size={32}
                color={config.paymentProcessor === 'stripe' ? theme.colors.background : theme.colors.textSecondary}
              />
              <Text
                style={[
                  styles.paymentOptionText,
                  config.paymentProcessor === 'stripe' && styles.paymentOptionTextActive,
                ]}>
                Stripe
              </Text>
              {config.paymentProcessor === 'stripe' && (
                <Icon name="check-circle" size={20} color={theme.colors.background} />
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.paymentOption,
                config.paymentProcessor === 'xrp' && styles.paymentOptionActive,
              ]}
              onPress={() => handleUpdatePaymentProcessor('xrp')}>
              <Icon
                name="currency-xrp"
                size={32}
                color={config.paymentProcessor === 'xrp' ? theme.colors.background : theme.colors.textSecondary}
              />
              <Text
                style={[
                  styles.paymentOptionText,
                  config.paymentProcessor === 'xrp' && styles.paymentOptionTextActive,
                ]}>
                XRP / Ripple
              </Text>
              {config.paymentProcessor === 'xrp' && (
                <Icon name="check-circle" size={20} color={theme.colors.background} />
              )}
            </TouchableOpacity>
          </View>

          <View style={styles.infoCard}>
            <Icon name="alert-circle" size={20} color={theme.colors.warning} />
            <Text style={styles.infoText}>
              <Text style={styles.bold}>Important:</Text> Payment processing is handled entirely by
              the selected processor. UnderCut.Co never holds or stores customer money.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Current Configuration</Text>
          <View style={styles.configCard}>
            <View style={styles.configRow}>
              <Text style={styles.configLabel}>Transaction Timeout:</Text>
              <Text style={styles.configValue}>{config.transactionTimeoutHours} hours</Text>
            </View>
            <View style={styles.configRow}>
              <Text style={styles.configLabel}>Escrow Cool-Down:</Text>
              <Text style={styles.configValue}>{config.escrowCoolDownHours} hours</Text>
            </View>
            <View style={styles.configRow}>
              <Text style={styles.configLabel}>Payment Processor:</Text>
              <Text style={styles.configValue}>{config.paymentProcessor.toUpperCase()}</Text>
            </View>
            <View style={styles.configRow}>
              <Text style={styles.configLabel}>Blockchain Network:</Text>
              <Text style={styles.configValue}>{config.blockchainNetwork}</Text>
            </View>
          </View>
        </View>

        <View style={styles.warningCard}>
          <Icon name="shield-alert" size={24} color={theme.colors.warning} />
          <Text style={styles.warningText}>
            Configuration changes affect all new transactions. Existing transactions will continue
            with their original settings.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  content: {
    padding: theme.spacing.lg,
  },
  section: {
    marginBottom: theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  description: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.md,
    lineHeight: 20,
  },
  inputGroup: {
    marginBottom: theme.spacing.md,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  input: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    fontSize: 16,
    color: theme.colors.text,
    borderWidth: 1,
    borderColor: theme.colors.border,
    marginBottom: theme.spacing.xs,
  },
  hint: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.sm,
  },
  updateButton: {
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
  },
  updateButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  paymentOptions: {
    flexDirection: 'row',
    gap: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },
  paymentOption: {
    flex: 1,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  paymentOptionActive: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  paymentOptionText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.sm,
  },
  paymentOptionTextActive: {
    color: theme.colors.background,
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: theme.colors.info + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.info + '40',
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    lineHeight: 18,
  },
  configCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  configRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: theme.spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  configLabel: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  configValue: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
  },
  warningCard: {
    flexDirection: 'row',
    backgroundColor: theme.colors.warning + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.warning + '40',
  },
  warningText: {
    flex: 1,
    fontSize: 13,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    lineHeight: 18,
  },
  bold: {
    fontWeight: '700',
  },
});

export default ConfigScreen;

