import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAuth} from '../../contexts/AuthContext';
import {useLanguage} from '../../contexts/LanguageContext';
import {CopyrightNotice} from '../../components/CopyrightNotice';
import {theme} from '../../theme/theme';

const ProfileScreen: React.FC = () => {
  const navigation = useNavigation();
  const {user, signOut} = useAuth();
  const {t} = useLanguage();

  const menuItems = [
    {
      icon: 'file-document',
      title: t('profile.termsOfService'),
      onPress: () => navigation.navigate('Terms' as never),
    },
    {
      icon: 'scale-balance',
      title: t('profile.legalDisclaimers'),
      onPress: () => navigation.navigate('Legal' as never),
    },
    {
      icon: 'cog',
      title: t('profile.platformConfiguration'),
      onPress: () => navigation.navigate('Config' as never),
    },
    {
      icon: 'translate',
      title: t('profile.language'),
      onPress: () => navigation.navigate('Language' as never),
    },
    {
      icon: 'account-group',
      title: 'Referral Program',
      onPress: () => navigation.navigate('Referral' as never),
    },
    {
      icon: 'chat-processing',
      title: 'ChatMe.Pro',
      onPress: () => navigation.navigate('ChatList' as never),
      color: theme.colors.info,
    },
    {
      icon: 'shield-check',
      title: 'Copyright & Legal',
      onPress: () => navigation.navigate('Copyright' as never),
      color: theme.colors.textSecondary,
    },
    {
      icon: 'help-circle',
      title: 'Support',
      onPress: () => navigation.navigate('Support' as never),
      color: theme.colors.info,
    },
    {
      icon: 'heart',
      title: 'Favorites',
      onPress: () => navigation.navigate('Favorites' as never),
      color: theme.colors.error,
    },
    ...(user?.role === 'admin' || user?.role === 'founder'
      ? [
          {
            icon: 'shield-crown',
            title: 'Founders Console',
            onPress: () => navigation.navigate('Dashboard' as never),
            color: theme.colors.primary,
          },
        ]
      : []),
    {
      icon: 'logout',
      title: t('auth.signOut'),
      onPress: signOut,
      color: theme.colors.error,
    },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Icon name="account-circle" size={80} color={theme.colors.primary} />
        </View>
        <Text style={styles.name}>{user?.displayName || 'User'}</Text>
        <Text style={styles.email}>{user?.email}</Text>
        <View style={styles.roleBadge}>
          <Text style={styles.roleText}>
            {user?.role === 'buyer' ? t('auth.imBuyer') : t('auth.imSeller')}
          </Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('profile.accountInformation')}</Text>
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>{t('profile.totalTransactions')}</Text>
            <Text style={styles.infoValue}>{user?.totalTransactions || 0}</Text>
          </View>
          {user?.rating && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>{t('profile.rating')}</Text>
              <View style={styles.rating}>
                <Icon name="star" size={16} color={theme.colors.warning} />
                <Text style={styles.infoValue}>{user.rating.toFixed(1)}</Text>
              </View>
            </View>
          )}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('profile.settings')}</Text>
        {menuItems.map((item, index) => (
          <TouchableOpacity
            key={index}
            style={styles.menuItem}
            onPress={item.onPress}>
            <Icon
              name={item.icon}
              size={24}
              color={item.color || theme.colors.textSecondary}
            />
            <Text
              style={[
                styles.menuItemText,
                item.color && {color: item.color},
              ]}>
              {item.title}
            </Text>
            <Icon name="chevron-right" size={20} color={theme.colors.textSecondary} />
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>{t('app.name')}</Text>
        <View style={styles.globalBadge}>
          <Icon name="earth" size={14} color={theme.colors.global} />
          <Text style={styles.globalText}>{t('app.globalPlatform')}</Text>
        </View>
        <CopyrightNotice variant="compact" />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  avatar: {
    marginBottom: theme.spacing.md,
  },
  name: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  email: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.sm,
  },
  roleBadge: {
    backgroundColor: theme.colors.primary + '20',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.full,
  },
  roleText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.primary,
    textTransform: 'uppercase',
  },
  section: {
    padding: theme.spacing.lg,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  infoCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  infoLabel: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.sm,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  menuItemText: {
    flex: 1,
    fontSize: 16,
    color: theme.colors.text,
    marginLeft: theme.spacing.md,
  },
  footer: {
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  footerText: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  globalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  globalText: {
    fontSize: 12,
    color: theme.colors.global,
    marginLeft: theme.spacing.xs,
    fontWeight: '600',
  },
});

export default ProfileScreen;

