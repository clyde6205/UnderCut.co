import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import firestore from '@react-native-firebase/firestore';
import {useAuth} from '../../contexts/AuthContext';
import {Transaction} from '../../types';
import {theme} from '../../theme/theme';
import {format} from 'date-fns';
import {releaseEscrow} from '../../services/escrow';

type TransactionDetailRouteParams = {
  TransactionDetail: {
    transactionId: string;
  };
};

const TransactionDetailScreen: React.FC = () => {
  const route = useRoute<RouteProp<TransactionDetailRouteParams, 'TransactionDetail'>>();
  const navigation = useNavigation();
  const {user} = useAuth();
  const {transactionId} = route.params;
  const [transaction, setTransaction] = useState<Transaction | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    loadTransaction();
  }, [transactionId]);

  const loadTransaction = async () => {
    try {
      const doc = await firestore().collection('transactions').doc(transactionId).get();
      if (doc.exists) {
        const data = doc.data();
        setTransaction({
          id: doc.id,
          ...data,
          createdAt: data?.createdAt?.toDate() || new Date(),
          expiresAt: data?.expiresAt?.toDate() || new Date(),
          completedAt: data?.completedAt?.toDate(),
          coolDownEndsAt: data?.coolDownEndsAt?.toDate(),
        } as Transaction);
      }
    } catch (error) {
      console.error('Error loading transaction:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReleaseEscrow = async () => {
    Alert.alert(
      'Release Escrow',
      'Are you sure you want to release the escrow funds? This action cannot be undone.',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Release',
          style: 'destructive',
          onPress: async () => {
            setProcessing(true);
            try {
              await releaseEscrow(transactionId);
              Alert.alert('Success', 'Escrow has been released');
              await loadTransaction();
            } catch (error: any) {
              Alert.alert('Error', error.message || 'Failed to release escrow');
            } finally {
              setProcessing(false);
            }
          },
        },
      ]
    );
  };

  if (loading || !transaction) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  const isBuyer = user?.id === transaction.buyerId;
  const isSeller = user?.id === transaction.sellerId;
  const canRelease = isBuyer && transaction.status === 'escrow_initiated';

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Transaction Details</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Transaction Information</Text>
          
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Transaction ID</Text>
            <Text style={styles.infoValue}>{transaction.id.slice(0, 16)}...</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Status</Text>
            <View
              style={[
                styles.statusBadge,
                {
                  backgroundColor:
                    transaction.status === 'completed'
                      ? theme.colors.success + '20'
                      : theme.colors.info + '20',
                },
              ]}>
              <Text
                style={[
                  styles.statusText,
                  {
                    color:
                      transaction.status === 'completed'
                        ? theme.colors.success
                        : theme.colors.info,
                  },
                ]}>
                {transaction.status.replace('_', ' ').toUpperCase()}
              </Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Amount</Text>
            <Text style={styles.amount}>
              {transaction.currency} {transaction.amount.toLocaleString()}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Payment Method</Text>
            <View style={styles.paymentMethod}>
              <Icon
                name={transaction.paymentMethod === 'stripe' ? 'credit-card' : 'currency-xrp'}
                size={16}
                color={theme.colors.textSecondary}
              />
              <Text style={styles.infoValue}>
                {transaction.paymentMethod.toUpperCase()}
              </Text>
            </View>
          </View>

          {transaction.blockchainTxHash && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Blockchain Transaction</Text>
              <View style={styles.blockchainRow}>
                <Icon name="link-variant" size={16} color={theme.colors.info} />
                <Text style={styles.blockchainHash} numberOfLines={1}>
                  {transaction.blockchainTxHash.slice(0, 20)}...
                </Text>
              </View>
            </View>
          )}

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Created At</Text>
            <Text style={styles.infoValue}>
              {format(transaction.createdAt, 'MMM dd, yyyy HH:mm')}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Expires At</Text>
            <Text style={styles.infoValue}>
              {format(transaction.expiresAt, 'MMM dd, yyyy HH:mm')}
            </Text>
          </View>

          {transaction.completedAt && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Completed At</Text>
              <Text style={styles.infoValue}>
                {format(transaction.completedAt, 'MMM dd, yyyy HH:mm')}
              </Text>
            </View>
          )}
        </View>

        {transaction.escrowAddress && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Escrow Information</Text>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Escrow Address</Text>
              <Text style={styles.infoValue} numberOfLines={1}>
                {transaction.escrowAddress.slice(0, 20)}...
              </Text>
            </View>
          </View>
        )}

        {canRelease && (
          <TouchableOpacity
            style={[styles.releaseButton, processing && styles.releaseButtonDisabled]}
            onPress={handleReleaseEscrow}
            disabled={processing}>
            {processing ? (
              <ActivityIndicator color={theme.colors.background} />
            ) : (
              <>
                <Icon name="lock-open" size={20} color={theme.colors.background} />
                <Text style={styles.releaseButtonText}>Release Escrow</Text>
              </>
            )}
          </TouchableOpacity>
        )}

        <View style={styles.warningCard}>
          <Icon name="alert-circle" size={24} color={theme.colors.warning} />
          <Text style={styles.warningText}>
            <Text style={styles.bold}>NO REFUNDS POLICY:</Text> Due to internal Escrow
            cool-down periods that allow transaction continuation, all transactions are
            final. Legal disputes must be resolved directly between buyers and sellers.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.text,
  },
  content: {
    padding: theme.spacing.lg,
  },
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
    paddingBottom: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  infoLabel: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    flex: 1,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    flex: 1,
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '700',
  },
  amount: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.primary,
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  blockchainRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  blockchainHash: {
    fontSize: 12,
    color: theme.colors.info,
    marginLeft: theme.spacing.xs,
    fontFamily: 'monospace',
  },
  releaseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.success,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },
  releaseButtonDisabled: {
    opacity: 0.6,
  },
  releaseButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
    marginLeft: theme.spacing.sm,
  },
  warningCard: {
    flexDirection: 'row',
    backgroundColor: theme.colors.warning + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.warning + '40',
  },
  warningText: {
    flex: 1,
    fontSize: 12,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    lineHeight: 18,
  },
  bold: {
    fontWeight: '700',
  },
});

export default TransactionDetailScreen;

