/**
 * User Profile Screen
 * 
 * Simple profile view for other users - view and add to favorites
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import {useRoute, useNavigation, RouteProp} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import firestore from '@react-native-firebase/firestore';
import {useAuth} from '../../contexts/AuthContext';
import {User} from '../../types';
import {theme} from '../../theme/theme';
import {addToFavorites, removeFromFavorites, isFavorite} from '../../services/favorites';
import {format} from 'date-fns';

type UserProfileRouteParams = {
  UserProfile: {
    userId: string;
  };
};

const UserProfileScreen: React.FC = () => {
  const route = useRoute<RouteProp<UserProfileRouteParams, 'UserProfile'>>();
  const navigation = useNavigation();
  const {user: currentUser} = useAuth();
  const {userId} = route.params;
  
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [favorite, setFavorite] = useState(false);
  const [togglingFavorite, setTogglingFavorite] = useState(false);

  useEffect(() => {
    loadUserProfile();
    checkFavoriteStatus();
  }, [userId, currentUser]);

  const loadUserProfile = async () => {
    try {
      const userDoc = await firestore().collection('users').doc(userId).get();
      if (userDoc.exists) {
        const data = userDoc.data();
        setUser({
          id: userDoc.id,
          email: data?.email || '',
          displayName: data?.displayName || '',
          role: data?.role || 'buyer',
          verified: data?.verified || false,
          createdAt: data?.createdAt?.toDate() || new Date(),
          profileImage: data?.profileImage,
          location: data?.location,
          rating: data?.rating,
          totalTransactions: data?.totalTransactions || 0,
          favorites: data?.favorites || [],
          buyerMetrics: data?.buyerMetrics,
          sellerMetrics: data?.sellerMetrics,
        } as User);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const checkFavoriteStatus = async () => {
    if (!currentUser || currentUser.id === userId) {
      return;
    }

    try {
      const isFav = await isFavorite(currentUser.id, userId);
      setFavorite(isFav);
    } catch (error) {
      console.error('Error checking favorite status:', error);
    }
  };

  const handleToggleFavorite = async () => {
    if (!currentUser || !user) {
      return;
    }

    if (currentUser.id === userId) {
      Alert.alert('Info', 'You cannot add yourself to favorites');
      return;
    }

    setTogglingFavorite(true);
    try {
      if (favorite) {
        await removeFromFavorites(currentUser.id, userId);
        setFavorite(false);
      } else {
        await addToFavorites(currentUser.id, userId);
        setFavorite(true);
      }
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to update favorites');
    } finally {
      setTogglingFavorite(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
        </View>
      </View>
    );
  }

  if (!user) {
    return (
      <View style={styles.container}>
        <View style={styles.errorContainer}>
          <Icon name="account-alert" size={48} color={theme.colors.error} />
          <Text style={styles.errorText}>User not found</Text>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}>
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const isOwnProfile = currentUser?.id === userId;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backIcon}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        {!isOwnProfile && currentUser && (
          <TouchableOpacity
            style={styles.favoriteButton}
            onPress={handleToggleFavorite}
            disabled={togglingFavorite}>
            {togglingFavorite ? (
              <ActivityIndicator size="small" color={theme.colors.primary} />
            ) : (
              <Icon
                name={favorite ? 'heart' : 'heart-outline'}
                size={24}
                color={favorite ? theme.colors.error : theme.colors.textSecondary}
              />
            )}
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.content}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            {user.profileImage ? (
              <View style={styles.avatarImage} />
            ) : (
              <Icon name="account-circle" size={80} color={theme.colors.primary} />
            )}
          </View>
          <Text style={styles.name}>{user.displayName}</Text>
          {user.verified && (
            <View style={styles.verifiedBadge}>
              <Icon name="shield-check" size={16} color={theme.colors.primary} />
              <Text style={styles.verifiedText}>Verified</Text>
            </View>
          )}
          <Text style={styles.role}>{user.role === 'buyer' ? 'Buyer' : 'Seller'}</Text>
        </View>

        {/* Stats */}
        <View style={styles.statsContainer}>
          {user.rating && (
            <View style={styles.statItem}>
              <Icon name="star" size={20} color={theme.colors.warning} />
              <Text style={styles.statValue}>{user.rating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Rating</Text>
            </View>
          )}
          <View style={styles.statItem}>
            <Icon name="swap-horizontal" size={20} color={theme.colors.primary} />
            <Text style={styles.statValue}>{user.totalTransactions || 0}</Text>
            <Text style={styles.statLabel}>Transactions</Text>
          </View>
          {!isOwnProfile && (
            <View style={styles.statItem}>
              <Icon name="heart" size={20} color={theme.colors.error} />
              <Text style={styles.statValue}>{user.favorites?.length || 0}</Text>
              <Text style={styles.statLabel}>Favorites</Text>
            </View>
          )}
        </View>

        {/* Info */}
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Icon name="email" size={20} color={theme.colors.textSecondary} />
            <Text style={styles.infoText}>{user.email}</Text>
          </View>
          {user.location && (
            <View style={styles.infoRow}>
              <Icon name="map-marker" size={20} color={theme.colors.textSecondary} />
              <Text style={styles.infoText}>
                {user.location.city ? `${user.location.city}, ` : ''}
                {user.location.country}
              </Text>
            </View>
          )}
          <View style={styles.infoRow}>
            <Icon name="calendar" size={20} color={theme.colors.textSecondary} />
            <Text style={styles.infoText}>
              Member since {format(user.createdAt, 'MMM yyyy')}
            </Text>
          </View>
        </View>

        {/* Seller Metrics */}
        {user.role === 'seller' && user.sellerMetrics && (
          <View style={styles.infoCard}>
            <Text style={styles.sectionTitle}>Seller Stats</Text>
            {user.sellerMetrics.totalBids !== undefined && (
              <Text style={styles.infoText}>
                Total Bids: {user.sellerMetrics.totalBids}
              </Text>
            )}
            {user.sellerMetrics.averageResponseTime && (
              <Text style={styles.infoText}>
                Avg Response: {Math.round(user.sellerMetrics.averageResponseTime / 60)}h
              </Text>
            )}
            {user.sellerMetrics.completionRate !== undefined && (
              <Text style={styles.infoText}>
                Completion Rate: {Math.round(user.sellerMetrics.completionRate * 100)}%
              </Text>
            )}
          </View>
        )}

        {/* Buyer Metrics */}
        {user.role === 'buyer' && user.buyerMetrics && (
          <View style={styles.infoCard}>
            <Text style={styles.sectionTitle}>Buyer Stats</Text>
            {user.buyerMetrics.totalQuotes !== undefined && (
              <Text style={styles.infoText}>
                Total Quotes: {user.buyerMetrics.totalQuotes}
              </Text>
            )}
            {user.buyerMetrics.completedPurchases !== undefined && (
              <Text style={styles.infoText}>
                Completed: {user.buyerMetrics.completedPurchases}
              </Text>
            )}
            {user.buyerMetrics.seriousBuyer && (
              <View style={styles.seriousBadge}>
                <Icon name="check-circle" size={16} color={theme.colors.success} />
                <Text style={styles.seriousText}>Serious Buyer</Text>
              </View>
            )}
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  errorText: {
    fontSize: 16,
    color: theme.colors.error,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.lg,
    paddingTop: theme.spacing.xl,
  },
  backIcon: {
    padding: theme.spacing.xs,
  },
  favoriteButton: {
    padding: theme.spacing.xs,
  },
  content: {
    padding: theme.spacing.lg,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  avatarContainer: {
    marginBottom: theme.spacing.md,
  },
  avatarImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: theme.colors.surface,
  },
  name: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary + '20',
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.full,
    marginBottom: theme.spacing.xs,
  },
  verifiedText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.primary,
    marginLeft: theme.spacing.xs,
  },
  role: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textTransform: 'capitalize',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: theme.spacing.xl,
    paddingVertical: theme.spacing.md,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: theme.colors.border,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.xs,
  },
  statLabel: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  infoCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  infoText: {
    fontSize: 14,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    flex: 1,
  },
  seriousBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.sm,
    backgroundColor: theme.colors.success + '20',
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.md,
    alignSelf: 'flex-start',
  },
  seriousText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.success,
    marginLeft: theme.spacing.xs,
  },
  backButton: {
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
  },
  backButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
});

export default UserProfileScreen;

