import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {CopyrightNotice} from '../../components/CopyrightNotice';
import {theme} from '../../theme/theme';

const LegalScreen: React.FC = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="scale-balance" size={48} color={theme.colors.primary} />
        <Text style={styles.title}>Legal & Financial Disclaimers</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.warningSection}>
          <Icon name="alert-circle" size={32} color={theme.colors.error} />
          <Text style={styles.warningTitle}>CRITICAL FINANCIAL DISCLAIMER</Text>
          <Text style={styles.warningText}>
            UnderCut.Co <Text style={styles.bold}>DOES NOT and WILL NEVER hold or store</Text> customer
            money. All financial transactions are processed directly through third-party payment
            processors (Stripe, XRP/Ripple). Money movement is handled <Text style={styles.bold}>solely</Text> by
            these payment platforms and Ripple's payment system. We have no access to, control over,
            or responsibility for customer funds.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Platform Role</Text>
          <Text style={styles.text}>
            UnderCut.Co operates as a <Text style={styles.bold}>transaction facilitation tool provider</Text>.
            We provide the platform, tools, and infrastructure for buyers and sellers to connect and
            complete transactions. We are not a party to any transaction and do not act as an escrow
            agent, payment processor, or financial intermediary beyond providing the platform technology.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>No Refunds Policy</Text>
          <Text style={styles.text}>
            Due to internal Escrow cool-down periods that allow for making positive to continue the
            transaction, our policy is <Text style={styles.bold}>NO REFUNDS</Text>. All transactions are final
            once the escrow cool-down period has passed. By using this platform, you acknowledge and
            accept this policy.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Dispute Resolution</Text>
          <Text style={styles.text}>
            Any legal disagreements, disputes, or issues must be and will be resolved{' '}
            <Text style={styles.bold}>directly between buyers and sellers ONLY</Text>. UnderCut.Co does not
            mediate disputes, provide dispute resolution services, or assume any liability for
            transactions between users. Legal disputes are the sole responsibility of the transacting
            parties.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Blockchain Auditing</Text>
          <Text style={styles.text}>
            All transactions are recorded on the blockchain for secure auditing and control. This
            ensures precise, guaranteed, and unchangeable transaction records. Blockchain transaction
            data is provided for transparency and auditing purposes only.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Limitation of Liability</Text>
          <Text style={styles.text}>
            UnderCut.Co, its owners, employees, and affiliates shall not be liable for any direct,
            indirect, incidental, special, or consequential damages arising from the use of this
            platform or any transactions conducted through it. Users assume all risks associated with
            transactions.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Product Quality & Delivery</Text>
          <Text style={styles.text}>
            We do not guarantee product quality, authenticity, delivery, or seller performance. All
            product descriptions, warranties, and delivery promises are made by sellers. Buyers are
            responsible for verifying product details and seller credibility before completing transactions.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Global Jurisdiction</Text>
          <Text style={styles.text}>
            This platform operates globally. Users are responsible for compliance with all applicable
            local, state, national, and international laws and regulations. UnderCut.Co does not
            provide legal or financial advice.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Processor Terms</Text>
          <Text style={styles.text}>
            Users must comply with the terms and conditions of payment processors (Stripe, XRP/Ripple).
            Payment processing is subject to the policies and limitations of these third-party services.
            UnderCut.Co is not responsible for payment processor policies, fees, or issues.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Platform Availability</Text>
          <Text style={styles.text}>
            While we strive for 100% uptime, we do not guarantee uninterrupted access to the platform.
            The platform may be unavailable due to maintenance, technical issues, or circumstances
            beyond our control.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Modifications to Terms</Text>
          <Text style={styles.text}>
            We reserve the right to modify these disclaimers and terms at any time. Continued use of
            the platform after modifications constitutes acceptance of the updated terms.
          </Text>
        </View>

        <View style={styles.acknowledgmentBox}>
          <Icon name="file-check" size={24} color={theme.colors.primary} />
          <Text style={styles.acknowledgmentText}>
            By using UnderCut.Co, you acknowledge that you have read, understood, and agree to all
            legal and financial disclaimers stated above. You understand that UnderCut.Co does not
            hold or store customer money, does not mediate disputes, and operates solely as a
            transaction facilitation tool provider.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Intellectual Property & Code Protection</Text>
          <View style={styles.warningBox}>
            <Icon name="shield-alert" size={24} color={theme.colors.error} />
            <Text style={styles.warningText}>
              <Text style={styles.bold}>Copyright Protection:</Text> This platform is protected by 
              copyright law. Unauthorized copying, cloning, or distribution is strictly prohibited 
              and may result in severe civil and criminal penalties.
            </Text>
          </View>
          <Text style={styles.text}>
            This software includes code protection, watermarking, and monitoring systems. 
            Attempting to clone, reverse engineer, or copy this platform may result in legal action 
            including copyright infringement claims, trademark infringement claims, and criminal 
            prosecution under computer fraud laws.
          </Text>
        </View>

        <CopyrightNotice variant="compact" />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
    textAlign: 'center',
  },
  content: {
    padding: theme.spacing.lg,
  },
  warningSection: {
    backgroundColor: theme.colors.error + '20',
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.xl,
    borderWidth: 2,
    borderColor: theme.colors.error,
    alignItems: 'center',
  },
  warningBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.error + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.error + '40',
  },
  warningTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.error,
    marginTop: theme.spacing.sm,
    marginBottom: theme.spacing.md,
    textAlign: 'center',
  },
  warningText: {
    flex: 1,
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 22,
    marginLeft: theme.spacing.sm,
  },
  section: {
    marginBottom: theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.primary,
    marginBottom: theme.spacing.sm,
  },
  text: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 22,
  },
  bold: {
    fontWeight: '700',
    color: theme.colors.text,
  },
  acknowledgmentBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.primary + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.primary + '40',
    marginTop: theme.spacing.lg,
  },
  acknowledgmentText: {
    flex: 1,
    fontSize: 14,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    lineHeight: 20,
  },
});

export default LegalScreen;

