import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import DatePicker from 'react-native-date-picker';
import firestore from '@react-native-firebase/firestore';
import {useAuth} from '../../contexts/AuthContext';
import {useConfig} from '../../contexts/ConfigContext';
import {useAutoTrackUsage} from '../../hooks/usePlatformUsage';
import {useNavigation} from '@react-navigation/native';
import {Quote, CategoryLevel} from '../../types';
import {calculateCommitmentDeposit} from '../../services/buyerCommitment';
import {CATEGORIES, getAllCategories} from '../../config/categories';
import {theme} from '../../theme/theme';
import {addHours} from 'date-fns';

const PostQuoteScreen: React.FC = () => {
  const navigation = useNavigation();
  const {user} = useAuth();
  const {config} = useConfig();
  const {onQuotePosted} = useAutoTrackUsage();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [categoryLevel, setCategoryLevel] = useState<CategoryLevel>('mid-level');
  const [maxPrice, setMaxPrice] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [expiresAt, setExpiresAt] = useState<Date>(() => {
    // Default to config timeout hours from now
    const hours = config?.transactionTimeoutHours || 72;
    return addHours(new Date(), hours);
  });
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [loading, setLoading] = useState(false);
  const [requireCommitment, setRequireCommitment] = useState(true);
  const [quantity, setQuantity] = useState('1');
  const [urgencyLevel, setUrgencyLevel] = useState<'normal' | 'urgent' | 'asap'>('normal');

  const handlePostQuote = async () => {
    if (!title || !description || !category || !maxPrice) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const price = parseFloat(maxPrice);
    if (isNaN(price) || price <= 0) {
      Alert.alert('Error', 'Please enter a valid price');
      return;
    }

    if (!user) {
      Alert.alert('Error', 'You must be logged in to post a quote');
      return;
    }

    setLoading(true);
  };

  const proceedWithPosting = async (price: number, qty: number, commitmentDeposit: number) => {
    if (!user) {
      setLoading(false);
      return;
    }
    try {
      const quoteData: Omit<Quote, 'id'> = {
        buyerId: user.id,
        buyerName: user.displayName,
        title,
        description,
        category,
        categoryLevel,
        maxPrice: price,
        currency,
        expiresAt,
        createdAt: new Date(),
        status: 'quote_posted',
      };

      await firestore().collection('quotes').add({
        ...quoteData,
        createdAt: firestore.FieldValue.serverTimestamp(),
        expiresAt: firestore.Timestamp.fromDate(expiresAt),
      });

      // Track platform usage for chat eligibility
      await onQuotePosted();
      
      Alert.alert('Success', 'Your quote has been posted!', [
        {text: 'OK', onPress: () => navigation.goBack()},
      ]);
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to post quote');
    } finally {
      setLoading(false);
    }
  };

  const availableCategories = getAllCategories();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.form}>
        <Text style={styles.label}>Quote Title *</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g., Looking for a 2024 Ferrari 488"
          value={title}
          onChangeText={setTitle}
        />

        <Text style={styles.label}>Description *</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Describe what you're looking for in detail..."
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={6}
          textAlignVertical="top"
        />

        <Text style={styles.label}>Category Level *</Text>
        <View style={styles.levelSelector}>
          {(['luxury', 'mid-level', 'lower-level'] as CategoryLevel[]).map(level => (
            <TouchableOpacity
              key={level}
              style={[
                styles.levelButton,
                categoryLevel === level && styles.levelButtonActive,
              ]}
              onPress={() => setCategoryLevel(level)}>
              <Text
                style={[
                  styles.levelButtonText,
                  categoryLevel === level && styles.levelButtonTextActive,
                ]}>
                {level === 'luxury' ? 'Luxury' : level === 'mid-level' ? 'Mid-Level' : 'Lower-Level'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.label}>Category *</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.categoryContainer}>
            {availableCategories
              .filter(cat => cat.level === categoryLevel)
              .map(cat => (
                <TouchableOpacity
                  key={cat.id}
                  style={[
                    styles.categoryButton,
                    category === cat.id && styles.categoryButtonActive,
                  ]}
                  onPress={() => setCategory(cat.id)}>
                  <Text
                    style={[
                      styles.categoryButtonText,
                      category === cat.id && styles.categoryButtonTextActive,
                    ]}>
                    {cat.name}
                  </Text>
                </TouchableOpacity>
              ))}
          </View>
        </ScrollView>

        <View style={styles.row}>
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Max Price *</Text>
            <TextInput
              style={styles.input}
              placeholder="10000"
              value={maxPrice}
              onChangeText={setMaxPrice}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Currency</Text>
            <TextInput
              style={styles.input}
              placeholder="USD"
              value={currency}
              onChangeText={setCurrency}
            />
          </View>
        </View>

        <Text style={styles.label}>Expires At *</Text>
        <TouchableOpacity
          style={styles.dateButton}
          onPress={() => setShowDatePicker(true)}>
          <Icon name="calendar" size={20} color={theme.colors.textSecondary} />
          <Text style={styles.dateText}>
            {expiresAt.toLocaleString()}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.submitButton, loading && styles.submitButtonDisabled]}
          onPress={handlePostQuote}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator color={theme.colors.background} />
          ) : (
            <Text style={styles.submitButtonText}>Post Quote</Text>
          )}
        </TouchableOpacity>
      </View>

      <DatePicker
        modal
        open={showDatePicker}
        date={expiresAt}
        minimumDate={new Date()}
        onConfirm={(date) => {
          setExpiresAt(date);
          setShowDatePicker(false);
        }}
        onCancel={() => setShowDatePicker(false)}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  form: {
    padding: theme.spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
    marginTop: theme.spacing.md,
  },
  input: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    fontSize: 16,
    color: theme.colors.text,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  textArea: {
    height: 120,
    paddingTop: theme.spacing.md,
  },
  levelSelector: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
  },
  levelButton: {
    flex: 1,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surface,
    alignItems: 'center',
  },
  levelButtonActive: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  levelButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.textSecondary,
  },
  levelButtonTextActive: {
    color: theme.colors.background,
  },
  categoryContainer: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
  },
  categoryButton: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surface,
    marginRight: theme.spacing.sm,
  },
  categoryButtonActive: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  categoryButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.textSecondary,
  },
  categoryButtonTextActive: {
    color: theme.colors.background,
  },
  row: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },
  halfWidth: {
    flex: 1,
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  dateText: {
    fontSize: 16,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
  },
  submitButton: {
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
    marginTop: theme.spacing.xl,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
});

export default PostQuoteScreen;

