import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {CopyrightNotice} from '../../components/CopyrightNotice';
import {theme} from '../../theme/theme';

const TermsScreen: React.FC = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="file-document" size={48} color={theme.colors.primary} />
        <Text style={styles.title}>Terms of Service</Text>
        <Text style={styles.lastUpdated}>Last Updated: {new Date().toLocaleDateString()}</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>1. Platform Purpose</Text>
          <Text style={styles.text}>
            UnderCut.Co is a <Text style={styles.bold}>bartering platform</Text>, not a traditional
            shopping platform. This platform is designed for <Text style={styles.bold}>focused buyers</Text> who
            have already decided exactly what product they want to purchase and are seeking the
            lowest price through our vetted, timed offering system.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>2. No Refunds Policy</Text>
          <Text style={styles.text}>
            Due to internal Escrow cool-down periods that allow for making positive to continue the
            transaction, our policy is <Text style={styles.bold}>NO REFUNDS</Text>. All transactions are final
            once the escrow period has passed.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>3. Payment Processing</Text>
          <Text style={styles.text}>
            UnderCut.Co <Text style={styles.bold}>NEVER holds or stores customer money</Text>. All funds are
            processed directly through payment processors (Stripe, XRP/Ripple) and money movement is
            handled solely by these payment platforms. We act solely as a transaction facilitation tool provider.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>4. Escrow System</Text>
          <Text style={styles.text}>
            Our built-in E-Escrow system secures purchase agreements. Transaction timing is
            configurable and editable. The escrow cool-down period allows for transaction continuation
            and is a non-refundable period per our policy.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>5. Dispute Resolution</Text>
          <Text style={styles.text}>
            Any legal disagreements must be and will be resolved <Text style={styles.bold}>between buyers and
            sellers ONLY</Text>. As a company, we are ONLY in the middle providing tools for buyers and
            sellers to originate and complete purchases. We do not mediate disputes.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>6. Global Platform</Text>
          <Text style={styles.text}>
            This platform operates worldwide. All transactions are subject to local laws and
            regulations. Users are responsible for compliance with their local jurisdiction.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>7. Blockchain Integration</Text>
          <Text style={styles.text}>
            All transactions are sent through the blockchain for secure auditing and control. This
            ensures precise and guaranteed transaction records that are unchangeable.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>8. User Responsibilities</Text>
          <Text style={styles.text}>
            Users must provide accurate information and comply with all applicable laws. Buyers must
            have decided exactly what product they seek before posting quotes. Sellers must provide
            honest, competitive pricing.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>9. Platform Limitation</Text>
          <Text style={styles.text}>
            UnderCut.Co provides tools and platform services only. We facilitate transactions but do
            not guarantee product quality, delivery, or seller performance. All risks are assumed by
            the transacting parties.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>10. Acceptance of Terms</Text>
          <Text style={styles.text}>
            By using this platform, you acknowledge that you have read, understood, and agree to be
            bound by these Terms of Service.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>11. Intellectual Property Protection</Text>
          <Text style={styles.text}>
            This platform, including all software, code, designs, logos, and content, is protected by 
            copyright, trademark, and other intellectual property laws. Unauthorized copying, cloning, 
            modification, or distribution of this platform is strictly prohibited and may result in 
            severe civil and criminal penalties.
          </Text>
        </View>

        <View style={styles.warningBox}>
          <Icon name="alert-circle" size={24} color={theme.colors.warning} />
          <Text style={styles.warningText}>
            <Text style={styles.bold}>Important:</Text> This is NOT a shopping platform for browsing.
            It is for focused buyers who know exactly what they want and seek the lowest price.
          </Text>
        </View>

        <CopyrightNotice variant="compact" />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.xs,
  },
  lastUpdated: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  content: {
    padding: theme.spacing.lg,
  },
  section: {
    marginBottom: theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.primary,
    marginBottom: theme.spacing.sm,
  },
  text: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 22,
  },
  bold: {
    fontWeight: '700',
    color: theme.colors.text,
  },
  warningBox: {
    flexDirection: 'row',
    backgroundColor: theme.colors.warning + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.warning + '40',
    marginTop: theme.spacing.lg,
  },
  warningText: {
    flex: 1,
    fontSize: 14,
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    lineHeight: 20,
  },
});

export default TermsScreen;

