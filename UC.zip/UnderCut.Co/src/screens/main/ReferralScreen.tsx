import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import QRCode from 'react-native-qrcode-svg';
import {captureRef} from 'react-native-view-shot';
import Share from 'react-native-share';
import {useAuth} from '../../contexts/AuthContext';
import {useLanguage} from '../../contexts/LanguageContext';
import {
  getUserReferralCode,
  getReferralLink,
  getUserReferralStats,
  getUserReferrals,
} from '../../services/referral';
import {shareReferralLink, shareQRCode} from '../../services/qrCode';
import {ReferralData} from '../../types/admin';
import {theme} from '../../theme/theme';
import {format} from 'date-fns';

const ReferralScreen: React.FC = () => {
  const navigation = useNavigation();
  const {user} = useAuth();
  const {t} = useLanguage();
  const [referralCode, setReferralCode] = useState<string>('');
  const [referralLink, setReferralLink] = useState<string>('');
  const [stats, setStats] = useState<{
    referralCount: number;
    totalEarnings: number;
    activeReferrals: number;
    completedReferrals: number;
  } | null>(null);
  const [referrals, setReferrals] = useState<ReferralData[]>([]);
  const [loading, setLoading] = useState(true);
  const qrRef = useRef<any>(null);

  useEffect(() => {
    loadReferralData();
  }, [user]);

  const loadReferralData = async () => {
    if (!user) return;

    try {
      const code = await getUserReferralCode(user.id);
      const link = await getReferralLink(user.id);
      const statsData = await getUserReferralStats(user.id);
      const referralsData = await getUserReferrals(user.id);

      setReferralCode(code);
      setReferralLink(link);
      setStats(statsData);
      setReferrals(referralsData);
    } catch (error) {
      console.error('Error loading referral data:', error);
      Alert.alert('Error', 'Failed to load referral information');
    } finally {
      setLoading(false);
    }
  };

  const handleShareQR = async () => {
    try {
      await shareQRCode(qrRef, referralLink, user?.displayName || '');
    } catch (error) {
      Alert.alert('Error', 'Failed to share QR code');
    }
  };

  const handleShareLink = async () => {
    try {
      await shareReferralLink(referralLink, referralCode, user?.displayName || '');
    } catch (error) {
      Alert.alert('Error', 'Failed to share referral link');
    }
  };

  const handleCopyLink = () => {
    // Copy to clipboard
    Alert.alert('Copied', 'Referral link copied to clipboard');
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-left" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Referral Program</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.qrSection}>
          <Text style={styles.sectionTitle}>Share Your QR Code</Text>
          <Text style={styles.sectionDescription}>
            Share this QR code to invite others. They scan and join instantly!
          </Text>
          
          <View style={styles.qrContainer}>
            <View ref={qrRef} style={styles.qrWrapper}>
              <QRCode
                value={referralLink}
                size={200}
                color={theme.colors.primary}
                backgroundColor={theme.colors.background}
              />
            </View>
          </View>

          <TouchableOpacity style={styles.shareButton} onPress={handleShareQR}>
            <Icon name="share-variant" size={20} color={theme.colors.background} />
            <Text style={styles.shareButtonText}>Share QR Code</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.linkSection}>
          <Text style={styles.sectionTitle}>Your Referral Link</Text>
          <Text style={styles.sectionDescription}>
            Copy or share your referral link
          </Text>

          <View style={styles.linkContainer}>
            <Text style={styles.referralCode}>{referralCode}</Text>
            <Text style={styles.referralLink} numberOfLines={2}>
              {referralLink}
            </Text>
          </View>

          <View style={styles.linkButtons}>
            <TouchableOpacity
              style={[styles.linkButton, styles.copyButton]}
              onPress={handleCopyLink}>
              <Icon name="content-copy" size={20} color={theme.colors.primary} />
              <Text style={[styles.linkButtonText, {color: theme.colors.primary}]}>
                Copy Link
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.linkButton, styles.shareLinkButton]}
              onPress={handleShareLink}>
              <Icon name="share" size={20} color={theme.colors.background} />
              <Text style={[styles.linkButtonText, {color: theme.colors.background}]}>
                Share Link
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {stats && (
          <View style={styles.statsSection}>
            <Text style={styles.sectionTitle}>Your Referral Stats</Text>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Icon name="account-group" size={32} color={theme.colors.primary} />
                <Text style={styles.statValue}>{stats.referralCount}</Text>
                <Text style={styles.statLabel}>Total Referrals</Text>
              </View>
              <View style={styles.statCard}>
                <Icon name="check-circle" size={32} color={theme.colors.success} />
                <Text style={styles.statValue}>{stats.completedReferrals}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </View>
              <View style={styles.statCard}>
                <Icon name="clock-outline" size={32} color={theme.colors.warning} />
                <Text style={styles.statValue}>{stats.activeReferrals}</Text>
                <Text style={styles.statLabel}>Active</Text>
              </View>
              <View style={styles.statCard}>
                <Icon name="cash" size={32} color={theme.colors.success} />
                <Text style={styles.statValue}>${stats.totalEarnings.toFixed(2)}</Text>
                <Text style={styles.statLabel}>Total Earnings</Text>
              </View>
            </View>
          </View>
        )}

        <View style={styles.referralsList}>
          <Text style={styles.sectionTitle}>Your Referrals</Text>
          {referrals.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Icon name="account-question" size={64} color={theme.colors.textSecondary} />
              <Text style={styles.emptyText}>No referrals yet</Text>
              <Text style={styles.emptySubtext}>
                Share your QR code or link to start referring!
              </Text>
            </View>
          ) : (
            referrals.map(referral => (
              <View key={referral.id} style={styles.referralItem}>
                <View style={styles.referralHeader}>
                  <View style={styles.referralAvatar}>
                    <Icon name="account" size={24} color={theme.colors.primary} />
                  </View>
                  <View style={styles.referralInfo}>
                    <Text style={styles.referralName}>{referral.referredUserName}</Text>
                    <Text style={styles.referralDate}>
                      {format(referral.createdAt, 'MMM dd, yyyy')}
                    </Text>
                  </View>
                  <View
                    style={[
                      styles.statusBadge,
                      {
                        backgroundColor:
                          referral.status === 'completed'
                            ? theme.colors.success + '20'
                            : theme.colors.warning + '20',
                      },
                    ]}>
                    <Text
                      style={[
                        styles.statusText,
                        {
                          color:
                            referral.status === 'completed'
                              ? theme.colors.success
                              : theme.colors.warning,
                        },
                      ]}>
                      {referral.status.toUpperCase()}
                    </Text>
                  </View>
                </View>
              </View>
            ))
          )}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  backButton: {
    marginRight: theme.spacing.md,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.text,
  },
  content: {
    padding: theme.spacing.lg,
  },
  qrSection: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.lg,
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  sectionDescription: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: theme.spacing.lg,
  },
  qrContainer: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.md,
  },
  qrWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
  },
  shareButtonText: {
    color: theme.colors.background,
    fontSize: 16,
    fontWeight: '600',
    marginLeft: theme.spacing.sm,
  },
  linkSection: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.lg,
  },
  linkContainer: {
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },
  referralCode: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.primary,
    textAlign: 'center',
    marginBottom: theme.spacing.xs,
    letterSpacing: 2,
  },
  referralLink: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  linkButtons: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },
  linkButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.primary,
  },
  copyButton: {
    backgroundColor: theme.colors.background,
  },
  shareLinkButton: {
    backgroundColor: theme.colors.primary,
  },
  linkButtonText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: theme.spacing.xs,
  },
  statsSection: {
    marginBottom: theme.spacing.lg,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing.md,
  },
  statCard: {
    width: '48%',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.xs,
  },
  statLabel: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  referralsList: {
    marginBottom: theme.spacing.lg,
  },
  emptyContainer: {
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
  },
  emptySubtext: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    textAlign: 'center',
  },
  referralItem: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.sm,
  },
  referralHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  referralAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: theme.colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: theme.spacing.md,
  },
  referralInfo: {
    flex: 1,
  },
  referralName: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
  },
  referralDate: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  statusBadge: {
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '700',
  },
});

export default ReferralScreen;

