import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {theme} from '../../theme/theme';

const CopyrightScreen: React.FC = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Icon name="shield-check" size={48} color={theme.colors.primary} />
        <Text style={styles.title}>Copyright & Intellectual Property</Text>
        <Text style={styles.subtitle}>Protection & Legal Information</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Copyright Notice</Text>
          <Text style={styles.paragraph}>
            <Text style={styles.bold}>© 2024 UnderCut.Co. All Rights Reserved.</Text>
          </Text>
          <Text style={styles.paragraph}>
            This software and associated documentation files (the "Software") are proprietary and 
            confidential. Unauthorized copying, modification, distribution, or use of this Software, 
            via any medium is strictly prohibited, and may result in severe civil and criminal penalties.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Trademark Protection</Text>
          <Text style={styles.paragraph}>
            <Text style={styles.bold}>UnderCut.Co</Text>, <Text style={styles.bold}>ChatMe.Pro</Text>, 
            and all related logos, designs, and brand elements are trademarks or registered trademarks 
            of UnderCut.Co.
          </Text>
          <Text style={styles.paragraph}>
            Unauthorized use of these trademarks, including but not limited to:
          </Text>
          <View style={styles.list}>
            <Text style={styles.listItem}>• Using similar or identical brand names</Text>
            <Text style={styles.listItem}>• Copying or imitating logos and designs</Text>
            <Text style={styles.listItem}>• Creating derivative works based on our branding</Text>
            <Text style={styles.listItem}>• Using our trademarks in domain names or social media</Text>
          </View>
          <Text style={styles.paragraph}>
            is prohibited and may constitute trademark infringement under applicable law.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Code Protection</Text>
          <Text style={styles.paragraph}>
            This platform includes multiple layers of code protection:
          </Text>
          <View style={styles.list}>
            <Text style={styles.listItem}>
              • <Text style={styles.bold}>Obfuscation & Minification</Text>: Source code is protected through obfuscation
            </Text>
            <Text style={styles.listItem}>
              • <Text style={styles.bold}>License Validation</Text>: Built-in license and authenticity checks
            </Text>
            <Text style={styles.listItem}>
              • <Text style={styles.bold}>Watermarking</Text>: Code includes digital fingerprints and watermarks
            </Text>
            <Text style={styles.listItem}>
              • <Text style={styles.bold}>Monitoring Systems</Text>: Detection and monitoring of unauthorized use
            </Text>
            <Text style={styles.listItem}>
              • <Text style={styles.bold}>Legal Enforcement</Text>: Active enforcement of intellectual property rights
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Anti-Cloning Measures</Text>
          <Text style={styles.paragraph}>
            This platform incorporates various technical and legal measures to prevent unauthorized 
            copying, cloning, or replication:
          </Text>
          <View style={styles.warningBox}>
            <Icon name="shield-alert" size={24} color={theme.colors.error} />
            <Text style={styles.warningText}>
              <Text style={styles.bold}>Warning:</Text> Attempting to clone, reverse engineer, or 
              copy this platform may result in:
            </Text>
            <View style={styles.list}>
              <Text style={styles.listItem}>• Civil lawsuits for copyright infringement</Text>
              <Text style={styles.listItem}>• Criminal penalties under computer fraud laws</Text>
              <Text style={styles.listItem}>• Trademark infringement claims</Text>
              <Text style={styles.listItem}>• Trade secret misappropriation claims</Text>
              <Text style={styles.listItem}>• Permanent injunctions and damages</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Prohibited Activities</Text>
          <Text style={styles.paragraph}>
            The following activities are strictly prohibited:
          </Text>
          <View style={styles.list}>
            <Text style={styles.listItem}>Copying, cloning, or replicating the platform</Text>
            <Text style={styles.listItem}>Reverse engineering or decompiling the software</Text>
            <Text style={styles.listItem}>Creating derivative works based on our code</Text>
            <Text style={styles.listItem}>Distributing or selling copied versions</Text>
            <Text style={styles.listItem}>Using our code in competing platforms</Text>
            <Text style={styles.listItem}>Removing copyright or license notices</Text>
            <Text style={styles.listItem}>Circumventing protection mechanisms</Text>
            <Text style={styles.listItem}>Creating similar platforms using our concepts</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal Remedies</Text>
          <Text style={styles.paragraph}>
            UnderCut.Co reserves the right to pursue all available legal remedies, including:
          </Text>
          <View style={styles.list}>
            <Text style={styles.listItem}>• Injunctive relief to stop unauthorized use</Text>
            <Text style={styles.listItem}>• Monetary damages for infringement</Text>
            <Text style={styles.listItem}>• Recovery of attorney's fees and costs</Text>
            <Text style={styles.listItem}>• Criminal prosecution where applicable</Text>
            <Text style={styles.listItem}>• Seizure of infringing materials</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Reporting Violations</Text>
          <Text style={styles.paragraph}>
            If you become aware of any unauthorized copying, cloning, or use of our platform, 
            please report it immediately to:
          </Text>
          <View style={styles.contactBox}>
            <Text style={styles.contactText}>
              <Text style={styles.bold}>Legal Department</Text>{'\n'}
              UnderCut.Co{'\n'}
              legal@undercut.co
            </Text>
          </View>
        </View>

        <View style={styles.footer}>
          <Icon name="copyright" size={16} color={theme.colors.textSecondary} />
          <Text style={styles.footerText}>
            © 2024 UnderCut.Co. All Rights Reserved.{'\n'}
            This notice is protected by copyright law.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    alignItems: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.xs,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  content: {
    padding: theme.spacing.lg,
  },
  section: {
    marginBottom: theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.primary,
    marginBottom: theme.spacing.md,
  },
  paragraph: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 22,
    marginBottom: theme.spacing.sm,
  },
  bold: {
    fontWeight: '700',
    color: theme.colors.text,
  },
  list: {
    marginLeft: theme.spacing.md,
    marginTop: theme.spacing.sm,
    marginBottom: theme.spacing.md,
  },
  listItem: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 24,
    marginBottom: theme.spacing.xs,
  },
  warningBox: {
    backgroundColor: theme.colors.error + '20',
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginTop: theme.spacing.md,
    marginBottom: theme.spacing.md,
    borderWidth: 2,
    borderColor: theme.colors.error + '40',
  },
  warningText: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 20,
    marginLeft: theme.spacing.sm,
  },
  contactBox: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginTop: theme.spacing.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  contactText: {
    fontSize: 14,
    color: theme.colors.text,
    lineHeight: 22,
    textAlign: 'center',
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.xl,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    marginTop: theme.spacing.xl,
  },
  footerText: {
    fontSize: 12,
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.sm,
    textAlign: 'center',
  },
});

export default CopyrightScreen;

