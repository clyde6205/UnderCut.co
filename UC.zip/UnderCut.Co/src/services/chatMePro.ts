import {firestore} from './firebase';
import {ChatRoom, ChatMessage, ChatSubscription, PlatformUsage} from '../types/chat';
import {User} from '../types';

const CHAT_SUBSCRIPTION_PRICE_MONTHLY = 9.99; // USD
const PLATFORM_USAGE_MONTHS_REQUIRED = 6; // Months of no platform usage before chat removal
// ChatMe.Pro is built-in using Firebase Firestore for real-time messaging
// No external API calls - zero cold startup

// Initialize ChatMe.Pro subscription
export const subscribeToChat = async (userId: string, subscriptionType: 'monthly' | 'yearly'): Promise<ChatSubscription> => {
  try {
    const now = new Date();
    const expiresAt = new Date(now);
    
    if (subscriptionType === 'monthly') {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    } else {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    }

    const subscription: Omit<ChatSubscription, 'userId'> = {
      subscribed: true,
      subscribedAt: now,
      expiresAt,
      subscriptionType,
      lastPaymentDate: now,
      nextPaymentDate: expiresAt,
      autoRenew: true,
    };

    await firestore().collection('chatSubscriptions').doc(userId).set({
      ...subscription,
      subscribedAt: firestore.FieldValue.serverTimestamp(),
      expiresAt: firestore.Timestamp.fromDate(expiresAt),
      lastPaymentDate: firestore.Timestamp.fromDate(now),
      nextPaymentDate: firestore.Timestamp.fromDate(expiresAt),
    });

    // Update user profile
    await firestore().collection('users').doc(userId).update({
      'chatSubscription.subscribed': true,
      'chatSubscription.subscribedAt': firestore.Timestamp.fromDate(now),
      'chatSubscription.expiresAt': firestore.Timestamp.fromDate(expiresAt),
    });

    return {userId, ...subscription};
  } catch (error) {
    console.error('Error subscribing to chat:', error);
    throw error;
  }
};

// Check if user has active chat subscription
export const hasActiveChatSubscription = async (userId: string): Promise<boolean> => {
  try {
    const userDoc = await firestore().collection('users').doc(userId).get();
    const userData = userDoc.data();
    
    if (!userData?.chatSubscription?.subscribed) {
      return false;
    }

    // Check if subscription expired
    if (userData.chatSubscription.expiresAt) {
      const expiresAt = userData.chatSubscription.expiresAt.toDate();
      if (expiresAt < new Date()) {
        return false;
      }
    }

    // Check platform usage requirement
    const isEligible = await checkPlatformUsageEligibility(userId);
    return isEligible;
  } catch (error) {
    console.error('Error checking chat subscription:', error);
    return false;
  }
};

// Check platform usage eligibility
export const checkPlatformUsageEligibility = async (userId: string): Promise<boolean> => {
  try {
    const usageDoc = await firestore().collection('platformUsage').doc(userId).get();
    
    if (!usageDoc.exists) {
      // New user - give grace period
      return true;
    }

    const usage = usageDoc.data() as PlatformUsage;
    const now = new Date();
    const monthsAgo = new Date(now);
    monthsAgo.setMonth(monthsAgo.getMonth() - PLATFORM_USAGE_MONTHS_REQUIRED);

    // Check last platform activity
    const lastActivity = usage.lastPlatformActivity?.toDate() || usage.lastQuotePost?.toDate() || 
                        usage.lastBidSubmission?.toDate() || usage.lastTransactionCompletion?.toDate();

    if (!lastActivity) {
      // No activity at all - check creation date
      const userDoc = await firestore().collection('users').doc(userId).get();
      const userData = userDoc.data();
      const createdAt = userData?.createdAt?.toDate() || new Date();
      
      // Give 6 months grace period for new users
      const gracePeriodEnd = new Date(createdAt);
      gracePeriodEnd.setMonth(gracePeriodEnd.getMonth() + PLATFORM_USAGE_MONTHS_REQUIRED);
      
      if (now > gracePeriodEnd) {
        // Send warning if not sent
        if (!usage.warningSentAt) {
          await sendUsageWarning(userId);
        }
        return false;
      }
      return true;
    }

    // Check if last activity is within required period
    if (lastActivity < monthsAgo) {
      // User hasn't used platform - send warning
      if (!usage.warningSentAt) {
        await sendUsageWarning(userId);
      }
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error checking platform usage:', error);
    return true; // Default to eligible on error
  }
};

// Send usage warning
const sendUsageWarning = async (userId: string): Promise<void> => {
  try {
    await firestore().collection('platformUsage').doc(userId).update({
      warningSentAt: firestore.FieldValue.serverTimestamp(),
      chatUsageEligible: false,
    });
  } catch (error) {
    console.error('Error sending usage warning:', error);
  }
};

// Update platform usage tracking
export const updatePlatformUsage = async (
  userId: string,
  activityType: 'quote' | 'bid' | 'transaction'
): Promise<void> => {
  try {
    const now = new Date();
    const updateData: Partial<PlatformUsage> = {
      lastPlatformActivity: now,
      chatUsageEligible: true,
    };

    switch (activityType) {
      case 'quote':
        updateData.lastQuotePost = now;
        updateData.totalQuotesPosted = firestore.FieldValue.increment(1);
        break;
      case 'bid':
        updateData.lastBidSubmission = now;
        updateData.totalBidsSubmitted = firestore.FieldValue.increment(1);
        break;
      case 'transaction':
        updateData.lastTransactionCompletion = now;
        updateData.totalTransactionsCompleted = firestore.FieldValue.increment(1);
        break;
    }

    await firestore().collection('platformUsage').doc(userId).set(updateData, {merge: true});
  } catch (error) {
    console.error('Error updating platform usage:', error);
  }
};

// Create chat room
export const createChatRoom = async (
  participantIds: string[],
  participantNames: Record<string, string>,
  type: 'quote' | 'transaction' | 'general' = 'general',
  relatedQuoteId?: string,
  relatedTransactionId?: string
): Promise<string> => {
  try {
    // Check both participants have active subscriptions
    for (const participantId of participantIds) {
      const hasSubscription = await hasActiveChatSubscription(participantId);
      if (!hasSubscription) {
        throw new Error('One or more participants do not have an active chat subscription');
      }
    }

    const chatRoom: Omit<ChatRoom, 'id'> = {
      participantIds,
      participantNames,
      createdAt: new Date(),
      type,
      relatedQuoteId,
      relatedTransactionId,
      unreadCount: {},
    };

    const docRef = await firestore().collection('chatRooms').add({
      ...chatRoom,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    return docRef.id;
  } catch (error) {
    console.error('Error creating chat room:', error);
    throw error;
  }
};

// Send message
export const sendMessage = async (
  chatRoomId: string,
  senderId: string,
  senderName: string,
  text: string
): Promise<string> => {
  try {
    // Verify sender has active subscription
    const hasSubscription = await hasActiveChatSubscription(senderId);
    if (!hasSubscription) {
      throw new Error('You do not have an active chat subscription');
    }

    const message: Omit<ChatMessage, 'id'> = {
      chatRoomId,
      senderId,
      senderName,
      text,
      createdAt: new Date(),
      read: false,
    };

    const docRef = await firestore().collection('chatMessages').add({
      ...message,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    // Update chat room last message
    await firestore().collection('chatRooms').doc(chatRoomId).update({
      lastMessage: {
        text,
        senderName,
        createdAt: firestore.FieldValue.serverTimestamp(),
      },
      lastMessageAt: firestore.FieldValue.serverTimestamp(),
    });

    // Send push notification to other participants
    const chatRoomDoc = await firestore().collection('chatRooms').doc(chatRoomId).get();
    const chatRoomData = chatRoomDoc.data();
    if (chatRoomData?.participantIds) {
      const otherParticipants = chatRoomData.participantIds.filter((id: string) => id !== senderId);
      for (const participantId of otherParticipants) {
        try {
          const {sendChatNotification} = await import('./pushNotifications');
          await sendChatNotification(participantId, senderName, text, chatRoomId);
        } catch (error) {
          console.error('Error sending notification:', error);
        }
      }
    }

    return docRef.id;
  } catch (error) {
    console.error('Error sending message:', error);
    throw error;
  }
};

// Subscribe to user's chat rooms in real-time (no cold start)
export const subscribeToUserChatRooms = (
  userId: string,
  onRooms: (rooms: ChatRoom[]) => void
): (() => void) => {
  // Real-time listener - loads from cache instantly
  const unsubscribe = firestore()
    .collection('chatRooms')
    .where('participantIds', 'array-contains', userId)
    .orderBy('lastMessageAt', 'desc')
    .onSnapshot(
      (snapshot) => {
        const rooms = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate() || new Date(),
          lastMessageAt: doc.data().lastMessageAt?.toDate(),
        })) as ChatRoom[];
        onRooms(rooms);
      },
      (error) => {
        console.error('Error subscribing to chat rooms:', error);
      }
    );

  return unsubscribe;
};

// Get user's chat rooms (for one-time load - use subscribeToUserChatRooms for real-time)
export const getUserChatRooms = async (userId: string): Promise<ChatRoom[]> => {
  try {
    const snapshot = await firestore()
      .collection('chatRooms')
      .where('participantIds', 'array-contains', userId)
      .orderBy('lastMessageAt', 'desc')
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      lastMessageAt: doc.data().lastMessageAt?.toDate(),
    })) as ChatRoom[];
  } catch (error) {
    console.error('Error getting chat rooms:', error);
    throw error;
  }
};

// Unsubscribe from user chat rooms
export const unsubscribeFromUserChatRooms = (unsubscribe: () => void): void => {
  unsubscribe();
};

// Subscribe to real-time chat messages (no cold start - uses Firestore cache)
export const subscribeToChatRoomMessages = (
  chatRoomId: string,
  onMessages: (messages: ChatMessage[]) => void,
  limit: number = 50
): (() => void) => {
  // Real-time listener - loads from cache instantly, then syncs in real-time
  const unsubscribe = firestore()
    .collection('chatMessages')
    .where('chatRoomId', '==', chatRoomId)
    .orderBy('createdAt', 'desc')
    .limit(limit)
    .onSnapshot(
      (snapshot) => {
        const messages = snapshot.docs
          .map(doc => ({
            id: doc.id,
            ...doc.data(),
            createdAt: doc.data().createdAt?.toDate() || new Date(),
            readAt: doc.data().readAt?.toDate(),
          }))
          .reverse() as ChatMessage[];
        onMessages(messages);
      },
      (error) => {
        console.error('Error subscribing to chat messages:', error);
      }
    );

  return unsubscribe;
};

// Get chat room messages (for initial load - but use subscribeToChatRoomMessages for real-time)
export const getChatRoomMessages = async (
  chatRoomId: string,
  limit: number = 50
): Promise<ChatMessage[]> => {
  try {
    const snapshot = await firestore()
      .collection('chatMessages')
      .where('chatRoomId', '==', chatRoomId)
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();

    return snapshot.docs
      .map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        readAt: doc.data().readAt?.toDate(),
      }))
      .reverse() as ChatMessage[];
  } catch (error) {
    console.error('Error getting chat messages:', error);
    throw error;
  }
};

// Unsubscribe from chat room messages
export const unsubscribeFromChatRoomMessages = (unsubscribe: () => void): void => {
  unsubscribe();
};

// Mark messages as read
export const markMessagesAsRead = async (chatRoomId: string, userId: string): Promise<void> => {
  try {
    const snapshot = await firestore()
      .collection('chatMessages')
      .where('chatRoomId', '==', chatRoomId)
      .where('senderId', '!=', userId)
      .where('read', '==', false)
      .get();

    const batch = firestore().batch();
    snapshot.docs.forEach(doc => {
      batch.update(doc.ref, {
        read: true,
        readAt: firestore.FieldValue.serverTimestamp(),
      });
    });

    await batch.commit();
  } catch (error) {
    console.error('Error marking messages as read:', error);
  }
};

// Get or create chat room between two users (for quote/transaction)
export const getOrCreateChatRoom = async (
  user1Id: string,
  user2Id: string,
  user1Name: string,
  user2Name: string,
  type: 'quote' | 'transaction' | 'general' = 'general',
  relatedQuoteId?: string,
  relatedTransactionId?: string
): Promise<string> => {
  try {
    // Check if room already exists
    const existingRooms = await firestore()
      .collection('chatRooms')
      .where('participantIds', '==', [user1Id, user2Id])
      .where('type', '==', type)
      .get();

    if (!existingRooms.empty) {
      return existingRooms.docs[0].id;
    }

    // Create new room
    return await createChatRoom(
      [user1Id, user2Id],
      {[user1Id]: user1Name, [user2Id]: user2Name},
      type,
      relatedQuoteId,
      relatedTransactionId
    );
  } catch (error) {
    console.error('Error getting or creating chat room:', error);
    throw error;
  }
};

// Cancel chat subscription
export const cancelChatSubscription = async (userId: string): Promise<void> => {
  try {
    await firestore().collection('chatSubscriptions').doc(userId).update({
      subscribed: false,
      autoRenew: false,
    });

    await firestore().collection('users').doc(userId).update({
      'chatSubscription.subscribed': false,
      'chatSubscription.autoRenew': false,
    });
  } catch (error) {
    console.error('Error canceling chat subscription:', error);
    throw error;
  }
};

