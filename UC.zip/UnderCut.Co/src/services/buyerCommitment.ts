/**
 * Buyer Commitment Service
 * 
 * Ensures buyers are serious and committed to purchase
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {Quote, User} from '../types';

export interface CommitmentDeposit {
  quoteId: string;
  buyerId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'confirmed' | 'refunded' | 'applied';
  createdAt: Date;
  confirmedAt?: Date;
}

/**
 * Calculate commitment deposit amount (typically 5-10% of max price)
 */
export const calculateCommitmentDeposit = (maxPrice: number, percentage: number = 0.05): number => {
  return Math.max(10, Math.round(maxPrice * percentage)); // Minimum $10
};

/**
 * Create commitment deposit for quote
 */
export const createCommitmentDeposit = async (
  quoteId: string,
  buyerId: string,
  amount: number,
  currency: string
): Promise<string> => {
  try {
    const deposit: Omit<CommitmentDeposit, 'id'> = {
      quoteId,
      buyerId,
      amount,
      currency,
      status: 'pending',
      createdAt: new Date(),
    };

    const depositRef = await firestore().collection('commitmentDeposits').add({
      ...deposit,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    // Update quote with commitment info
    await firestore().collection('quotes').doc(quoteId).update({
      buyerCommitted: true,
      buyerCommitmentDeposit: amount,
    });

    // Update user buyer metrics
    await firestore()
      .collection('users')
      .doc(buyerId)
      .update({
        'buyerMetrics.totalQuotes': firestore.FieldValue.increment(1),
        'buyerMetrics.seriousBuyer': true,
      });

    return depositRef.id;
  } catch (error) {
    console.error('Error creating commitment deposit:', error);
    throw error;
  }
};

/**
 * Confirm commitment deposit payment
 */
export const confirmCommitmentDeposit = async (
  depositId: string,
  paymentTransactionId: string
): Promise<void> => {
  try {
    await firestore().collection('commitmentDeposits').doc(depositId).update({
      status: 'confirmed',
      confirmedAt: firestore.FieldValue.serverTimestamp(),
      paymentTransactionId,
    });
  } catch (error) {
    console.error('Error confirming commitment deposit:', error);
    throw error;
  }
};

/**
 * Apply commitment deposit to transaction
 */
export const applyCommitmentDeposit = async (
  depositId: string,
  transactionId: string
): Promise<void> => {
  try {
    await firestore().collection('commitmentDeposits').doc(depositId).update({
      status: 'applied',
      appliedToTransaction: transactionId,
    });
  } catch (error) {
    console.error('Error applying commitment deposit:', error);
    throw error;
  }
};

/**
 * Check if buyer is committed to quote
 */
export const isBuyerCommitted = async (quoteId: string, buyerId: string): Promise<boolean> => {
  try {
    const snapshot = await firestore()
      .collection('commitmentDeposits')
      .where('quoteId', '==', quoteId)
      .where('buyerId', '==', buyerId)
      .where('status', '==', 'confirmed')
      .get();

    return !snapshot.empty;
  } catch (error) {
    console.error('Error checking buyer commitment:', error);
    return false;
  }
};

/**
 * Get buyer's commitment status for quote
 */
export const getBuyerCommitment = async (
  quoteId: string,
  buyerId: string
): Promise<CommitmentDeposit | null> => {
  try {
    const snapshot = await firestore()
      .collection('commitmentDeposits')
      .where('quoteId', '==', quoteId)
      .where('buyerId', '==', buyerId)
      .limit(1)
      .get();

    if (snapshot.empty) {
      return null;
    }

    const doc = snapshot.docs[0];
    return {
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      confirmedAt: doc.data().confirmedAt?.toDate(),
    } as CommitmentDeposit;
  } catch (error) {
    console.error('Error getting buyer commitment:', error);
    return null;
  }
};

