/**
 * Review & Rating Service
 * 
 * Post-transaction reviews and ratings for trust building
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {Review, Transaction, User} from '../types';

/**
 * Create review for transaction
 */
export const createReview = async (
  transactionId: string,
  reviewerId: string,
  revieweeId: string,
  rating: number,
  comment?: string
): Promise<string> => {
  try {
    if (rating < 1 || rating > 5) {
      throw new Error('Rating must be between 1 and 5');
    }

    const review: Omit<Review, 'id'> = {
      transactionId,
      reviewerId,
      revieweeId,
      rating,
      comment,
      createdAt: new Date(),
      helpful: 0,
    };

    const reviewRef = await firestore().collection('reviews').add({
      ...review,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    // Update transaction with review
    const transactionRef = firestore().collection('transactions').doc(transactionId);
    const transactionDoc = await transactionRef.get();

    if (transactionDoc.exists) {
      const transaction = transactionDoc.data() as Transaction;
      const isBuyerReview = reviewerId === transaction.buyerId;

      await transactionRef.update({
        [`review.${isBuyerReview ? 'buyerReview' : 'sellerReview'}`]: {
          id: reviewRef.id,
          rating,
          comment,
        },
      });
    }

    // Update user rating
    await updateUserRating(revieweeId);

    return reviewRef.id;
  } catch (error) {
    console.error('Error creating review:', error);
    throw error;
  }
};

/**
 * Update user rating based on all reviews
 */
export const updateUserRating = async (userId: string): Promise<void> => {
  try {
    const reviewsSnapshot = await firestore()
      .collection('reviews')
      .where('revieweeId', '==', userId)
      .get();

    if (reviewsSnapshot.empty) {
      return;
    }

    let totalRating = 0;
    reviewsSnapshot.forEach(doc => {
      const review = doc.data() as Review;
      totalRating += review.rating;
    });

    const averageRating = totalRating / reviewsSnapshot.size;

    await firestore().collection('users').doc(userId).update({
      rating: Math.round(averageRating * 10) / 10, // Round to 1 decimal
    });
  } catch (error) {
    console.error('Error updating user rating:', error);
  }
};

/**
 * Get reviews for user
 */
export const getUserReviews = async (userId: string): Promise<Review[]> => {
  try {
    const snapshot = await firestore()
      .collection('reviews')
      .where('revieweeId', '==', userId)
      .orderBy('createdAt', 'desc')
      .limit(50)
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    })) as Review[];
  } catch (error) {
    console.error('Error getting user reviews:', error);
    return [];
  }
};

/**
 * Get review for transaction
 */
export const getTransactionReview = async (transactionId: string): Promise<{
  buyerReview?: Review;
  sellerReview?: Review;
} | null> => {
  try {
    const doc = await firestore().collection('transactions').doc(transactionId).get();
    
    if (!doc.exists) {
      return null;
    }

    const transaction = doc.data() as Transaction;
    return transaction.review || null;
  } catch (error) {
    console.error('Error getting transaction review:', error);
    return null;
  }
};

