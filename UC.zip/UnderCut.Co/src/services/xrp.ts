import {Client, Wallet, Payment, xrpToDrops} from 'xrpl';
import {getConfig} from '../config/appConfig';

let client: Client | null = null;

export interface XRPPaymentParams {
  destination: string;
  amount: number; // XRP amount
  destinationTag?: number;
  sourceTag?: number;
  memo?: string;
}

export interface XRPPaymentResult {
  success: boolean;
  txHash?: string;
  error?: string;
}

export const initializeXRP = async (): Promise<void> => {
  try {
    const config = getConfig();
    
    if (config.paymentProcessor !== 'xrp' && !config.xrpApiEndpoint) {
      console.warn('XRP not configured');
      return;
    }

    const network = config.rippleNetwork || 'testnet';
    const serverUrl = network === 'mainnet' 
      ? 'wss://xrplcluster.com' 
      : 'wss://s.altnet.rippletest.net:51233';

    client = new Client(serverUrl);
    await client.connect();

    console.log(`XRP client connected to ${network}`);
  } catch (error) {
    console.error('XRP initialization error:', error);
    throw error;
  }
};

export const disconnectXRP = async (): Promise<void> => {
  if (client && client.isConnected()) {
    await client.disconnect();
    client = null;
  }
};

export const generateXRPVault = async (): Promise<{address: string; secret: string}> => {
  try {
    if (!client || !client.isConnected()) {
      await initializeXRP();
    }

    const wallet = Wallet.generate();
    
    return {
      address: wallet.classicAddress,
      secret: wallet.seed,
    };
  } catch (error) {
    console.error('Error generating XRP wallet:', error);
    throw error;
  }
};

export const sendXRPPayment = async (
  secret: string,
  params: XRPPaymentParams
): Promise<XRPPaymentResult> => {
  try {
    if (!client || !client.isConnected()) {
      await initializeXRP();
    }

    if (!client) {
      return {success: false, error: 'XRP client not initialized'};
    }

    const wallet = Wallet.fromSeed(secret);
    
    // Prepare payment transaction
    const payment: Payment = {
      TransactionType: 'Payment',
      Account: wallet.classicAddress,
      Destination: params.destination,
      Amount: xrpToDrops(params.amount.toString()),
      DestinationTag: params.destinationTag,
      SourceTag: params.sourceTag,
      Memos: params.memo ? [
        {
          Memo: {
            MemoData: Buffer.from(params.memo).toString('hex').toUpperCase(),
            MemoType: Buffer.from('text/plain').toString('hex').toUpperCase(),
          },
        },
      ] : undefined,
    };

    // Submit transaction
    const prepared = await client.autofill(payment);
    const signed = wallet.sign(prepared);
    const result = await client.submitAndWait(signed.tx_blob);

    if (result.result.meta?.TransactionResult === 'tesSUCCESS') {
      return {
        success: true,
        txHash: result.result.hash,
      };
    } else {
      return {
        success: false,
        error: result.result.meta?.TransactionResult || 'Unknown error',
      };
    }
  } catch (error: any) {
    console.error('Error sending XRP payment:', error);
    return {
      success: false,
      error: error.message || 'Failed to send XRP payment',
    };
  }
};

export const getXRPBalance = async (address: string): Promise<number> => {
  try {
    if (!client || !client.isConnected()) {
      await initializeXRP();
    }

    if (!client) {
      throw new Error('XRP client not initialized');
    }

    const response = await client.request({
      command: 'account_info',
      account: address,
      ledger_index: 'validated',
    });

    const balance = parseFloat(response.result.account_data.Balance) / 1_000_000; // Convert drops to XRP
    return balance;
  } catch (error) {
    console.error('Error getting XRP balance:', error);
    throw error;
  }
};

export const isXRPInitialized = (): boolean => {
  return client !== null && client.isConnected();
};

