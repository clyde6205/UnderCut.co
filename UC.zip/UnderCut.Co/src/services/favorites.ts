/**
 * Favorites Service
 * 
 * Simple favorites system for adding and managing favorite users
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {User} from '../types';

/**
 * Add user to favorites
 */
export const addToFavorites = async (currentUserId: string, favoriteUserId: string): Promise<void> => {
  try {
    const userRef = firestore().collection('users').doc(currentUserId);
    const userDoc = await userRef.get();

    if (!userDoc.exists) {
      throw new Error('User not found');
    }

    const currentFavorites = userDoc.data()?.favorites || [];
    
    if (currentFavorites.includes(favoriteUserId)) {
      // Already in favorites
      return;
    }

    await userRef.update({
      favorites: firestore.FieldValue.arrayUnion(favoriteUserId),
    });
  } catch (error) {
    console.error('Error adding to favorites:', error);
    throw error;
  }
};

/**
 * Remove user from favorites
 */
export const removeFromFavorites = async (currentUserId: string, favoriteUserId: string): Promise<void> => {
  try {
    const userRef = firestore().collection('users').doc(currentUserId);
    
    await userRef.update({
      favorites: firestore.FieldValue.arrayRemove(favoriteUserId),
    });
  } catch (error) {
    console.error('Error removing from favorites:', error);
    throw error;
  }
};

/**
 * Check if user is in favorites
 */
export const isFavorite = async (currentUserId: string, favoriteUserId: string): Promise<boolean> => {
  try {
    const userDoc = await firestore().collection('users').doc(currentUserId).get();
    if (!userDoc.exists) {
      return false;
    }

    const favorites = userDoc.data()?.favorites || [];
    return favorites.includes(favoriteUserId);
  } catch (error) {
    console.error('Error checking favorite status:', error);
    return false;
  }
};

/**
 * Get all favorite users
 */
export const getFavoriteUsers = async (currentUserId: string): Promise<User[]> => {
  try {
    const userDoc = await firestore().collection('users').doc(currentUserId).get();
    if (!userDoc.exists) {
      return [];
    }

    const favoriteIds = userDoc.data()?.favorites || [];
    if (favoriteIds.length === 0) {
      return [];
    }

    // Get user data for each favorite (batch read)
    const userPromises = favoriteIds.map(id =>
      firestore().collection('users').doc(id).get()
    );
    
    const userDocs = await Promise.all(userPromises);
    
    return userDocs
      .filter(doc => doc.exists)
      .map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          email: data?.email || '',
          displayName: data?.displayName || '',
          role: data?.role || 'buyer',
          verified: data?.verified || false,
          createdAt: data?.createdAt?.toDate() || new Date(),
          profileImage: data?.profileImage,
          location: data?.location,
          rating: data?.rating,
          totalTransactions: data?.totalTransactions || 0,
          favorites: data?.favorites || [],
        } as User;
      });
  } catch (error) {
    console.error('Error getting favorite users:', error);
    return [];
  }
};

