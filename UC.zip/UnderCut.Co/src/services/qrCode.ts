import QRCode from 'react-native-qrcode-svg';
import Share from 'react-native-share';
import {captureRef} from 'react-native-view-shot';
import {getReferralLink} from './referral';

export interface QRCodeData {
  type: 'referral' | 'quote' | 'transaction';
  data: string;
  title?: string;
  description?: string;
}

// Generate QR code component (for rendering)
export const generateQRCodeComponent = (
  value: string,
  size: number = 200,
  color: string = '#000000',
  backgroundColor: string = '#FFFFFF'
) => {
  return (
    <QRCode
      value={value}
      size={size}
      color={color}
      backgroundColor={backgroundColor}
      logo={undefined} // Can add logo later
      logoSize={size * 0.2}
      logoBackgroundColor="transparent"
      logoMargin={2}
      logoBorderRadius={10}
      quietZone={10}
    />
  );
};

// Share QR code as image
export const shareQRCode = async (
  qrRef: React.RefObject<any>,
  referralLink: string,
  userName: string
): Promise<void> => {
  try {
    if (!qrRef.current) {
      throw new Error('QR code ref not available');
    }

    // Capture QR code as image
    const uri = await captureRef(qrRef.current, {
      format: 'png',
      quality: 1.0,
    });

    // Share the image with text
    await Share.open({
      title: 'Join UnderCut.Co',
      message: `Join me on UnderCut.Co! Use my referral link: ${referralLink}`,
      url: uri,
      type: 'image/png',
      subject: 'Join UnderCut.Co - Global Bartering Platform',
    });
  } catch (error: any) {
    if (error?.message !== 'User did not share') {
      console.error('Error sharing QR code:', error);
    }
  }
};

// Share referral link directly
export const shareReferralLink = async (
  referralLink: string,
  referralCode: string,
  userName: string
): Promise<void> => {
  try {
    const message = `Join me on UnderCut.Co - Global Bartering Platform! 🚀

Use my referral code: ${referralCode}

Sign up here: ${referralLink}

Get the lowest prices on products you want. Fast, secure, worldwide! 🌍`;

    await Share.open({
      title: 'Join UnderCut.Co',
      message,
      url: referralLink,
      subject: 'Join UnderCut.Co - Global Bartering Platform',
    });
  } catch (error: any) {
    if (error?.message !== 'User did not share') {
      console.error('Error sharing referral link:', error);
    }
  }
};

// Generate QR code data URL for referral
export const generateReferralQRData = async (
  userId: string
): Promise<{link: string; code: string}> => {
  const link = await getReferralLink(userId);
  // Extract code from link
  const code = link.split('/').pop() || '';
  return {link, code};
};

