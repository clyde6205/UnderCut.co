/**
 * Optimized Authentication Service
 * 
 * Fast, secure login/logout with caching and session management
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import {auth, firestore} from './firebase';
import {User} from '../types';

const USER_CACHE_KEY = '@UndercutCo:UserCache';
const SESSION_KEY = '@UndercutCo:Session';

/**
 * Cache user data for instant loading
 */
export const cacheUserData = async (user: User): Promise<void> => {
  try {
    await AsyncStorage.setItem(USER_CACHE_KEY, JSON.stringify({
      ...user,
      cachedAt: new Date().toISOString(),
    }));
  } catch (error) {
    console.error('Error caching user data:', error);
  }
};

/**
 * Get cached user data
 */
export const getCachedUserData = async (): Promise<User | null> => {
  try {
    const cached = await AsyncStorage.getItem(USER_CACHE_KEY);
    if (cached) {
      const data = JSON.parse(cached);
      // Cache valid for 1 hour
      const cachedAt = new Date(data.cachedAt);
      const now = new Date();
      const hoursDiff = (now.getTime() - cachedAt.getTime()) / (1000 * 60 * 60);
      
      if (hoursDiff < 1) {
        // Remove cachedAt from returned data
        const {cachedAt: _, ...userData} = data;
        return userData as User;
      }
    }
    return null;
  } catch (error) {
    console.error('Error getting cached user data:', error);
    return null;
  }
};

/**
 * Clear user cache
 */
export const clearUserCache = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(USER_CACHE_KEY);
    await AsyncStorage.removeItem(SESSION_KEY);
  } catch (error) {
    console.error('Error clearing user cache:', error);
  }
};

/**
 * Fast user data load with cache
 */
export const loadUserDataOptimized = async (uid: string, useCache: boolean = true): Promise<User | null> => {
  // Try cache first for instant loading
  if (useCache) {
    const cached = await getCachedUserData();
    if (cached && cached.id === uid) {
      // Return cached data immediately, then refresh in background
      refreshUserData(uid).catch(() => {
        // Silent fail - cache is acceptable
      });
      return cached;
    }
  }

  // Load from Firestore
  try {
    const userDoc = await firestore().collection('users').doc(uid).get();
    if (userDoc.exists) {
      const data = userDoc.data();
      const user: User = {
        id: uid,
        email: data?.email || '',
        displayName: data?.displayName || '',
        role: data?.role || 'buyer',
        verified: data?.verified || false,
        createdAt: data?.createdAt?.toDate() || new Date(),
        profileImage: data?.profileImage,
        location: data?.location,
        rating: data?.rating,
        totalTransactions: data?.totalTransactions || 0,
        referralCode: data?.referralCode,
        referredBy: data?.referredBy,
        referralCount: data?.referralCount || 0,
        totalReferralEarnings: data?.totalReferralEarnings || 0,
        favorites: data?.favorites || [],
        buyerMetrics: data?.buyerMetrics,
        sellerMetrics: data?.sellerMetrics,
        chatSubscription: data?.chatSubscription ? {
          subscribed: data.chatSubscription.subscribed || false,
          subscribedAt: data.chatSubscription.subscribedAt?.toDate(),
          expiresAt: data.chatSubscription.expiresAt?.toDate(),
          lastPlatformUsage: data.chatSubscription.lastPlatformUsage?.toDate(),
          usageWarningSent: data.chatSubscription.usageWarningSent || false,
        } : undefined,
      };
      
      // Cache for next time
      await cacheUserData(user);
      return user;
    }
  } catch (error) {
    console.error('Error loading user data:', error);
  }
  
  return null;
};

/**
 * Refresh user data in background
 */
const refreshUserData = async (uid: string): Promise<void> => {
  try {
    const user = await loadUserDataOptimized(uid, false);
    if (user) {
      await cacheUserData(user);
    }
  } catch (error) {
    // Silent fail
  }
};

/**
 * Fast sign out - clear cache immediately
 */
export const fastSignOut = async (): Promise<void> => {
  try {
    // Clear cache immediately for instant logout
    await clearUserCache();
    // Sign out from Firebase (non-blocking)
    auth().signOut().catch(() => {
      // Silent fail - cache already cleared
    });
  } catch (error) {
    console.error('Error in fast sign out:', error);
    // Still try to sign out
    await auth().signOut();
  }
};

