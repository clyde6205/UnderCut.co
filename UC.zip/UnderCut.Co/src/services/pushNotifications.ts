import messaging, {FirebaseMessagingTypes} from '@react-native-firebase/messaging';
import {firestore} from './firebase';
import {Platform} from 'react-native';

// Request notification permissions
export const requestNotificationPermissions = async (): Promise<boolean> => {
  try {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
      console.log('Notification permissions granted');
      await saveFCMToken();
    }

    return enabled;
  } catch (error) {
    console.error('Error requesting notification permissions:', error);
    return false;
  }
};

// Save FCM token to user profile
export const saveFCMToken = async (userId?: string): Promise<void> => {
  try {
    const token = await messaging().getToken();
    
    if (!token) {
      console.warn('No FCM token available');
      return;
    }

    if (userId) {
      // Save token to user's document
      await firestore().collection('users').doc(userId).update({
        fcmToken: token,
        fcmTokenUpdatedAt: firestore.FieldValue.serverTimestamp(),
      });
    }

    console.log('FCM token saved:', token.substring(0, 20) + '...');
  } catch (error) {
    console.error('Error saving FCM token:', error);
  }
};

// Setup foreground message handler
export const setupForegroundMessageHandler = (
  onMessage: (message: FirebaseMessagingTypes.RemoteMessage) => void
): (() => void) => {
  const unsubscribe = messaging().onMessage(async (remoteMessage) => {
    console.log('Foreground message received:', remoteMessage);
    onMessage(remoteMessage);
  });

  return unsubscribe;
};

// Setup background message handler (must be called outside React component)
export const setupBackgroundMessageHandler = (): void => {
  messaging().setBackgroundMessageHandler(async (remoteMessage) => {
    console.log('Background message received:', remoteMessage);
    // Handle background notifications here
  });
};

// Setup notification handler for app opened from quit state
export const setupNotificationOpenedHandler = (
  onNotificationOpened: (message: FirebaseMessagingTypes.RemoteMessage) => void
): (() => void) => {
  messaging()
    .getInitialNotification()
    .then((remoteMessage) => {
      if (remoteMessage) {
        console.log('Notification opened app:', remoteMessage);
        onNotificationOpened(remoteMessage);
      }
    });

  const unsubscribe = messaging().onNotificationOpenedApp((remoteMessage) => {
    console.log('Notification opened app:', remoteMessage);
    onNotificationOpened(remoteMessage);
  });

  return unsubscribe;
};

// Send push notification to user (for chat messages)
export const sendChatNotification = async (
  userId: string,
  senderName: string,
  messageText: string,
  chatRoomId: string
): Promise<void> => {
  try {
    const userDoc = await firestore().collection('users').doc(userId).get();
    const userData = userDoc.data();
    const fcmToken = userData?.fcmToken;

    if (!fcmToken) {
      console.warn('No FCM token for user:', userId);
      return;
    }

    // In production, send via Firebase Cloud Functions or your backend
    // For now, this is a placeholder structure
    // You would call: https://fcm.googleapis.com/v1/projects/{project}/messages:send
    // Or use Firebase Admin SDK in Cloud Functions

    console.log('Chat notification prepared for:', userId);
  } catch (error) {
    console.error('Error sending chat notification:', error);
  }
};

// Initialize push notifications
export const initializePushNotifications = async (userId?: string): Promise<void> => {
  try {
    const hasPermission = await requestNotificationPermissions();
    
    if (hasPermission && userId) {
      await saveFCMToken(userId);
    }

    // Setup handlers
    setupBackgroundMessageHandler();
  } catch (error) {
    console.error('Error initializing push notifications:', error);
  }
};

