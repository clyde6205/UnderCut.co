import {firestore} from './firebase';
import {User} from '../types';
import {ReferralData} from '../types/admin';

const REFERRAL_CODE_LENGTH = 8;
const REFERRAL_BASE_URL = 'https://undercut.co/ref';

// Generate unique referral code
export const generateReferralCode = (userId: string): string => {
  // Use first 4 chars of user ID + random 4 chars
  const prefix = userId.substring(0, 4).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}${random}`;
};

// Create or get user's referral code
export const getUserReferralCode = async (userId: string): Promise<string> => {
  try {
    const userDoc = await firestore().collection('users').doc(userId).get();
    
    if (!userDoc.exists) {
      throw new Error('User not found');
    }

    const userData = userDoc.data();
    
    // If user already has a referral code, return it
    if (userData?.referralCode) {
      return userData.referralCode;
    }

    // Generate new referral code
    let referralCode = generateReferralCode(userId);
    let attempts = 0;
    const maxAttempts = 10;

    // Ensure uniqueness
    while (attempts < maxAttempts) {
      const existing = await firestore()
        .collection('users')
        .where('referralCode', '==', referralCode)
        .limit(1)
        .get();

      if (existing.empty) {
        break; // Code is unique
      }

      referralCode = generateReferralCode(userId);
      attempts++;
    }

    // Save referral code to user
    await firestore().collection('users').doc(userId).update({
      referralCode,
      referralCount: 0,
      totalReferralEarnings: 0,
    });

    return referralCode;
  } catch (error) {
    console.error('Error getting user referral code:', error);
    throw error;
  }
};

// Get referral link
export const getReferralLink = async (userId: string): Promise<string> => {
  const code = await getUserReferralCode(userId);
  return `${REFERRAL_BASE_URL}/${code}`;
};

// Process referral when new user signs up
export const processReferral = async (
  referredUserId: string,
  referralCode: string
): Promise<void> => {
  try {
    // Find referrer by code
    const referrers = await firestore()
      .collection('users')
      .where('referralCode', '==', referralCode)
      .limit(1)
      .get();

    if (referrers.empty) {
      console.warn('Referral code not found:', referralCode);
      return;
    }

    const referrerDoc = referrers.docs[0];
    const referrerId = referrerDoc.id;
    const referrerData = referrerDoc.data();

    // Prevent self-referral
    if (referrerId === referredUserId) {
      return;
    }

    // Get referred user data
    const referredUserDoc = await firestore().collection('users').doc(referredUserId).get();
    const referredUserData = referredUserDoc.data();

    // Create referral record
    const referralData: Omit<ReferralData, 'id'> = {
      referrerId,
      referrerName: referrerData?.displayName || 'Unknown',
      referredUserId,
      referredUserName: referredUserData?.displayName || 'Unknown',
      referralCode,
      status: 'pending',
      createdAt: new Date(),
    };

    await firestore().collection('referrals').add({
      ...referralData,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    // Update referrer's referral count
    await firestore().collection('users').doc(referrerId).update({
      referralCount: firestore.FieldValue.increment(1),
    });

    // Update referred user
    await firestore().collection('users').doc(referredUserId).update({
      referredBy: referrerId,
    });
  } catch (error) {
    console.error('Error processing referral:', error);
    throw error;
  }
};

// Check if referral code is valid
export const validateReferralCode = async (code: string): Promise<boolean> => {
  try {
    const result = await firestore()
      .collection('users')
      .where('referralCode', '==', code)
      .limit(1)
      .get();

    return !result.empty;
  } catch (error) {
    console.error('Error validating referral code:', error);
    return false;
  }
};

// Get user's referral statistics
export const getUserReferralStats = async (userId: string): Promise<{
  referralCount: number;
  totalEarnings: number;
  activeReferrals: number;
  completedReferrals: number;
}> => {
  try {
    const userDoc = await firestore().collection('users').doc(userId).get();
    const userData = userDoc.data();

    const referralsSnapshot = await firestore()
      .collection('referrals')
      .where('referrerId', '==', userId)
      .get();

    const referrals = referralsSnapshot.docs.map(doc => doc.data());
    const completed = referrals.filter(r => r.status === 'completed').length;

    return {
      referralCount: userData?.referralCount || 0,
      totalEarnings: userData?.totalReferralEarnings || 0,
      activeReferrals: referrals.length - completed,
      completedReferrals: completed,
    };
  } catch (error) {
    console.error('Error getting referral stats:', error);
    throw error;
  }
};

// Get all referrals for a user
export const getUserReferrals = async (userId: string): Promise<ReferralData[]> => {
  try {
    const snapshot = await firestore()
      .collection('referrals')
      .where('referrerId', '==', userId)
      .orderBy('createdAt', 'desc')
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      completedAt: doc.data().completedAt?.toDate(),
    })) as ReferralData[];
  } catch (error) {
    console.error('Error getting user referrals:', error);
    throw error;
  }
};

