import i18n from 'i18next';
import {initReactI18next} from 'react-i18next';
import * as RNLocalize from 'react-native-localize';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {getConfig} from '../config/appConfig';

// Translation API Configuration
// For production, set these via environment variables or config
let TRANSLATION_API_KEY: string | undefined;
let TRANSLATION_API_URL = 'https://translation.googleapis.com/language/translate/v2';

// Initialize API configuration from config
export const setTranslationAPIKey = (apiKey: string) => {
  TRANSLATION_API_KEY = apiKey;
};

// Supported languages - can be expanded
export const SUPPORTED_LANGUAGES = [
  {code: 'en', name: 'English', nativeName: 'English'},
  {code: 'es', name: 'Spanish', nativeName: 'Español'},
  {code: 'fr', name: 'French', nativeName: 'Français'},
  {code: 'de', name: 'German', nativeName: 'Deutsch'},
  {code: 'it', name: 'Italian', nativeName: 'Italiano'},
  {code: 'pt', name: 'Portuguese', nativeName: 'Português'},
  {code: 'ru', name: 'Russian', nativeName: 'Русский'},
  {code: 'zh', name: 'Chinese', nativeName: '中文'},
  {code: 'ja', name: 'Japanese', nativeName: '日本語'},
  {code: 'ko', name: 'Korean', nativeName: '한국어'},
  {code: 'ar', name: 'Arabic', nativeName: 'العربية'},
  {code: 'hi', name: 'Hindi', nativeName: 'हिन्दी'},
  {code: 'tr', name: 'Turkish', nativeName: 'Türkçe'},
  {code: 'pl', name: 'Polish', nativeName: 'Polski'},
  {code: 'nl', name: 'Dutch', nativeName: 'Nederlands'},
  {code: 'sv', name: 'Swedish', nativeName: 'Svenska'},
  {code: 'da', name: 'Danish', nativeName: 'Dansk'},
  {code: 'fi', name: 'Finnish', nativeName: 'Suomi'},
  {code: 'no', name: 'Norwegian', nativeName: 'Norsk'},
  {code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt'},
  {code: 'th', name: 'Thai', nativeName: 'ไทย'},
  {code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia'},
  {code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu'},
  {code: 'cs', name: 'Czech', nativeName: 'Čeština'},
  {code: 'hu', name: 'Hungarian', nativeName: 'Magyar'},
  {code: 'ro', name: 'Romanian', nativeName: 'Română'},
  {code: 'el', name: 'Greek', nativeName: 'Ελληνικά'},
  {code: 'he', name: 'Hebrew', nativeName: 'עברית'},
  {code: 'uk', name: 'Ukrainian', nativeName: 'Українська'},
  {code: 'bg', name: 'Bulgarian', nativeName: 'Български'},
  {code: 'hr', name: 'Croatian', nativeName: 'Hrvatski'},
  {code: 'sk', name: 'Slovak', nativeName: 'Slovenčina'},
  {code: 'sl', name: 'Slovenian', nativeName: 'Slovenščina'},
];

const LANGUAGE_STORAGE_KEY = '@UndercutCo:Language';

// Translation resources - Base translations in English
const resources = {
  en: {
    translation: require('../locales/en.json'),
  },
  // Other languages will be loaded dynamically or via API
};

// Get device language
const getDeviceLanguage = (): string => {
  const locales = RNLocalize.getLocales();
  if (locales.length > 0) {
    const deviceLang = locales[0].languageCode;
    // Check if device language is supported
    const supported = SUPPORTED_LANGUAGES.find(lang => lang.code === deviceLang);
    if (supported) {
      return deviceLang;
    }
    // Try to match language family (e.g., pt-BR -> pt)
    const baseLang = deviceLang.split('-')[0];
    const baseSupported = SUPPORTED_LANGUAGES.find(lang => lang.code === baseLang);
    if (baseSupported) {
      return baseLang;
    }
  }
  return 'en'; // Default to English
};

// Initialize i18n
export const initializeI18n = async (): Promise<void> => {
  try {
    // Load saved language preference
    const savedLanguage = await AsyncStorage.getItem(LANGUAGE_STORAGE_KEY);
    const language = savedLanguage || getDeviceLanguage();

    await i18n
      .use(initReactI18next)
      .init({
        resources,
        lng: language,
        fallbackLng: 'en',
        compatibilityJSON: 'v3',
        interpolation: {
          escapeValue: false,
        },
        react: {
          useSuspense: false,
        },
      });

    // Load translations for the selected language if not English
    if (language !== 'en') {
      await loadLanguageTranslations(language);
    }

    console.log(`i18n initialized with language: ${language}`);
  } catch (error) {
    console.error('Error initializing i18n:', error);
    // Fallback to English
    await i18n.use(initReactI18next).init({
      resources: {en: {translation: require('../locales/en.json')}},
      lng: 'en',
      fallbackLng: 'en',
      compatibilityJSON: 'v3',
    });
  }
};

// Change language
export const changeLanguage = async (languageCode: string): Promise<void> => {
  try {
    await AsyncStorage.setItem(LANGUAGE_STORAGE_KEY, languageCode);
    
    // Load translations if not already loaded
    if (!i18n.hasResourceBundle(languageCode, 'translation')) {
      await loadLanguageTranslations(languageCode);
    }
    
    await i18n.changeLanguage(languageCode);
    console.log(`Language changed to: ${languageCode}`);
  } catch (error) {
    console.error('Error changing language:', error);
    throw error;
  }
};

// Get current language
export const getCurrentLanguage = (): string => {
  return i18n.language || 'en';
};

// Load translations for a language (from API or local files)
const loadLanguageTranslations = async (languageCode: string): Promise<void> => {
  try {
    // Try to load from local file first
    try {
      const translations = require(`../locales/${languageCode}.json`);
      i18n.addResourceBundle(languageCode, 'translation', translations, true, true);
      return;
    } catch {
      // If local file doesn't exist, use API
    }

    // Use translation API to get translations
    const config = getConfig();
    if (config.useTranslationAPI && config.translationAPIKey) {
      TRANSLATION_API_KEY = config.translationAPIKey;
      await loadTranslationsFromAPI(languageCode);
    } else {
      // Fallback: use English translations
      const enTranslations = require('../locales/en.json');
      i18n.addResourceBundle(languageCode, 'translation', enTranslations, true, true);
    }
  } catch (error) {
    console.error(`Error loading translations for ${languageCode}:`, error);
    // Fallback to English
    const enTranslations = require('../locales/en.json');
    i18n.addResourceBundle(languageCode, 'translation', enTranslations, true, true);
  }
};

// Load translations from Google Translate API (or similar)
const loadTranslationsFromAPI = async (targetLanguage: string): Promise<void> => {
  try {
    const enTranslations = require('../locales/en.json');
    const keys = Object.keys(enTranslations);
    const translations: Record<string, string> = {};

    // Translate all keys (in production, batch this or cache results)
    for (const key of keys) {
      try {
        const response = await axios.post(
          TRANSLATION_API_URL,
          {
            q: enTranslations[key],
            target: targetLanguage,
            source: 'en',
            format: 'text',
          },
          {
            headers: {
              'Content-Type': 'application/json',
            },
        params: {
          key: TRANSLATION_API_KEY || '',
        },
          }
        );

        translations[key] = response.data.data.translations[0].translatedText;
      } catch (error) {
        // If API fails, use original English text
        translations[key] = enTranslations[key];
      }
    }

    i18n.addResourceBundle(targetLanguage, 'translation', translations, true, true);
  } catch (error) {
    console.error('Error loading translations from API:', error);
    throw error;
  }
};

// Translate text dynamically (for user-generated content)
export const translateText = async (
  text: string,
  targetLanguage?: string
): Promise<string> => {
  try {
    const lang = targetLanguage || getCurrentLanguage();
    
    if (lang === 'en') {
      return text; // Already in English
    }

    const config = getConfig();
    const apiKey = config.translationAPIKey || TRANSLATION_API_KEY;
    if (!config.useTranslationAPI || !apiKey) {
      return text; // No API configured
    }

    const response = await axios.post(
      TRANSLATION_API_URL,
      {
        q: text,
        target: lang,
        source: 'en',
        format: 'text',
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
        params: {
          key: apiKey,
        },
      }
    );

    return response.data.data.translations[0].translatedText;
  } catch (error) {
    console.error('Error translating text:', error);
    return text; // Return original text on error
  }
};

export default i18n;

