import firestore from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';
import storage from '@react-native-firebase/storage';
import {getConfig} from '../config/appConfig';

// React Native Firebase initializes automatically via native modules
// This service provides initialization checks and configuration
export const initializeFirebase = async (): Promise<void> => {
  try {
    const config = getConfig();
    
    if (!config.useFirebase) {
      console.warn('Firebase not enabled in configuration. Some features may not work.');
      return;
    }

    // React Native Firebase is initialized automatically via native configuration
    // Just verify it's working
    const firestoreInstance = firestore();
    
    // Enable offline persistence for instant startup and no cold starts
    // Messages load instantly from local cache
    firestoreInstance.settings({
      persistence: true,
      cacheSizeBytes: firestore.CACHE_SIZE_UNLIMITED,
    });
    
    console.log('Firebase initialized successfully with offline persistence');
  } catch (error) {
    console.error('Firebase initialization error:', error);
    throw error;
  }
};

// Export Firebase instances for use throughout the app
export {firestore, auth, storage};

export const isFirebaseInitialized = (): boolean => {
  try {
    // Check if Firebase is accessible
    const instance = firestore();
    return instance !== null;
  } catch {
    return false;
  }
};

