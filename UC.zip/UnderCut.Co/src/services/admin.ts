import {firestore} from './firebase';
import {PlatformAnalytics, PlatformSettings, AdminAction, ReferralData} from '../types/admin';
import {User, Transaction, Quote, Bid} from '../types';

// Get platform analytics
export const getPlatformAnalytics = async (): Promise<PlatformAnalytics> => {
  try {
    const now = new Date();
    const today = new Date(now.setHours(0, 0, 0, 0));
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Get all users
    const usersSnapshot = await firestore().collection('users').get();
    const users = usersSnapshot.docs.map(doc => doc.data());
    
    const totalUsers = users.length;
    const totalBuyers = users.filter(u => u.role === 'buyer').length;
    const totalSellers = users.filter(u => u.role === 'seller').length;
    const activeUsers = users.filter(u => {
      const lastActive = u.lastActiveAt?.toDate();
      return lastActive && lastActive > weekAgo;
    }).length;

    // Get quotes
    const quotesSnapshot = await firestore().collection('quotes').get();
    const totalQuotes = quotesSnapshot.size;

    // Get bids
    const bidsSnapshot = await firestore().collection('bids').get();
    const totalBids = bidsSnapshot.size;

    // Get transactions
    const transactionsSnapshot = await firestore().collection('transactions').get();
    const transactions = transactionsSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    })) as Transaction[];

    const totalTransactions = transactions.length;
    const completedTransactions = transactions.filter(t => t.status === 'completed').length;
    const totalTransactionVolume = transactions
      .filter(t => t.status === 'completed')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    const averageTransactionValue = completedTransactions > 0 
      ? totalTransactionVolume / completedTransactions 
      : 0;

    // Calculate new users
    const newUsersToday = users.filter(u => {
      const createdAt = u.createdAt?.toDate();
      return createdAt && createdAt >= today;
    }).length;

    const newUsersThisWeek = users.filter(u => {
      const createdAt = u.createdAt?.toDate();
      return createdAt && createdAt >= weekAgo;
    }).length;

    const newUsersThisMonth = users.filter(u => {
      const createdAt = u.createdAt?.toDate();
      return createdAt && createdAt >= monthAgo;
    }).length;

    // Calculate transactions
    const transactionsToday = transactions.filter(t => {
      return t.createdAt && t.createdAt >= today;
    }).length;

    const transactionsThisWeek = transactions.filter(t => {
      return t.createdAt && t.createdAt >= weekAgo;
    }).length;

    const transactionsThisMonth = transactions.filter(t => {
      return t.createdAt && t.createdAt >= monthAgo;
    }).length;

    // Get referrals
    const referralsSnapshot = await firestore().collection('referrals').get();
    const activeReferrals = referralsSnapshot.size;

    // Top categories
    const categoryCounts: Record<string, {count: number; volume: number}> = {};
    quotesSnapshot.docs.forEach(doc => {
      const data = doc.data();
      const category = data.category || 'Unknown';
      if (!categoryCounts[category]) {
        categoryCounts[category] = {count: 0, volume: 0};
      }
      categoryCounts[category].count++;
      categoryCounts[category].volume += data.maxPrice || 0;
    });

    const topCategories = Object.entries(categoryCounts)
      .map(([category, data]) => ({
        category,
        count: data.count,
        volume: data.volume,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    // Top countries
    const countryData: Record<string, {users: number; transactions: number}> = {};
    users.forEach(u => {
      const country = u.location?.country || 'Unknown';
      if (!countryData[country]) {
        countryData[country] = {users: 0, transactions: 0};
      }
      countryData[country].users++;
    });

    transactions.forEach(t => {
      // Would need to get user location from transaction
      // For now, just count users
    });

    const topCountries = Object.entries(countryData)
      .map(([country, data]) => ({
        country,
        users: data.users,
        transactions: data.transactions,
      }))
      .sort((a, b) => b.users - a.users)
      .slice(0, 10);

    return {
      totalUsers,
      activeUsers,
      totalBuyers,
      totalSellers,
      totalQuotes,
      totalBids,
      totalTransactions,
      completedTransactions,
      totalTransactionVolume,
      averageTransactionValue,
      platformRevenue: totalTransactionVolume * 0.02, // 2% platform fee estimate
      activeReferrals,
      newUsersToday,
      newUsersThisWeek,
      newUsersThisMonth,
      transactionsToday,
      transactionsThisWeek,
      transactionsThisMonth,
      topCategories,
      topCountries,
      userGrowth: [], // Would need historical data
      transactionGrowth: [], // Would need historical data
    };
  } catch (error) {
    console.error('Error getting platform analytics:', error);
    throw error;
  }
};

// Get platform settings
export const getPlatformSettings = async (): Promise<PlatformSettings> => {
  try {
    const settingsDoc = await firestore().collection('platformSettings').doc('main').get();
    
    if (settingsDoc.exists) {
      return settingsDoc.data() as PlatformSettings;
    }

    // Return default settings
    return {
      maintenanceMode: false,
      registrationEnabled: true,
      transactionTimeoutHours: 72,
      escrowCoolDownHours: 24,
      platformFeePercentage: 2.0,
      referralRewardAmount: 10,
      minReferralTransactions: 1,
      maxQuotesPerUser: 50,
      maxBidsPerQuote: 100,
    };
  } catch (error) {
    console.error('Error getting platform settings:', error);
    throw error;
  }
};

// Update platform settings
export const updatePlatformSettings = async (
  settings: Partial<PlatformSettings>
): Promise<void> => {
  try {
    await firestore().collection('platformSettings').doc('main').set(
      {
        ...settings,
        updatedAt: firestore.FieldValue.serverTimestamp(),
      },
      {merge: true}
    );
  } catch (error) {
    console.error('Error updating platform settings:', error);
    throw error;
  }
};

// Log admin action
export const logAdminAction = async (action: Omit<AdminAction, 'id' | 'timestamp'>): Promise<void> => {
  try {
    await firestore().collection('adminActions').add({
      ...action,
      timestamp: firestore.FieldValue.serverTimestamp(),
    });
  } catch (error) {
    console.error('Error logging admin action:', error);
  }
};

// Get all users (for admin)
export const getAllUsers = async (limit: number = 100): Promise<User[]> => {
  try {
    const snapshot = await firestore()
      .collection('users')
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    })) as User[];
  } catch (error) {
    console.error('Error getting all users:', error);
    throw error;
  }
};

// Update user (admin action)
export const updateUserAsAdmin = async (
  userId: string,
  updates: Partial<User>,
  adminId: string,
  adminName: string
): Promise<void> => {
  try {
    await firestore().collection('users').doc(userId).update(updates);
    
    await logAdminAction({
      adminId,
      adminName,
      action: 'update_user',
      targetType: 'user',
      targetId: userId,
      details: updates,
    });
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
};

// Get all referrals (admin)
export const getAllReferrals = async (limit: number = 100): Promise<ReferralData[]> => {
  try {
    const snapshot = await firestore()
      .collection('referrals')
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      completedAt: doc.data().completedAt?.toDate(),
    })) as ReferralData[];
  } catch (error) {
    console.error('Error getting all referrals:', error);
    throw error;
  }
};

