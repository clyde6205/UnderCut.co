import {initStripe, StripeProvider, useStripe} from '@stripe/stripe-react-native';
import {getConfig} from '../config/appConfig';
import axios from 'axios';

let stripeInitialized = false;

export const initializeStripe = async (): Promise<void> => {
  try {
    const config = getConfig();
    
    if (config.paymentProcessor !== 'stripe') {
      console.warn('Stripe is not the active payment processor');
      return;
    }

    if (!config.stripePublishableKey) {
      throw new Error('Stripe publishable key not configured');
    }

    if (stripeInitialized) {
      return;
    }

    await initStripe({
      publishableKey: config.stripePublishableKey,
      merchantIdentifier: 'merchant.undercut.co',
      setReturnUrlSchemeOnAndroid: true,
    });

    stripeInitialized = true;
    console.log('Stripe initialized successfully');
  } catch (error) {
    console.error('Stripe initialization error:', error);
    throw error;
  }
};

export interface PaymentIntent {
  clientSecret: string;
  amount: number;
  currency: string;
}

export const createPaymentIntent = async (
  amount: number,
  currency: string = 'USD',
  transactionId: string
): Promise<PaymentIntent> => {
  try {
    const config = getConfig();
    
    // In production, this should call your backend API
    // For now, this is a placeholder structure
    const response = await axios.post('/api/stripe/create-payment-intent', {
      amount: Math.round(amount * 100), // Convert to cents
      currency: currency.toLowerCase(),
      transactionId,
      // We never hold money - Stripe handles everything
      applicationFeeAmount: 0, // Platform fee would be set here
    });

    return {
      clientSecret: response.data.clientSecret,
      amount,
      currency,
    };
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw error;
  }
};

export const confirmPayment = async (
  clientSecret: string,
  paymentMethodId: string
): Promise<{success: boolean; transactionId?: string}> => {
  try {
    const {confirmPayment} = useStripe();
    
    const {error, paymentIntent} = await confirmPayment(clientSecret, {
      paymentMethodType: 'Card',
      paymentMethodData: {
        billingDetails: {
          // Add billing details if needed
        },
      },
    });

    if (error) {
      return {success: false};
    }

    return {
      success: paymentIntent?.status === 'Succeeded',
      transactionId: paymentIntent?.id,
    };
  } catch (error) {
    console.error('Error confirming payment:', error);
    return {success: false};
  }
};

export const isStripeInitialized = (): boolean => {
  return stripeInitialized;
};

// Export Stripe hooks
export {StripeProvider, useStripe};

