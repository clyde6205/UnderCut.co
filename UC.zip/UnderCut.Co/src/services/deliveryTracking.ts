/**
 * Delivery Tracking Service
 * 
 * Track shipments and delivery status
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {Transaction} from '../types';

export interface TrackingUpdate {
  status: 'pending' | 'preparing' | 'shipped' | 'in_transit' | 'delivered';
  location?: string;
  timestamp: Date;
  message?: string;
  carrier?: string;
  trackingNumber?: string;
}

/**
 * Update delivery tracking for transaction
 */
export const updateDeliveryTracking = async (
  transactionId: string,
  update: Partial<TrackingUpdate>
): Promise<void> => {
  try {
    const transactionRef = firestore().collection('transactions').doc(transactionId);
    const transactionDoc = await transactionRef.get();

    if (!transactionDoc.exists) {
      throw new Error('Transaction not found');
    }

    const currentTracking = transactionDoc.data()?.deliveryTracking || {status: 'pending'};
    
    const trackingUpdate: TrackingUpdate = {
      status: update.status || currentTracking.status,
      location: update.location || currentTracking.location,
      timestamp: new Date(),
      message: update.message,
      carrier: update.carrier || currentTracking.carrier,
      trackingNumber: update.trackingNumber || currentTracking.trackingNumber,
    };

    await transactionRef.update({
      deliveryTracking: {
        ...currentTracking,
        ...trackingUpdate,
        ...(update.status === 'shipped' && {shippedAt: firestore.FieldValue.serverTimestamp()}),
        ...(update.status === 'delivered' && {deliveredAt: firestore.FieldValue.serverTimestamp()}),
      },
    });

    // Update transaction status if delivered
    if (update.status === 'delivered') {
      await transactionRef.update({
        status: 'completed',
        completedAt: firestore.FieldValue.serverTimestamp(),
      });
    }
  } catch (error) {
    console.error('Error updating delivery tracking:', error);
    throw error;
  }
};

/**
 * Add tracking number to transaction
 */
export const addTrackingNumber = async (
  transactionId: string,
  carrier: string,
  trackingNumber: string
): Promise<void> => {
  await updateDeliveryTracking(transactionId, {
    status: 'shipped',
    carrier,
    trackingNumber,
    message: `Package shipped via ${carrier}. Tracking: ${trackingNumber}`,
  });
};

/**
 * Get delivery tracking for transaction
 */
export const getDeliveryTracking = async (transactionId: string): Promise<TrackingUpdate | null> => {
  try {
    const doc = await firestore().collection('transactions').doc(transactionId).get();
    
    if (!doc.exists) {
      return null;
    }

    const data = doc.data();
    return data?.deliveryTracking || null;
  } catch (error) {
    console.error('Error getting delivery tracking:', error);
    return null;
  }
};

