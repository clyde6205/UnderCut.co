/**
 * Market Insights Service
 * 
 * Price trends, market data, and analytics for buyers
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {MarketInsight, Quote, Bid} from '../types';

/**
 * Get market insights for category
 */
export const getMarketInsights = async (category: string): Promise<MarketInsight | null> => {
  try {
    // Get all active quotes in category
    const quotesSnapshot = await firestore()
      .collection('quotes')
      .where('category', '==', category)
      .where('status', 'in', ['quote_posted', 'bids_received'])
      .get();

    if (quotesSnapshot.empty) {
      return null;
    }

    const quotes = quotesSnapshot.docs.map(doc => doc.data() as Quote);
    const quoteIds = quotes.map(q => q.id);

    // Get all bids for these quotes
    const bidsSnapshot = await firestore()
      .collection('bids')
      .where('quoteId', 'in', quoteIds.slice(0, 10)) // Firestore limit
      .get();

    const bids = bidsSnapshot.docs.map(doc => doc.data() as Bid);

    if (bids.length === 0) {
      return {
        category,
        averagePrice: 0,
        lowestPrice: 0,
        highestPrice: 0,
        totalQuotes: quotes.length,
        totalBids: 0,
        priceTrend: 'stable',
        lastUpdated: new Date(),
      };
    }

    const prices = bids.map(b => b.price);
    const averagePrice = prices.reduce((a, b) => a + b, 0) / prices.length;
    const lowestPrice = Math.min(...prices);
    const highestPrice = Math.max(...prices);

    // Calculate trend (simplified - compare with previous period)
    const priceTrend: 'up' | 'down' | 'stable' = 'stable'; // Would need historical data

    return {
      category,
      averagePrice: Math.round(averagePrice),
      lowestPrice,
      highestPrice,
      totalQuotes: quotes.length,
      totalBids: bids.length,
      priceTrend,
      lastUpdated: new Date(),
    };
  } catch (error) {
    console.error('Error getting market insights:', error);
    return null;
  }
};

/**
 * Calculate savings for buyer (maxPrice - bestBidPrice)
 */
export const calculateSavings = (maxPrice: number, bestBidPrice: number): {
  amount: number;
  percentage: number;
} => {
  const savings = maxPrice - bestBidPrice;
  const percentage = (savings / maxPrice) * 100;

  return {
    amount: savings,
    percentage: Math.round(percentage * 10) / 10,
  };
};

/**
 * Get price comparison for quote (all bids sorted)
 */
export const getPriceComparison = async (quoteId: string): Promise<{
  bids: Bid[];
  lowestPrice: number;
  averagePrice: number;
  savings?: {amount: number; percentage: number};
} | null> => {
  try {
    const quoteDoc = await firestore().collection('quotes').doc(quoteId).get();
    if (!quoteDoc.exists) {
      return null;
    }

    const quote = quoteDoc.data() as Quote;

    const bidsSnapshot = await firestore()
      .collection('bids')
      .where('quoteId', '==', quoteId)
      .orderBy('price', 'asc')
      .get();

    const bids = bidsSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    })) as Bid[];

    if (bids.length === 0) {
      return {
        bids: [],
        lowestPrice: quote.maxPrice,
        averagePrice: quote.maxPrice,
      };
    }

    const prices = bids.map(b => b.price);
    const lowestPrice = prices[0];
    const averagePrice = prices.reduce((a, b) => a + b, 0) / prices.length;

    const savings = calculateSavings(quote.maxPrice, lowestPrice);

    return {
      bids,
      lowestPrice,
      averagePrice: Math.round(averagePrice),
      savings,
    };
  } catch (error) {
    console.error('Error getting price comparison:', error);
    return null;
  }
};

