/**
 * Price Alert Service
 * 
 * Real-time notifications for new bids, price drops, and quote expiration
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {PriceAlert, Bid, Quote} from '../types';
import {sendChatNotification} from './pushNotifications';

export type AlertType = 'new_bid' | 'price_drop' | 'expiring_soon' | 'best_price';

/**
 * Create price alert for a quote
 */
export const createPriceAlert = async (
  userId: string,
  quoteId: string,
  alertType: AlertType,
  thresholdPrice?: number
): Promise<void> => {
  try {
    const alert: Omit<PriceAlert, 'id'> = {
      userId,
      quoteId,
      alertType,
      thresholdPrice,
      isActive: true,
      createdAt: new Date(),
    };

    await firestore().collection('priceAlerts').add({
      ...alert,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });
  } catch (error) {
    console.error('Error creating price alert:', error);
    throw error;
  }
};

/**
 * Check and trigger alerts for new bid
 */
export const checkNewBidAlerts = async (quoteId: string, newBid: Bid): Promise<void> => {
  try {
    // Get all active alerts for this quote
    const alertsSnapshot = await firestore()
      .collection('priceAlerts')
      .where('quoteId', '==', quoteId)
      .where('isActive', '==', true)
      .where('alertType', '==', 'new_bid')
      .get();

    // Get quote owner
    const quoteDoc = await firestore().collection('quotes').doc(quoteId).get();
    if (!quoteDoc.exists) return;

    const quote = quoteDoc.data() as Quote;

    // Notify quote owner of new bid
    await sendChatNotification(
      quote.buyerId,
      newBid.sellerName,
      `New bid received: ${newBid.currency} ${newBid.price.toLocaleString()}`,
      `quote_${quoteId}`
    );

    // Process each alert
    alertsSnapshot.forEach(async doc => {
      const alert = doc.data() as PriceAlert;
      // Send notification to user
      await sendChatNotification(
        alert.userId,
        'UnderCut.Co',
        `New bid on your quote: ${newBid.currency} ${newBid.price.toLocaleString()}`,
        `quote_${quoteId}`
      );
    });
  } catch (error) {
    console.error('Error checking new bid alerts:', error);
  }
};

/**
 * Check and trigger price drop alerts
 */
export const checkPriceDropAlerts = async (quoteId: string, currentLowestPrice: number): Promise<void> => {
  try {
    const alertsSnapshot = await firestore()
      .collection('priceAlerts')
      .where('quoteId', '==', quoteId)
      .where('isActive', '==', true)
      .where('alertType', '==', 'price_drop')
      .get();

    alertsSnapshot.forEach(async doc => {
      const alert = doc.data() as PriceAlert;
      
      // Check if price dropped below threshold
      if (alert.thresholdPrice && currentLowestPrice < alert.thresholdPrice) {
        await sendChatNotification(
          alert.userId,
          'UnderCut.Co',
          `Price dropped! New lowest bid: ${currentLowestPrice.toLocaleString()}`,
          `quote_${quoteId}`
        );
      }
    });
  } catch (error) {
    console.error('Error checking price drop alerts:', error);
  }
};

/**
 * Check expiring soon alerts
 */
export const checkExpiringAlerts = async (): Promise<void> => {
  try {
    const oneHourFromNow = new Date(Date.now() + 60 * 60 * 1000);
    
    // Get quotes expiring soon
    const quotesSnapshot = await firestore()
      .collection('quotes')
      .where('expiresAt', '<=', firestore.Timestamp.fromDate(oneHourFromNow))
      .where('status', '==', 'quote_posted')
      .get();

    quotesSnapshot.forEach(async doc => {
      const quote = doc.data() as Quote;
      
      // Get alerts for this quote
      const alertsSnapshot = await firestore()
        .collection('priceAlerts')
        .where('quoteId', '==', quote.id)
        .where('isActive', '==', true)
        .where('alertType', '==', 'expiring_soon')
        .get();

      alertsSnapshot.forEach(async alertDoc => {
        const alert = alertDoc.data() as PriceAlert;
        await sendChatNotification(
          alert.userId,
          'UnderCut.Co',
          `Quote expiring soon: ${quote.title}`,
          `quote_${quote.id}`
        );
      });
    });
  } catch (error) {
    console.error('Error checking expiring alerts:', error);
  }
};

/**
 * Disable price alert
 */
export const disablePriceAlert = async (alertId: string): Promise<void> => {
  try {
    await firestore().collection('priceAlerts').doc(alertId).update({
      isActive: false,
    });
  } catch (error) {
    console.error('Error disabling price alert:', error);
    throw error;
  }
};

/**
 * Get user's active alerts
 */
export const getUserAlerts = async (userId: string): Promise<PriceAlert[]> => {
  try {
    const snapshot = await firestore()
      .collection('priceAlerts')
      .where('userId', '==', userId)
      .where('isActive', '==', true)
      .orderBy('createdAt', 'desc')
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    })) as PriceAlert[];
  } catch (error) {
    console.error('Error getting user alerts:', error);
    return [];
  }
};

