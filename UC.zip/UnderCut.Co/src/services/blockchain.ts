import {ethers} from 'ethers';
import {getConfig} from '../config/appConfig';
import {BlockchainTransaction} from '../types';

let provider: ethers.JsonRpcProvider | null = null;

export const initializeBlockchain = async (): Promise<void> => {
  try {
    const config = getConfig();
    
    if (!config.blockchainRpcUrl) {
      console.warn('Blockchain RPC URL not configured');
      return;
    }

    provider = new ethers.JsonRpcProvider(config.blockchainRpcUrl);
    
    console.log(`Blockchain provider initialized for ${config.blockchainNetwork}`);
  } catch (error) {
    console.error('Blockchain initialization error:', error);
    throw error;
  }
};

export const recordTransaction = async (
  transactionId: string,
  txHash: string,
  fromAddress: string,
  toAddress: string,
  amount: string,
  network: string = 'ethereum'
): Promise<BlockchainTransaction> => {
  try {
    if (!provider) {
      await initializeBlockchain();
    }

    if (!provider) {
      throw new Error('Blockchain provider not initialized');
    }

    const tx = await provider.getTransaction(txHash);
    const receipt = await provider.waitForTransaction(txHash);

    const blockchainTx: BlockchainTransaction = {
      txHash,
      blockNumber: receipt?.blockNumber || 0,
      from: fromAddress,
      to: toAddress,
      amount,
      timestamp: new Date(),
      status: receipt?.status === 1 ? 'confirmed' : 'failed',
      network,
    };

    // In production, this would save to your database
    // For now, we return the transaction record
    return blockchainTx;
  } catch (error) {
    console.error('Error recording blockchain transaction:', error);
    throw error;
  }
};

export const verifyTransaction = async (txHash: string): Promise<boolean> => {
  try {
    if (!provider) {
      await initializeBlockchain();
    }

    if (!provider) {
      return false;
    }

    const receipt = await provider.getTransactionReceipt(txHash);
    return receipt !== null && receipt.status === 1;
  } catch (error) {
    console.error('Error verifying transaction:', error);
    return false;
  }
};

export const getTransactionHistory = async (
  address: string,
  limit: number = 100
): Promise<BlockchainTransaction[]> => {
  try {
    if (!provider) {
      await initializeBlockchain();
    }

    if (!provider) {
      return [];
    }

    // This would typically query your database for stored transactions
    // For now, return empty array as placeholder
    return [];
  } catch (error) {
    console.error('Error getting transaction history:', error);
    return [];
  }
};

export const isBlockchainInitialized = (): boolean => {
  return provider !== null;
};

