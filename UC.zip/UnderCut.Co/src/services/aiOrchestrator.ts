/**
 * AI Orchestrator Service
 * 
 * Handles routing, organization, and blockchain orchestration
 * CRITICAL: AI is LOCKED OUT from vital system functions
 * 
 * AI CAN DO:
 * - Route notifications and messages
 * - Organize and categorize data
 * - Prepare blockchain transaction data (NOT execute)
 * - Analytics and insights
 * - Matching suggestions
 * - Search optimization
 * - Content organization
 * 
 * AI CANNOT DO (VITAL FUNCTIONS):
 * - Payment processing
 * - Escrow execution
 * - User authentication
 * - Financial transactions
 * - Access control
 * - User data modifications (write)
 * - Transaction approvals
 * - Money movement
 * 
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {AITask, Quote, Bid, Transaction} from '../types';

export type AITaskType = 
  | 'routing' 
  | 'organization' 
  | 'notification' 
  | 'matching' 
  | 'blockchain_prep'
  | 'analytics'
  | 'optimization';

export type AITaskStatus = 'pending' | 'processing' | 'completed' | 'failed';

/**
 * CRITICAL: Validate task is allowed (not a vital function)
 */
const isTaskAllowed = (taskType: AITaskType, data: any): boolean => {
  // Block any tasks related to vital functions
  const blockedKeywords = [
    'payment',
    'escrow_execute',
    'auth',
    'authenticate',
    'financial',
    'money',
    'transaction_approve',
    'access_control',
    'user_write',
    'signin',
    'signup',
  ];

  const taskDataString = JSON.stringify(data).toLowerCase();
  return !blockedKeywords.some(keyword => taskDataString.includes(keyword));
};

/**
 * Route notification intelligently
 */
export const routeNotification = async (
  userId: string,
  type: string,
  data: any
): Promise<void> => {
  if (!isTaskAllowed('routing', data)) {
    throw new Error('AI: Blocked - Vital function detected');
  }

  try {
    // AI determines best notification channel, timing, priority
    // DOES NOT send - just routes to notification service
    const aiTask: Omit<AITask, 'id'> = {
      type: 'routing',
      status: 'processing',
      data: {
        userId,
        notificationType: type,
        routingData: data,
        priority: determinePriority(type, data),
        channel: determineChannel(type),
      },
      createdAt: new Date(),
    };

    await firestore().collection('aiTasks').add({
      ...aiTask,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    // Route to notification service (AI doesn't execute)
    await firestore().collection('notifications').add({
      userId,
      type,
      data,
      routed: true,
      routedBy: 'ai_orchestrator',
      createdAt: firestore.FieldValue.serverTimestamp(),
    });
  } catch (error) {
    console.error('AI Orchestrator: Routing error', error);
    throw error;
  }
};

/**
 * Organize and categorize quotes
 */
export const organizeQuotes = async (quoteId: string): Promise<void> => {
  try {
    const quoteDoc = await firestore().collection('quotes').doc(quoteId).get();
    if (!quoteDoc.exists) return;

    const quote = quoteDoc.data() as Quote;
    
    // AI analyzes and suggests organization
    // DOES NOT modify - just suggests
    const suggestions = {
      categoryMatch: analyzeCategory(quote),
      priorityScore: calculatePriority(quote),
      matchingSellers: await findMatchingSellers(quote),
    };

    const aiTask: Omit<AITask, 'id'> = {
      type: 'organization',
      status: 'completed',
      data: {
        quoteId,
        suggestions,
        organizedAt: new Date(),
      },
      createdAt: new Date(),
      completedAt: new Date(),
    };

    await firestore().collection('aiTasks').add({
      ...aiTask,
      createdAt: firestore.FieldValue.serverTimestamp(),
      completedAt: firestore.FieldValue.serverTimestamp(),
    });
  } catch (error) {
    console.error('AI Orchestrator: Organization error', error);
  }
};

/**
 * Prepare blockchain transaction data (NOT execute)
 */
export const prepareBlockchainTransaction = async (
  transactionId: string,
  transactionData: any
): Promise<any> => {
  // Validate - AI cannot execute blockchain transactions
  if (transactionData?.execute || transactionData?.sign) {
    throw new Error('AI: Blocked - Cannot execute blockchain transactions');
  }

  try {
    // AI prepares transaction data structure
    // DOES NOT sign or execute
    const preparedData = {
      transactionId,
      from: transactionData.from,
      to: transactionData.to,
      amount: transactionData.amount,
      network: determineNetwork(transactionData),
      gasEstimate: estimateGas(transactionData),
      preparedAt: new Date(),
      preparedBy: 'ai_orchestrator',
      // Critical: NO private keys, NO signing, NO execution
      status: 'prepared',
      requiresHumanApproval: true, // Always requires human/system approval
    };

    const aiTask: Omit<AITask, 'id'> = {
      type: 'blockchain_prep',
      status: 'completed',
      data: {
        transactionId,
        preparedData,
        note: 'AI prepared data only - requires system execution',
      },
      createdAt: new Date(),
      completedAt: new Date(),
    };

    await firestore().collection('aiTasks').add({
      ...aiTask,
      createdAt: firestore.FieldValue.serverTimestamp(),
      completedAt: firestore.FieldValue.serverTimestamp(),
    });

    // Store prepared data (system will execute)
    await firestore().collection('blockchainPrepared').doc(transactionId).set({
      ...preparedData,
      createdAt: firestore.FieldValue.serverTimestamp(),
    });

    return preparedData;
  } catch (error) {
    console.error('AI Orchestrator: Blockchain prep error', error);
    throw error;
  }
};

/**
 * Match buyers with sellers
 */
export const matchBuyerSeller = async (quoteId: string): Promise<string[]> => {
  try {
    const quoteDoc = await firestore().collection('quotes').doc(quoteId).get();
    if (!quoteDoc.exists) return [];

    const quote = quoteDoc.data() as Quote;

    // AI suggests matching sellers
    // DOES NOT create bids or transactions
    const matchingSellers = await findMatchingSellers(quote);

    const aiTask: Omit<AITask, 'id'> = {
      type: 'matching',
      status: 'completed',
      data: {
        quoteId,
        suggestedSellers: matchingSellers,
        matchScore: calculateMatchScore(quote, matchingSellers),
      },
      createdAt: new Date(),
      completedAt: new Date(),
    };

    await firestore().collection('aiTasks').add({
      ...aiTask,
      createdAt: firestore.FieldValue.serverTimestamp(),
      completedAt: firestore.FieldValue.serverTimestamp(),
    });

    // Send suggestions (system handles notifications)
    if (matchingSellers.length > 0) {
      matchingSellers.forEach(sellerId => {
        routeNotification(sellerId, 'quote_match', {quoteId}).catch(() => {
          // Silent fail
        });
      });
    }

    return matchingSellers;
  } catch (error) {
    console.error('AI Orchestrator: Matching error', error);
    return [];
  }
};

/**
 * Optimize search and filtering
 */
export const optimizeSearch = async (
  query: string,
  filters: any
): Promise<any> => {
  try {
    // AI optimizes search parameters
    // DOES NOT access user data directly
    const optimizedQuery = {
      searchTerms: extractKeywords(query),
      relevanceScore: calculateRelevance(query, filters),
      suggestedFilters: suggestFilters(filters),
    };

    return optimizedQuery;
  } catch (error) {
    console.error('AI Orchestrator: Search optimization error', error);
    return filters;
  }
};

// Helper functions (AI logic, no vital operations)

const determinePriority = (type: string, data: any): 'low' | 'medium' | 'high' => {
  // AI determines notification priority
  if (type.includes('urgent') || type.includes('transaction')) return 'high';
  if (type.includes('bid') || type.includes('quote')) return 'medium';
  return 'low';
};

const determineChannel = (type: string): string => {
  // AI determines best notification channel
  if (type.includes('transaction')) return 'push';
  if (type.includes('message')) return 'in_app';
  return 'email';
};

const analyzeCategory = (quote: Quote): string => {
  // AI analyzes quote to suggest category improvements
  return quote.category; // Simplified
};

const calculatePriority = (quote: Quote): number => {
  // AI calculates quote priority score (0-100)
  let score = 50;
  if (quote.urgencyLevel === 'urgent') score += 30;
  if (quote.urgencyLevel === 'asap') score += 50;
  if (quote.buyerCommitted) score += 20;
  return Math.min(100, score);
};

const findMatchingSellers = async (quote: Quote): Promise<string[]> => {
  // AI finds potential matching sellers
  // DOES NOT create bids or transactions
  try {
    const sellersSnapshot = await firestore()
      .collection('users')
      .where('role', '==', 'seller')
      .limit(50)
      .get();

    // Simple matching (can be enhanced)
    return sellersSnapshot.docs
      .map(doc => doc.id)
      .slice(0, 10); // Top 10 matches
  } catch (error) {
    return [];
  }
};

const determineNetwork = (data: any): string => {
  // AI suggests blockchain network based on transaction
  return data.network || 'ethereum';
};

const estimateGas = (data: any): number => {
  // AI estimates gas (does not execute)
  return 21000; // Simplified estimate
};

const calculateMatchScore = (quote: Quote, sellers: string[]): Record<string, number> => {
  // AI calculates match scores
  const scores: Record<string, number> = {};
  sellers.forEach(sellerId => {
    scores[sellerId] = Math.random() * 100; // Simplified
  });
  return scores;
};

const extractKeywords = (query: string): string[] => {
  // AI extracts search keywords
  return query.toLowerCase().split(' ').filter(w => w.length > 2);
};

const calculateRelevance = (query: string, filters: any): number => {
  // AI calculates relevance score
  return 0.8; // Simplified
};

const suggestFilters = (filters: any): any => {
  // AI suggests filter improvements
  return filters;
};

/**
 * Process AI tasks queue (background worker)
 */
export const processAITasks = async (): Promise<void> => {
  try {
    // Get pending AI tasks
    const tasksSnapshot = await firestore()
      .collection('aiTasks')
      .where('status', '==', 'pending')
      .limit(10)
      .get();

    for (const taskDoc of tasksSnapshot.docs) {
      const task = taskDoc.data() as AITask;
      
      // Validate task is allowed
      if (!isTaskAllowed(task.type as AITaskType, task.data)) {
        await taskDoc.ref.update({
          status: 'failed',
          error: 'Blocked - Vital function detected',
        });
        continue;
      }

      // Process task based on type
      await taskDoc.ref.update({status: 'processing'});
      
      try {
        switch (task.type) {
          case 'routing':
            await routeNotification(task.data.userId, task.data.type, task.data);
            break;
          case 'organization':
            await organizeQuotes(task.data.quoteId);
            break;
          case 'matching':
            await matchBuyerSeller(task.data.quoteId);
            break;
          case 'blockchain_prep':
            await prepareBlockchainTransaction(task.data.transactionId, task.data);
            break;
        }
        
        await taskDoc.ref.update({
          status: 'completed',
          completedAt: firestore.FieldValue.serverTimestamp(),
        });
      } catch (error: any) {
        await taskDoc.ref.update({
          status: 'failed',
          error: error.message,
        });
      }
    }
  } catch (error) {
    console.error('AI Orchestrator: Task processing error', error);
  }
};

