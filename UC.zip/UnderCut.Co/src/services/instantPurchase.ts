/**
 * Instant Purchase Service
 * 
 * Enables one-click purchase from best bid - critical for action-motivated buyers
 * © 2024 UnderCut.Co. All Rights Reserved.
 */

import {firestore} from './firebase';
import {Bid, Transaction, Quote} from '../types';
import {initiateEscrow} from './escrow';
import {User} from '../types';

export interface InstantPurchaseResult {
  success: boolean;
  transactionId?: string;
  error?: string;
}

/**
 * Accept bid and create transaction instantly
 */
export const acceptBidInstantly = async (
  quote: Quote,
  bid: Bid,
  buyer: User,
  paymentMethod: 'stripe' | 'xrp'
): Promise<InstantPurchaseResult> => {
  try {
    // Verify buyer is the quote owner
    if (buyer.id !== quote.buyerId) {
      return {success: false, error: 'Only quote owner can accept bids'};
    }

    // Verify bid belongs to quote
    if (bid.quoteId !== quote.id) {
      return {success: false, error: 'Invalid bid for this quote'};
    }

    // Check if quote is still active
    if (quote.expiresAt < new Date()) {
      return {success: false, error: 'Quote has expired'};
    }

    // Create transaction
    const transaction: Omit<Transaction, 'id'> = {
      quoteId: quote.id,
      bidId: bid.id,
      buyerId: buyer.id,
      sellerId: bid.sellerId,
      amount: bid.price,
      currency: bid.currency || quote.currency,
      paymentMethod,
      status: 'escrow_initiated',
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 72 * 60 * 60 * 1000), // 72 hours default
      coolDownEndsAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours cool down
      categoryLevel: quote.categoryLevel,
      termsAccepted: true,
      deliveryTracking: {
        status: 'pending',
      },
    };

    // Save transaction
    const transactionRef = await firestore().collection('transactions').add({
      ...transaction,
      createdAt: firestore.FieldValue.serverTimestamp(),
      expiresAt: firestore.Timestamp.fromDate(transaction.expiresAt),
      coolDownEndsAt: firestore.Timestamp.fromDate(transaction.coolDownEndsAt),
    });

    // Mark bid as selected
    await firestore().collection('bids').doc(bid.id).update({
      isSelected: true,
    });

    // Update quote status
    await firestore().collection('quotes').doc(quote.id).update({
      status: 'accepted',
    });

    // Initiate escrow (async - doesn't block purchase)
    initiateEscrow(transactionRef.id, bid.price, bid.currency || quote.currency).catch(
      error => console.error('Escrow initiation error:', error)
    );

    return {
      success: true,
      transactionId: transactionRef.id,
    };
  } catch (error: any) {
    console.error('Instant purchase error:', error);
    return {
      success: false,
      error: error.message || 'Failed to process instant purchase',
    };
  }
};

/**
 * Get best bid for a quote
 */
export const getBestBid = async (quoteId: string): Promise<Bid | null> => {
  try {
    const snapshot = await firestore()
      .collection('bids')
      .where('quoteId', '==', quoteId)
      .where('isSelected', '==', false)
      .orderBy('price', 'asc')
      .limit(1)
      .get();

    if (snapshot.empty) {
      return null;
    }

    const doc = snapshot.docs[0];
    return {
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
    } as Bid;
  } catch (error) {
    console.error('Error getting best bid:', error);
    return null;
  }
};

/**
 * Check if instant purchase is available
 */
export const canInstantPurchase = (quote: Quote, bids: Bid[]): boolean => {
  // Quote must be active
  if (quote.expiresAt < new Date()) {
    return false;
  }

  // Must have at least one bid
  if (bids.length === 0) {
    return false;
  }

  // Quote must not be already accepted
  if (quote.status === 'accepted' || quote.status === 'completed') {
    return false;
  }

  return true;
};

