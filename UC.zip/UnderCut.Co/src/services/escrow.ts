import {Transaction, TransactionStatus, EscrowDetails} from '../types';
import {getConfig} from '../config/appConfig';
import {createPaymentIntent, confirmPayment} from './stripe';
import {sendXRPPayment, generateXRPVault} from './xrp';
import {recordTransaction} from './blockchain';
import {firestore} from './firebase';
import {addHours} from 'date-fns';

export const createEscrow = async (transaction: Transaction): Promise<EscrowDetails> => {
  try {
    const config = getConfig();
    const now = new Date();
    
    // Calculate expiration based on editable timeout
    const expiresAt = addHours(now, config.transactionTimeoutHours);
    const coolDownEndsAt = addHours(expiresAt, config.escrowCoolDownHours);

    // Update transaction with timing
    await firestore().collection('transactions').doc(transaction.id).update({
      expiresAt,
      coolDownEndsAt,
      status: 'escrow_initiated' as TransactionStatus,
    });

    let escrowAddress: string;
    let blockchainTxHash: string | undefined;

    if (config.paymentProcessor === 'stripe') {
      // Stripe handles escrow automatically
      // Create payment intent but don't capture immediately
      const paymentIntent = await createPaymentIntent(
        transaction.amount,
        transaction.currency,
        transaction.id
      );
      
      escrowAddress = paymentIntent.clientSecret; // Using client secret as escrow identifier
      
      // Store payment intent for later capture
      await firestore().collection('escrows').doc(transaction.id).set({
        transactionId: transaction.id,
        paymentIntentId: paymentIntent.clientSecret,
        amount: transaction.amount,
        currency: transaction.currency,
        status: 'pending',
        createdAt: firestore.FieldValue.serverTimestamp(),
        expiresAt,
      });
    } else if (config.paymentProcessor === 'xrp') {
      // Generate XRP escrow address
      const vault = await generateXRPVault();
      escrowAddress = vault.address;
      
      // Store vault info securely (in production, encrypt the secret)
      await firestore().collection('escrows').doc(transaction.id).set({
        transactionId: transaction.id,
        escrowAddress: vault.address,
        escrowSecret: vault.secret, // In production, encrypt this
        amount: transaction.amount,
        currency: transaction.currency,
        status: 'pending',
        createdAt: firestore.FieldValue.serverTimestamp(),
        expiresAt,
      });
    } else {
      throw new Error('No payment processor configured');
    }

    const escrowDetails: EscrowDetails = {
      transactionId: transaction.id,
      escrowAddress,
      amount: transaction.amount,
      currency: transaction.currency,
      blockchainTxHash: blockchainTxHash || '',
      initiatedAt: now,
      expiresAt,
      status: 'pending',
    };

    return escrowDetails;
  } catch (error) {
    console.error('Error creating escrow:', error);
    throw error;
  }
};

export const releaseEscrow = async (transactionId: string): Promise<boolean> => {
  try {
    const config = getConfig();
    const escrowDoc = await firestore().collection('escrows').doc(transactionId).get();
    
    if (!escrowDoc.exists) {
      throw new Error('Escrow not found');
    }

    const escrowData = escrowDoc.data();

    if (config.paymentProcessor === 'stripe') {
      // Capture the payment intent
      // This would call your backend to capture the Stripe payment
      // Stripe automatically releases to seller's account
      await firestore().collection('transactions').doc(transactionId).update({
        status: 'completed' as TransactionStatus,
        completedAt: firestore.FieldValue.serverTimestamp(),
      });

      await firestore().collection('escrows').doc(transactionId).update({
        status: 'released',
      });
    } else if (config.paymentProcessor === 'xrp') {
      // Send XRP from escrow to seller
      const transactionDoc = await firestore().collection('transactions').doc(transactionId).get();
      const transactionData = transactionDoc.data();
      
      if (!transactionData) {
        throw new Error('Transaction not found');
      }

      // In production, get seller's XRP address from their profile
      const sellerXRPAddress = transactionData.sellerXRPAddress;
      
      if (!sellerXRPAddress) {
        throw new Error('Seller XRP address not found');
      }

      const result = await sendXRPPayment(escrowData?.escrowSecret || '', {
        destination: sellerXRPAddress,
        amount: escrowData?.amount || 0,
        memo: `Escrow release for transaction ${transactionId}`,
      });

      if (result.success && result.txHash) {
        // Record on blockchain
        await recordTransaction(
          transactionId,
          result.txHash,
          escrowData?.escrowAddress || '',
          sellerXRPAddress,
          escrowData?.amount?.toString() || '0'
        );

        await firestore().collection('transactions').doc(transactionId).update({
          status: 'completed' as TransactionStatus,
          completedAt: firestore.FieldValue.serverTimestamp(),
          blockchainTxHash: result.txHash,
        });

        await firestore().collection('escrows').doc(transactionId).update({
          status: 'released',
        });

        return true;
      } else {
        throw new Error(result.error || 'Failed to release escrow');
      }
    }

    return true;
  } catch (error) {
    console.error('Error releasing escrow:', error);
    throw error;
  }
};

export const checkEscrowExpiration = async (): Promise<void> => {
  try {
    const config = getConfig();
    const now = new Date();
    
    // Find expired escrows
    const expiredEscrows = await firestore()
      .collection('escrows')
      .where('status', '==', 'pending')
      .where('expiresAt', '<', now)
      .get();

    for (const doc of expiredEscrows.docs) {
      const escrowData = doc.data();
      
      // Check if cool-down period has passed
      const transactionDoc = await firestore()
        .collection('transactions')
        .doc(escrowData.transactionId)
        .get();
      
      const transactionData = transactionDoc.data();
      
      if (transactionData?.coolDownEndsAt) {
        const coolDownEnds = transactionData.coolDownEndsAt.toDate();
        
        if (now > coolDownEnds) {
          // Cool-down period passed - NO REFUNDS per policy
          // Transaction is finalized, buyer should contact seller directly
          await firestore().collection('transactions').doc(escrowData.transactionId).update({
            status: 'completed' as TransactionStatus,
          });
        }
      }
    }
  } catch (error) {
    console.error('Error checking escrow expiration:', error);
  }
};

