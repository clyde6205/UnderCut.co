import {useEffect} from 'react';
import {updatePlatformUsage} from '../services/chatMePro';
import {useAuth} from '../contexts/AuthContext';

// Hook to track platform usage for chat eligibility
export const usePlatformUsage = () => {
  const {user} = useAuth();

  const trackQuotePost = async () => {
    if (user) {
      await updatePlatformUsage(user.id, 'quote');
    }
  };

  const trackBidSubmission = async () => {
    if (user) {
      await updatePlatformUsage(user.id, 'bid');
    }
  };

  const trackTransactionCompletion = async () => {
    if (user) {
      await updatePlatformUsage(user.id, 'transaction');
    }
  };

  return {
    trackQuotePost,
    trackBidSubmission,
    trackTransactionCompletion,
  };
};

// Auto-track usage when components mount/update
export const useAutoTrackUsage = () => {
  const {trackQuotePost, trackBidSubmission, trackTransactionCompletion} = usePlatformUsage();

  return {
    onQuotePosted: trackQuotePost,
    onBidSubmitted: trackBidSubmission,
    onTransactionCompleted: trackTransactionCompletion,
  };
};

