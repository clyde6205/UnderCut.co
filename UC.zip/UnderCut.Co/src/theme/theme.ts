import {MD3LightTheme, MD3DarkTheme} from 'react-native-paper';

export const theme = {
  ...MD3LightTheme,
  colors: {
    ...MD3LightTheme.colors,
    primary: '#1E3A8A', // Deep blue - professional
    secondary: '#059669', // Emerald green - trust
    tertiary: '#DC2626', // Red - urgency/importance
    accent: '#F59E0B', // Amber - highlights
    background: '#FFFFFF',
    surface: '#F9FAFB',
    error: '#DC2626',
    success: '#059669',
    warning: '#F59E0B',
    info: '#3B82F6',
    text: '#111827',
    textSecondary: '#6B7280',
    border: '#E5E7EB',
    categoryLuxury: '#9333EA', // Purple
    categoryMidLevel: '#3B82F6', // Blue
    categoryLowerLevel: '#10B981', // Green
    global: '#1E40AF', // Global platform indicator
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  borderRadius: {
    sm: 4,
    md: 8,
    lg: 12,
    xl: 16,
    full: 9999,
  },
  typography: {
    h1: {
      fontSize: 32,
      fontWeight: '700' as const,
      lineHeight: 40,
    },
    h2: {
      fontSize: 24,
      fontWeight: '600' as const,
      lineHeight: 32,
    },
    h3: {
      fontSize: 20,
      fontWeight: '600' as const,
      lineHeight: 28,
    },
    body: {
      fontSize: 16,
      fontWeight: '400' as const,
      lineHeight: 24,
    },
    caption: {
      fontSize: 14,
      fontWeight: '400' as const,
      lineHeight: 20,
    },
    small: {
      fontSize: 12,
      fontWeight: '400' as const,
      lineHeight: 16,
    },
  },
};

