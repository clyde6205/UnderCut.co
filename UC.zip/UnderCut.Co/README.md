# UnderCut.Co

**Global Bartering Platform for Focused Buyers and Sellers**

## What We Are

UnderCut.Co is **NOT** a traditional shopping platform. We are a **focused-action bartering platform** designed for buyers who have already decided exactly what product they want to purchase and are seeking the **lowest price** through our vetted, timed offering system.

### Our Platform Purpose

- **For Focused Buyers**: Buyers who know exactly what they want - no tire-kickers
- **For Competitive Sellers**: Sellers who respond with their lowest price to win the sale
- **Global Scale**: Worldwide platform built for billions of users
- **Secure Transactions**: Built-in E-Escrow with blockchain auditing
- **Fair & Timed**: Transparent, time-limited transactions

## Key Features

- ✨ **Vetted Quotes**: Buyers post verified product requests
- 💰 **Lowest Price Competition**: Sellers compete with their best offers
- 🔒 **E-Escrow System**: Secure, timed purchase agreements
- ⏱️ **Editable Transaction Timing**: Configurable deal closure windows
- 🌐 **Global Platform**: Built for worldwide scalability
- 💳 **Multiple Payment Options**: Stripe (primary) and XRP/Ripple (secondary)
- 🔐 **Blockchain Integration**: Full transaction auditing and security
- 🏆 **Category-Based**: Luxury, Mid-level, and Lower-level classifications
- 🤖 **AI Organization**: Automated platform organization and efficiency

## Important Legal & Financial Information

### Payment Processing
- **We NEVER hold or store customer money**
- All funds are processed directly through payment processors (Stripe/XRP)
- Money movement is handled solely by payment platforms and Ripple's payment system

### Transaction Policy
- **NO REFUNDS**: Due to internal Escrow cool-down periods that allow transaction continuation
- Legal disputes are between buyers and sellers only
- UnderCut.Co provides tools and platform services only - we facilitate transactions, we do not mediate disputes

### Financial Disclaimers
- All financial transactions are between buyers and sellers
- Platform fees are transparent and disclosed
- Company operates as a transaction facilitation tool provider

## Tech Stack

- **Framework**: React Native (TypeScript)
- **Database**: Firebase (up to 50k users) → AWS (advanced scaling)
- **Payments**: Stripe (editable) + XRP/Ripple
- **Blockchain**: Full integration for transaction auditing
- **State Management**: React Context API
- **Navigation**: React Navigation

## Getting Started

```bash
# Install dependencies
npm install

# iOS
npm run ios

# Android
npm run android
```

## Environment Setup

Create a `.env` file with:
```
STRIPE_PUBLISHABLE_KEY=your_stripe_key
STRIPE_SECRET_KEY=your_stripe_secret
XRP_API_ENDPOINT=ripple_api_endpoint
FIREBASE_API_KEY=your_firebase_key
BLOCKCHAIN_NETWORK=mainnet
TRANSACTION_TIMEOUT_HOURS=72
```

## Project Structure

```
src/
├── components/     # Reusable UI components
├── screens/        # Screen components
├── navigation/     # Navigation configuration
├── services/       # External services (Firebase, Stripe, XRP, Blockchain)
├── contexts/       # React contexts
├── types/          # TypeScript types
├── utils/          # Utility functions
├── config/         # Configuration files
└── theme/          # Theme and styling
```

## Scaling Strategy

1. **Phase 1**: Firebase (0-50k users)
2. **Phase 2**: AWS migration (50k+ users)
3. **Phase 3**: Enterprise scale (billions of users)

## License

Copyright © UnderCut.Co - All Rights Reserved

